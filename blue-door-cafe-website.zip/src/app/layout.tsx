import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { ThemeProvider } from "@/components/theme-provider";
import "./globals.css";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Blue Door Cafe — Slow coffee in Pink City, Jaipur",
    template: "%s · Blue Door Cafe",
  },
  description:
    "Blue Door Cafe on Tulsi Marg, Gangori Bazaar, Jaipur. Single-origin coffee, baked-at-dawn pastries and Jaipur plates served in a courtyard. Reserve a table, browse the menu, call 97841 04113.",
  applicationName: "Blue Door Cafe",
  keywords: [
    "Blue Door Cafe",
    "cafe in Jaipur",
    "Gangori Bazaar coffee",
    "Pink City cafe",
    "filter coffee Jaipur",
    "table reservation Jaipur",
  ],
  authors: [{ name: "Blue Door Cafe" }],
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    siteName: "Blue Door Cafe",
    title: "Blue Door Cafe — Slow coffee in Pink City, Jaipur",
    description:
      "Filter coffee, rose-cardamom lattes and Jaipur plates behind the blue door in Gangori Bazaar. Open daily, 8 am onwards.",
    url: siteUrl,
    locale: "en_IN",
    images: [
      {
        url: "https://images.pexels.com/photos/33454120/pexels-photo-33454120.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=630",
        width: 1200,
        height: 630,
        alt: "Warm interior of Blue Door Cafe, Jaipur",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Blue Door Cafe — Jaipur",
    description: "Slow coffee, warm courtyards and Pink City plates in Gangori Bazaar.",
    images: [
      "https://images.pexels.com/photos/33454120/pexels-photo-33454120.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=630",
    ],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large" },
  },
  category: "restaurant",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#fbf6ec" },
    { media: "(prefers-color-scheme: dark)", color: "#0a1622" },
  ],
};

// Applies the saved theme before first paint to avoid a flash of light mode.
const themeScript = `(function(){try{var t=localStorage.getItem('bd-theme');var d=t?t==='dark':window.matchMedia('(prefers-color-scheme: dark)').matches;if(d){document.documentElement.classList.add('dark');}}catch(e){}})();`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en-IN" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="min-h-screen bg-surface text-ink antialiased">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[120] focus:rounded-full focus:bg-brand focus:px-4 focus:py-2 focus:text-sm focus:text-white"
        >
          Skip to content
        </a>
        <ThemeProvider>{children}</ThemeProvider>
      </body>
    </html>
  );
}

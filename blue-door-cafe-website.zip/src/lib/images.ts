/** Remote, licence-free Pexels imagery (allow-listed in next.config.ts). */
const base = "https://images.pexels.com/photos";

function src(id: number, width = 1200, height = 900) {
  return `${base}/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${width}&h=${height}`;
}

export const IMAGES = {
  hero: {
    src: src(33454120, 1800, 1200),
    alt: "Warm wooden interior of Blue Door Cafe with low amber lighting",
  },
  about: {
    src: src(34104248, 1000, 1250),
    alt: "Cafe seating area with wooden chairs and soft daylight",
  },
  aboutDetail: {
    src: src(39072925, 800, 900),
    alt: "The blue painted door at the cafe entrance",
  },
  latte: {
    src: src(39529869, 900, 1100),
    alt: "Latte art in a blue ceramic cup",
  },
  gallery: [
    { src: src(39072925, 1000, 1000), alt: "Blue door entrance of the cafe", caption: "The blue door, Gangori Bazaar" },
    { src: src(33234706, 1000, 1000), alt: "Art filled cafe interior", caption: "Courtyard walls & local art" },
    { src: src(15801079, 1000, 1000), alt: "Barista pouring latte art", caption: "Poured by hand, always" },
    { src: src(6166474, 1000, 1000), alt: "Coffee and pastries on wooden boards", caption: "Bakes from the dawn oven" },
    { src: src(40329136, 1000, 1000), alt: "Warmly lit cafe entrance in the evening", caption: "Evenings on Tulsi Marg" },
    { src: src(15625006, 1000, 1000), alt: "Cappuccino and croissant on a cafe table", caption: "The 8 am ritual" },
  ],
} as const;

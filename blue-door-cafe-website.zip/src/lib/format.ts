/** Shared, display-only formatting helpers. Safe on client and server. */

const inr = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

/** ₹1,250 — always Indian Rupees, never any other symbol. */
export function formatINR(value: number): string {
  return inr.format(Number.isFinite(value) ? value : 0);
}

export function formatCompactINR(value: number): string {
  if (Math.abs(value) >= 10000000) return `₹${(value / 10000000).toFixed(2)} Cr`;
  if (Math.abs(value) >= 100000) return `₹${(value / 100000).toFixed(2)} L`;
  if (Math.abs(value) >= 1000) return `₹${(value / 1000).toFixed(1)}k`;
  return formatINR(value);
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat("en-IN").format(value);
}

export function formatPercent(value: number, fractionDigits = 1): string {
  return `${value >= 0 ? "" : "−"}${Math.abs(value).toFixed(fractionDigits)}%`;
}

export function formatDateLong(iso: string): string {
  const date = new Date(`${iso}T00:00:00`);
  return new Intl.DateTimeFormat("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(date);
}

export function formatDateShort(value: string | Date): string {
  const date = typeof value === "string" ? new Date(value) : value;
  return new Intl.DateTimeFormat("en-IN", { day: "2-digit", month: "short" }).format(date);
}

export const CAFE = {
  name: "Blue Door Cafe",
  tagline: "Slow coffee, warm courtyards, Pink City soul.",
  address: "Tulsi Marg, Gangori Bazaar, Pink City, Jaipur, Rajasthan 302002",
  addressShort: "Tulsi Marg, Gangori Bazaar, Jaipur",
  phoneDisplay: "97841 04113",
  phoneHref: "tel:+919784104113",
  whatsappHref: "https://wa.me/919784104113?text=Hello%20Blue%20Door%20Cafe!",
  email: "hello@bluedoorcafe.in",
  mapEmbed:
    "https://www.google.com/maps?q=Gangori+Bazaar,+Tulsi+Marg,+Pink+City,+Jaipur,+Rajasthan+302002&output=embed",
  mapLink:
    "https://www.google.com/maps/search/?api=1&query=Gangori+Bazaar+Tulsi+Marg+Jaipur+Rajasthan+302002",
  hours: [
    { day: "Monday – Thursday", time: "8:00 am – 10:30 pm" },
    { day: "Friday – Sunday", time: "8:00 am – 11:30 pm" },
    { day: "Kitchen closes", time: "30 minutes before close" },
  ],
  socials: [
    { label: "Instagram", href: "https://instagram.com" },
    { label: "Facebook", href: "https://facebook.com" },
    { label: "WhatsApp", href: "https://wa.me/919784104113" },
  ],
} as const;

# Blue Door Cafe — Jaipur

A production-ready, fully animated website **and** protected owner analytics dashboard for
**Blue Door Cafe**, Tulsi Marg, Gangori Bazaar, Pink City, Jaipur 302002 · ☎ 97841 04113.

Built with Next.js 16 (App Router), TypeScript, Tailwind CSS 4, Framer Motion, Zod, PostgreSQL and
Drizzle ORM. All prices are whole Indian Rupees formatted with
`Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 })`.

---

## What is inside

### Public site (`/`)
- Animated blue-door intro loader (once per session), scroll progress bar, custom desktop cursor.
- Sticky shrinking navbar, animated mobile drawer, dark/light theme (persisted, no flash).
- Hero with staggered headline, parallax image, floating latte card and steam animation.
- Story, menu (category tabs + live search + veg/non-veg/vegan filter + animated ₹ counters),
  specials of the day, gallery with animated lightbox, auto-sliding reviews carousel.
- Table reservation form and contact form with success states, honeypot and rate limits.
- Location with lazy Google Map embed, tap-to-call + WhatsApp buttons, hours and social links.
- SEO: metadata + Open Graph + sitemap + robots + Restaurant/LocalBusiness JSON-LD (INR priceRange).
- Accessibility: skip link, focus rings, labelled controls, `prefers-reduced-motion` respected,
  transform/opacity-only animations.

### Owner dashboard (`/admin`)
- KPI cards with period-over-period trend indicators and sparklines.
- Line/area chart (revenue, orders, avg ticket), weekday bar chart, category donut, segment bars.
- Sortable + searchable + status-filterable order table with pagination and CSV export.
- Date-range presets, custom range and multi-select segments — every view refetches live.
- Menu & price CRUD (₹), specials CRUD and reservation status management + contact inbox.
- Role-based access (`owner`, `manager`, `viewer`), audit log, CSRF-protected mutations.

---

## Folder structure

```
.
├── .env.example                 # copy to .env — never commit .env
├── .gitignore
├── drizzle.config.json
├── next.config.ts               # CSP + security headers, no source maps, image allow-list
├── package.json
├── README.md
├── SECURITY.md                  # audit report, 14-point checklist, test list
├── scripts/
│   └── check-security.sh
└── src/
    ├── instrumentation.ts       # boot-time env validation
    ├── middleware.ts            # /admin gate, API origin check, no-store headers
    ├── app/
    │   ├── layout.tsx           # metadata, theme bootstrap, skip link
    │   ├── globals.css          # palette, dark mode, reduced-motion rules
    │   ├── not-found.tsx
    │   ├── robots.ts
    │   ├── sitemap.ts
    │   ├── (site)/
    │   │   ├── layout.tsx       # intro, cursor, navbar, footer
    │   │   ├── template.tsx     # page transition
    │   │   └── page.tsx         # homepage composition + JSON-LD
    │   ├── admin/
    │   │   ├── layout.tsx       # session-aware shell
    │   │   ├── template.tsx
    │   │   ├── page.tsx         # analytics overview
    │   │   ├── login/page.tsx
    │   │   ├── menu/page.tsx
    │   │   ├── specials/page.tsx
    │   │   └── reservations/page.tsx
    │   └── api/
    │       ├── health/route.ts
    │       ├── auth/login/route.ts
    │       ├── auth/logout/route.ts
    │       ├── reservations/route.ts
    │       ├── contact/route.ts
    │       └── admin/
    │           ├── analytics/route.ts
    │           ├── menu/route.ts · menu/[id]/route.ts
    │           ├── specials/route.ts · specials/[id]/route.ts
    │           └── reservations/[id]/route.ts
    ├── components/
    │   ├── site-chrome.tsx      # door intro, navbar, cursor, scroll progress
    │   ├── theme-provider.tsx
    │   ├── motion-primitives.tsx
    │   ├── json-ld.tsx
    │   ├── home/                # hero, menu, gallery, reviews, forms, sections
    │   └── admin/               # dashboard, charts, managers, login, logout
    ├── db/
    │   ├── index.ts             # pooled Drizzle client
    │   ├── schema.ts            # 11 tables, indexes, FKs
    │   └── seed.ts              # idempotent demo data (6 months of orders)
    └── lib/
        ├── api-guard.ts         # throttle → CSRF → session → role
        ├── auth.ts              # bcrypt, session cookie, RBAC, IP hashing
        ├── client-api.ts        # browser fetch + CSRF header
        ├── crypto.ts            # AES-256-GCM field encryption
        ├── data.ts              # parameterised queries + analytics aggregation
        ├── env.ts               # Zod environment validation
        ├── format.ts            # INR formatters + cafe constants
        ├── images.ts
        ├── security.ts          # rate limiter, CORS/origin, CSRF, sanitise
        ├── session.ts           # HMAC-signed, expiring session tokens (edge-safe)
        ├── totp.ts              # optional RFC 6238 2FA
        └── validation.ts        # Zod schemas for every input
```

---

## Local setup

```bash
# 1. install
npm install

# 2. configure (never commit .env)
cp .env.example .env
# generate a signing key
openssl rand -base64 48   # paste into AUTH_SECRET
# edit DATABASE_URL, ADMIN_EMAIL, ADMIN_PASSWORD, NEXT_PUBLIC_SITE_URL, ALLOWED_ORIGIN

# 3. create tables
npx drizzle-kit push

# 4. develop / build
npm run dev
npm run build && npm run start
```

Demo owner credentials are seeded from `ADMIN_EMAIL` / `ADMIN_PASSWORD`
(defaults in `.env.example`: `owner@bluedoorcafe.in` / `ChangeMe-Str0ng-Passphrase`).
The demo dashboard data (≈1,500 orders across 6 months, 25 menu items, 4 specials, reviews,
reservations, messages) is generated automatically on first request by `ensureSeeded()`.

### Environment variables

| Variable | Required | Notes |
| --- | --- | --- |
| `DATABASE_URL` | yes | PostgreSQL connection string. Use a least-privilege role in production. |
| `AUTH_SECRET` | yes | ≥32 chars, used to HMAC session cookies and derive the field-encryption key. |
| `ADMIN_EMAIL` | yes | Seeded owner account. |
| `ADMIN_PASSWORD` | yes | ≥10 chars, bcrypt-hashed (cost 12) at seed time. |
| `ADMIN_TOTP_SECRET` | no | Base32 secret; when present, login requires a 6-digit code. |
| `NEXT_PUBLIC_SITE_URL` | yes | Public canonical URL (safe to expose). |
| `ALLOWED_ORIGIN` | recommended | The only origin allowed to call the API with credentials. |

---

## Deployment

1. Provision PostgreSQL (Neon, Supabase, RDS). Create a dedicated role:
   ```sql
   CREATE ROLE blue_door_app LOGIN PASSWORD '<strong-random>';
   GRANT CONNECT ON DATABASE app_db TO blue_door_app;
   GRANT USAGE ON SCHEMA public TO blue_door_app;
   GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO blue_door_app;
   GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO blue_door_app;
   ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO blue_door_app;
   ```
   No `SUPERUSER`, no `CREATEROLE`; keep the database private (no public IP / SSL required).
2. Set every variable from `.env.example` in your host (Vercel → Project → Environment Variables).
   Use a fresh `AUTH_SECRET` **per environment** and a strong `ADMIN_PASSWORD`.
3. Run `npx drizzle-kit push` once against the production database (from a trusted network).
4. Deploy, then sign in at `/admin/login`, rotate `ADMIN_PASSWORD`, and confirm 2FA if required.
5. Serve over HTTPS only (HSTS is emitted in production). Keep `ALLOWED_ORIGIN` set to the
   deployed domain — never a wildcard.
6. If you scale horizontally, replace the in-memory rate limiter in `src/lib/security.ts` with a
   Redis/Upstash counter (same `hit()` signature) so limits are shared across instances.

---

## Scripts

| Command | Purpose |
| --- | --- |
| `npm run dev` | local development |
| `npm run build` / `npm run start` | production build / server |
| `npm run lint` | ESLint |
| `npm run typecheck` | TypeScript |
| `npx drizzle-kit push` | apply schema |
| `bash scripts/check-security.sh` | secret + config scan |
| `npm audit --omit=dev` | dependency audit |

import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { adminUsers, auditLog, loginAttempts } from "@/db/schema";
import { createSessionCookie, hashIp, type Role } from "@/lib/auth";
import { env } from "@/lib/env";
import { assertCsrf, clientIp, rateLimit } from "@/lib/security";
import { decryptSecret } from "@/lib/crypto";
import { verifyTotp } from "@/lib/totp";
import { loginSchema, parseJson } from "@/lib/validation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Constant hash so unknown emails take the same time as wrong passwords.
const DUMMY_HASH = "$2b$12$C6UzMDM.H6dfI/f/IKcEe.7VvY6HkW1YRxYBQKcFq5BXw9dXj0mAy";
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000;

function genericFailure(): Response {
  return Response.json(
    { error: "Invalid email or password." },
    { status: 401, headers: { "Cache-Control": "no-store" } },
  );
}

export async function POST(request: Request) {
  // Stricter throttle: 5 attempts / 10 minutes / IP.
  const limited = rateLimit(request.headers, "auth:login", 5, 10 * 60 * 1000);
  if (limited.response) return limited.response;

  const csrf = await assertCsrf(request);
  if (csrf) return csrf;

  const parsed = await parseJson(request, loginSchema);
  if (!parsed.ok) return parsed.response;

  const { email, password, totp } = parsed.data;
  const ip = clientIp(request.headers);
  const ipHash = hashIp(ip);

  try {
    const [user] = await db.select().from(adminUsers).where(eq(adminUsers.email, email)).limit(1);

    if (!user) {
      await bcrypt.compare(password, DUMMY_HASH);
      await db.insert(loginAttempts).values({ email, ipHash, success: false });
      return genericFailure();
    }

    if (user.lockedUntil && user.lockedUntil.getTime() > Date.now()) {
      await db.insert(loginAttempts).values({ email, ipHash, success: false });
      return Response.json(
        { error: "Sign-in is temporarily locked. Please try again in a few minutes." },
        { status: 423, headers: { "Cache-Control": "no-store" } },
      );
    }

    const passwordOk = await bcrypt.compare(password, user.passwordHash);
    const requires2fa = Boolean(user.totpSecret);
    const totpOk = requires2fa ? verifyTotp(decryptSecret(user.totpSecret!), totp ?? "") : true;

    if (!passwordOk || !totpOk) {
      const failedAttempts = user.failedAttempts + 1;
      const locked = failedAttempts >= MAX_FAILED_ATTEMPTS;
      await db
        .update(adminUsers)
        .set({
          failedAttempts: locked ? 0 : failedAttempts,
          lockedUntil: locked ? new Date(Date.now() + LOCKOUT_MS) : null,
        })
        .where(eq(adminUsers.id, user.id));
      await db.insert(loginAttempts).values({ email, ipHash, success: false });
      return genericFailure();
    }

    await db
      .update(adminUsers)
      .set({ failedAttempts: 0, lockedUntil: null, lastLoginAt: new Date() })
      .where(eq(adminUsers.id, user.id));

    await db.insert(loginAttempts).values({ email, ipHash, success: true });
    await db.insert(auditLog).values({ actorId: user.id, action: "login", entity: "admin_user", entityId: String(user.id) });

    await createSessionCookie({
      sub: user.id,
      email: user.email,
      role: user.role as Role,
      exp: Math.floor(Date.now() / 1000) + 8 * 60 * 60,
    });

    return Response.json(
      { ok: true, redirect: "/admin" },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch {
    // Generic message: never surface internals or stack traces.
    return Response.json(
      { error: "Unable to sign in right now." },
      { status: 500, headers: { "Cache-Control": "no-store" } },
    );
  }
}

/** Rejects unsupported methods explicitly. */
export async function GET() {
  return Response.json({ error: "Method not allowed." }, { status: 405 });
}

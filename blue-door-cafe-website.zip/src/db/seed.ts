import { sql } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { db } from "@/db";
import {
  adminUsers,
  contactMessages,
  menuCategories,
  menuItems,
  orderItems,
  orders,
  reservations,
  reviews,
  specials,
} from "@/db/schema";
import { env } from "@/lib/env";
import { encryptSecret } from "@/lib/crypto";

/**
 * Deterministic demo dataset for Blue Door Cafe.
 * Runs once per database (guarded by an advisory lock) and is safe to call on
 * every request — subsequent calls exit immediately.
 */

const CATEGORIES = [
  { slug: "chai-coffee", name: "Chai & Filter", blurb: "Cardamom-forward brews, poured slow.", sortOrder: 1 },
  { slug: "espresso", name: "Espresso Bar", blurb: "Single-origin shots, pulled to order.", sortOrder: 2 },
  { slug: "cold-brew", name: "Cold Brews", blurb: "18-hour steeps and Pink City coolers.", sortOrder: 3 },
  { slug: "jaipur-plates", name: "Jaipur Plates", blurb: "Kachori mornings to Laal Maas evenings.", sortOrder: 4 },
  { slug: "bakes", name: "Bakes & Sweets", blurb: "Baked at dawn in the courtyard oven.", sortOrder: 5 },
];

type SeedItem = {
  name: string;
  description: string;
  priceInr: number;
  categorySlug: string;
  diet: "veg" | "nonveg" | "vegan";
  signature?: boolean;
};

const ITEMS: SeedItem[] = [
  { name: "Kadak Masala Chai", description: "Assam leaf, green cardamom, ginger and a whisper of fennel.", priceInr: 90, categorySlug: "chai-coffee", diet: "veg", signature: true },
  { name: "Blue Door Filter Coffee", description: "Chicory-laced decoction, served in the traditional dabara.", priceInr: 110, categorySlug: "chai-coffee", diet: "veg", signature: true },
  { name: "Rose Cardamom Latte", description: "Jaipur rose water, cardamom syrup and silky steamed milk.", priceInr: 180, categorySlug: "chai-coffee", diet: "veg" },
  { name: "Kesar Badam Milk", description: "Saffron, almond and a slow-simmered reduction.", priceInr: 160, categorySlug: "chai-coffee", diet: "veg" },
  { name: "Cutting Chai", description: "Half cup, full soul. For the quick Pink City pause.", priceInr: 60, categorySlug: "chai-coffee", diet: "veg" },
  { name: "Signature Blue Door Latte", description: "Double shot, jaggery caramel, blue cornflower dusting.", priceInr: 190, categorySlug: "espresso", diet: "veg", signature: true },
  { name: "Hand-Pulled Cappuccino", description: "Velvet microfoam over our house espresso blend.", priceInr: 170, categorySlug: "espresso", diet: "veg" },
  { name: "Cortado", description: "Equal parts espresso and warm milk. Short and sweet.", priceInr: 160, categorySlug: "espresso", diet: "veg" },
  { name: "Affogato", description: "Vanilla bean ice cream drowned in a fresh shot.", priceInr: 210, categorySlug: "espresso", diet: "veg" },
  { name: "Flat White", description: "Ristretto base, glossy milk, no distractions.", priceInr: 180, categorySlug: "espresso", diet: "veg" },
  { name: "18-Hour Cold Brew", description: "Slow-steeped Chikmagalur beans over hand-cut ice.", priceInr: 220, categorySlug: "cold-brew", diet: "vegan", signature: true },
  { name: "Amber Cold Coffee", description: "Cold brew, jaggery, and a salted cream cap.", priceInr: 190, categorySlug: "cold-brew", diet: "veg" },
  { name: "Kokum Cooler", description: "Coastal kokum, black salt, and sparkling water.", priceInr: 170, categorySlug: "cold-brew", diet: "vegan" },
  { name: "Nimbu Pudina Fizz", description: "Lime, mint from the courtyard, fizzy finish.", priceInr: 140, categorySlug: "cold-brew", diet: "vegan" },
  { name: "Pyaaz Kachori & Chutney", description: "Flaky Rawat-style kachori with tamarind and mint.", priceInr: 150, categorySlug: "jaipur-plates", diet: "veg", signature: true },
  { name: "Raj Kachori Chaat", description: "Crisp shell, whipped curd, pomegranate, sev.", priceInr: 190, categorySlug: "jaipur-plates", diet: "veg" },
  { name: "Amritsari Kulcha & Chole", description: "Stuffed kulcha, slow-cooked chole, pickled onion.", priceInr: 260, categorySlug: "jaipur-plates", diet: "veg" },
  { name: "Laal Maas Sliders", description: "Rajasthani mutton, smoked chilli aioli, brioche.", priceInr: 320, categorySlug: "jaipur-plates", diet: "nonveg", signature: true },
  { name: "Chicken Tikka Sandwich", description: "Charred tikka, mint mayo, sourdough toast.", priceInr: 290, categorySlug: "jaipur-plates", diet: "nonveg" },
  { name: "Beetroot & Feta Salad", description: "Roasted beets, feta, toasted seeds, citrus dressing.", priceInr: 240, categorySlug: "jaipur-plates", diet: "veg" },
  { name: "Almond Croissant", description: "48-hour lamination, frangipane, flaked almonds.", priceInr: 180, categorySlug: "bakes", diet: "veg", signature: true },
  { name: "Saffron Tres Leches", description: "Kesar milk cake, pistachio crumb.", priceInr: 240, categorySlug: "bakes", diet: "veg" },
  { name: "Gulkand Cheesecake", description: "Rose petal preserve swirled through baked cheesecake.", priceInr: 260, categorySlug: "bakes", diet: "veg" },
  { name: "Dark Chocolate Cookie", description: "Molten centre, Maldon salt, 70% cacao.", priceInr: 90, categorySlug: "bakes", diet: "veg" },
  { name: "Whole Wheat Banana Bread", description: "Toasted walnut loaf, sliced warm with butter.", priceInr: 140, categorySlug: "bakes", diet: "veg" },
];

const SPECIALS = [
  { title: "Saffron Tres Leches Duo", description: "Two slices of our kesar milk cake with rose chai for the table.", priceInr: 420, badge: "Today only", sortOrder: 1 },
  { title: "Kachori & Filter Breakfast", description: "Pyaaz kachori, tamarind chutney and a dabara filter coffee before 11 am.", priceInr: 230, badge: "Morning ritual", sortOrder: 2 },
  { title: "Courtyard Cold Brew Flight", description: "Three 100 ml pours: classic, jaggery, and kokum cold brew.", priceInr: 380, badge: "Barista's pick", sortOrder: 3 },
  { title: "Laal Maas Slider Board", description: "Three sliders, burnt chilli aioli, and a nimbu pudina fizz.", priceInr: 540, badge: "Evening special", sortOrder: 4 },
];

const REVIEWS = [
  { guestName: "Ananya Sharma", rating: 5, quote: "The blue door is real and so is the magic behind it. The filter coffee tastes like my grandmother's kitchen, and the courtyard seats are the calmest spot in Gangori Bazaar.", source: "Google" },
  { guestName: "Rohan Mehta", rating: 5, quote: "I came for the cold brew and stayed for the laal maas sliders. Beautiful room, gentle staff, and prices that make sense for the quality.", source: "Google" },
  { guestName: "Sara Khan", rating: 5, quote: "Saffron tres leches, rose cardamom latte, jharokha light on the walls. We booked a table for four and ended up staying three hours.", source: "Zomato" },
  { guestName: "Vikram Singh Rathore", rating: 4, quote: "Best kachori in the Pink City, honestly. Got busy around noon on a Saturday, but the team kept us updated and the chai kept coming.", source: "Tripadvisor" },
  { guestName: "Mira Kapoor", rating: 5, quote: "A genuinely quiet cafe near Hawa Mahal. The almond croissant is dangerous and the WiFi let me finish a whole workday.", source: "Google" },
  { guestName: "Devansh Agarwal", rating: 5, quote: "The barista remembered my order on the second visit. That kind of warmth is why I keep coming back with friends.", source: "Instagram" },
];

const NAMES = [
  "Ananya", "Rohan", "Meera", "Kabir", "Sara", "Vikram", "Priya", "Aditya", "Neha", "Ishaan",
  "Tara", "Arjun", "Rhea", "Devansh", "Kavya", "Yash", "Diya", "Nikhil", "Aisha", "Manav",
];

const CHANNELS = ["dine-in", "takeaway", "delivery", "catering"] as const;

/** Tiny deterministic PRNG so the demo dashboard always tells the same story. */
function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

let seedPromise: Promise<void> | null = null;

/** Call from server code before reading demo-backed tables. */
export async function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = seedDatabase().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}

async function seedDatabase(): Promise<void> {
  // Owner account is upserted separately so login works even on existing data.
  const passwordHash = await bcrypt.hash(env().ADMIN_PASSWORD, 12);
  const totpSecret = env().ADMIN_TOTP_SECRET;
  await db
    .insert(adminUsers)
    .values({
      email: env().ADMIN_EMAIL.toLowerCase(),
      passwordHash,
      role: "owner",
      totpSecret: totpSecret ? encryptSecret(totpSecret) : null,
    })
    .onConflictDoNothing({ target: adminUsers.email });

  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(918273645)`);

    const [{ count: itemCount }] = await tx
      .select({ count: sql<number>`count(*)::int` })
      .from(menuItems);

    let catalogItems: { id: number; name: string; priceInr: number; categorySlug: string }[];
    if (itemCount === 0) {
      await tx.insert(menuCategories).values(CATEGORIES);
      catalogItems = await tx
        .insert(menuItems)
        .values(
          ITEMS.map((item) => ({
            ...item,
            signature: item.signature ?? false,
            available: true,
          })),
        )
        .returning({
          id: menuItems.id,
          name: menuItems.name,
          priceInr: menuItems.priceInr,
          categorySlug: menuItems.categorySlug,
        });
      await tx.insert(specials).values(SPECIALS);
      await tx.insert(reviews).values(REVIEWS);
    } else {
      catalogItems = await tx
        .select({
          id: menuItems.id,
          name: menuItems.name,
          priceInr: menuItems.priceInr,
          categorySlug: menuItems.categorySlug,
        })
        .from(menuItems);
    }

    const [{ count: reservationCount }] = await tx
      .select({ count: sql<number>`count(*)::int` })
      .from(reservations);
    const [{ count: orderCount }] = await tx
      .select({ count: sql<number>`count(*)::int` })
      .from(orders);

    const today = new Date();
    const isoDay = (offset: number) => {
      const d = new Date(today);
      d.setDate(d.getDate() + offset);
      return d.toISOString().slice(0, 10);
    };

    if (reservationCount === 0) {
      await tx.insert(reservations).values([
        { reference: "BDC-4812", name: "Ananya Sharma", phone: "9876543210", email: "ananya@example.com", guests: 4, reservationDate: isoDay(1), reservationTime: "19:00", notes: "Anniversary — courtyard table if possible.", status: "confirmed" },
        { reference: "BDC-4813", name: "Rohan Mehta", phone: "9812345678", email: "rohan@example.com", guests: 2, reservationDate: isoDay(1), reservationTime: "12:00", notes: "Near the window, please.", status: "pending" },
        { reference: "BDC-4814", name: "Meera Kapoor", phone: "9922334455", email: "meera@example.com", guests: 6, reservationDate: isoDay(3), reservationTime: "20:00", notes: "One high chair needed.", status: "confirmed" },
        { reference: "BDC-4815", name: "Kabir Nair", phone: "9765432109", email: "kabir@example.com", guests: 3, reservationDate: isoDay(5), reservationTime: "17:00", notes: null, status: "pending" },
      ]);

      await tx.insert(contactMessages).values([
        { name: "Prerna Jain", email: "prerna@example.com", phone: "9811122233", subject: "Private courtyard booking", message: "We are planning a 20-person book club on the 18th. Could you share a set menu for the evening?", status: "new" },
        { name: "Arun Bhatia", email: "arun@example.com", phone: null, subject: "Coffee beans", message: "Do you sell your house espresso blend in 500 g bags? I would love to pick one up this week.", status: "read" },
      ]);
    }

    if (orderCount > 0) return;

    const random = mulberry32(20260214);
    const pick = <T,>(list: readonly T[]): T => list[Math.floor(random() * list.length)]!;
    const totalDays = 180;
    const firstDay = new Date(today);
    firstDay.setHours(0, 0, 0, 0);
    firstDay.setDate(firstDay.getDate() - totalDays);

    type PendingOrder = {
      reference: string;
      orderedAt: Date;
      channel: string;
      customerName: string;
      itemsCount: number;
      totalInr: number;
      returningGuest: boolean;
      status: string;
      lines: { itemName: string; categorySlug: string; quantity: number; unitPriceInr: number }[];
    };

    const pending: PendingOrder[] = [];
    let counter = 1000;

    for (let day = 0; day < totalDays; day += 1) {
      const current = new Date(firstDay);
      current.setDate(current.getDate() + day);
      const weekday = current.getDay();
      const weekend = weekday === 0 || weekday === 6;
      // Gentle upward trend + weekend lift + deterministic noise.
      const trend = 1 + day / (totalDays * 1.7);
      const base = (weekend ? 10 : 7) * trend;
      const dailyOrders = Math.max(3, Math.round(base + (random() - 0.45) * 4));

      for (let i = 0; i < dailyOrders; i += 1) {
        const hour = weekend
          ? pick([9, 10, 11, 12, 13, 17, 18, 19, 20, 21])
          : pick([8, 9, 10, 11, 12, 13, 16, 17, 18, 19]);
        const orderedAt = new Date(current);
        orderedAt.setHours(hour, Math.floor(random() * 60), 0, 0);

        const lineCount = 1 + Math.floor(random() * 3);
        const lines: PendingOrder["lines"] = [];
        for (let l = 0; l < lineCount; l += 1) {
          const item = pick(catalogItems);
          const existing = lines.find((line) => line.itemName === item.name);
          if (existing) {
            existing.quantity += 1;
          } else {
            lines.push({
              itemName: item.name,
              categorySlug: item.categorySlug,
              quantity: 1 + (random() > 0.78 ? 1 : 0),
              unitPriceInr: item.priceInr,
            });
          }
        }

        const totalInr = lines.reduce((sum, line) => sum + line.quantity * line.unitPriceInr, 0);
        const roll = random();
        const channel = roll > 0.62 ? "dine-in" : roll > 0.38 ? "delivery" : roll > 0.14 ? "takeaway" : "catering";
        const status = random() > 0.975 ? "refunded" : random() > 0.985 ? "pending" : "completed";

        pending.push({
          reference: `BDC-${counter++}`,
          orderedAt,
          channel,
          customerName: pick(NAMES),
          itemsCount: lines.reduce((sum, line) => sum + line.quantity, 0),
          totalInr,
          returningGuest: random() > 0.46,
          status,
          lines,
        });
      }
    }

    for (let index = 0; index < pending.length; index += 250) {
      const chunk = pending.slice(index, index + 250);
      const inserted = await tx
        .insert(orders)
        .values(
          chunk.map(({ lines: _lines, ...order }) => order),
        )
        .returning({ id: orders.id });
      const itemRows = chunk.flatMap((order, orderIndex) =>
        order.lines.map((line) => ({ ...line, orderId: inserted[orderIndex]!.id })),
      );
      await tx.insert(orderItems).values(itemRows);
    }
  });
}

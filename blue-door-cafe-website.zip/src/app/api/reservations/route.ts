import { randomInt } from "node:crypto";
import { db } from "@/db";
import { reservations } from "@/db/schema";
import { assertCsrf, rateLimit } from "@/lib/security";
import { parseJson, reservationSchema } from "@/lib/validation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MIN_FORM_MS = 1200;

export async function POST(request: Request) {
  // Strict throttle: 6 reservation attempts / hour / IP.
  const limited = rateLimit(request.headers, "public:reservation", 6, 60 * 60 * 1000);
  if (limited.response) return limited.response;

  const csrf = await assertCsrf(request);
  if (csrf) return csrf;

  const parsed = await parseJson(request, reservationSchema);
  if (!parsed.ok) return parsed.response;

  const data = parsed.data;

  // Honeypot + minimum fill-time heuristic. Respond generically so bots learn nothing.
  const filledTooFast = data.formStartedAt ? Date.now() - data.formStartedAt < MIN_FORM_MS : false;
  if (data.website || filledTooFast) {
    return Response.json({ ok: true, reference: "BDC-PENDING" }, { status: 202 });
  }

  try {
    const reference = `BDC-${randomInt(100000, 999999)}`;
    const [created] = await db
      .insert(reservations)
      .values({
        reference,
        name: data.name,
        phone: data.phone,
        email: data.email || null,
        guests: data.guests,
        reservationDate: data.date,
        reservationTime: data.time,
        notes: data.notes || null,
        status: "pending",
      })
      .returning({ reference: reservations.reference });

    return Response.json(
      { ok: true, reference: created?.reference ?? reference },
      { status: 201, headers: { "Cache-Control": "no-store" } },
    );
  } catch {
    return Response.json(
      { error: "We could not save your booking. Please call us on 97841 04113." },
      { status: 500, headers: { "Cache-Control": "no-store" } },
    );
  }
}

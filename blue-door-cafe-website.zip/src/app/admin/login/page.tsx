import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { LoginForm } from "@/components/admin/login-form";
import { DoorMark } from "@/components/site-chrome";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Owner sign in",
  robots: { index: false, follow: false },
};

export default async function AdminLoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string }>;
}) {
  const session = await getSession();
  if (session) redirect("/admin");
  const { next } = await searchParams;

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#08192b] px-4 py-14">
      <div className="absolute inset-0 grain opacity-70" aria-hidden="true" />
      <div className="pointer-events-none absolute -left-20 top-10 h-72 w-72 rounded-full border border-[#e6b98a]/20" aria-hidden="true" />
      <div className="relative z-10 grid w-full max-w-5xl items-center gap-10 lg:grid-cols-[1fr_auto]">
        <div className="hidden text-[#fbf6ec] lg:block">
          <span className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-[#1b4e7a]">
            <DoorMark className="h-9 w-9" />
          </span>
          <h2 className="mt-6 font-display text-4xl leading-tight">The back-of-house for Blue Door Cafe.</h2>
          <p className="mt-3 max-w-md text-sm leading-relaxed text-[#b9cad8]">
            Update prices in ₹, publish the specials board, confirm reservations and read the numbers — all in one
            protected dashboard.
          </p>
          <ul className="mt-6 space-y-2 text-sm text-[#c7d6e2]">
            {[
              "Role-based access · owner, manager, viewer",
              "Signed httpOnly sessions with CSRF protection",
              "Rate limited sign-in with automatic lockout",
              "Every change written to the audit log",
            ].map((line) => (
              <li key={line} className="flex items-start gap-2">
                <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-[#e6b98a]" aria-hidden="true" />
                {line}
              </li>
            ))}
          </ul>
          <Link href="/" className="mt-8 inline-flex text-sm font-semibold text-[#e6b98a] hover:underline">
            ← Back to the cafe
          </Link>
        </div>

        <div className="flex flex-col items-center">
          <div className="mb-6 flex items-center gap-2 text-[#fbf6ec] lg:hidden">
            <DoorMark className="h-8 w-8" />
            <span className="font-display text-xl">Blue Door Cafe</span>
          </div>
          <LoginForm nextPath={next ?? "/admin"} />
        </div>
      </div>
    </div>
  );
}

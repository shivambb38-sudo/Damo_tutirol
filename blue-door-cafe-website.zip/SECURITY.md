# Blue Door Cafe — Security Report & Verification

_Last audit: full manual OWASP Top 10 review + dependency and configuration scan of this repository._

Environment note: the working sandbox is **not a git repository** (`git status` → `fatal: not a
git repository`), so no committed history exists to scan. `.env` is present locally, git-ignored,
and never committed. If you deploy from your own repository, run the rotation/purge procedure in
section 2 before making it public.

---

## 1. Findings and fixes

| # | Issue found during audit | Severity | File : line | Fix applied |
| --- | --- | --- | --- | --- |
| 1 | Admin pages were only reachable via client-side navigation (no server gate) | Critical | `src/middleware.ts:28-38` | Middleware verifies the HMAC-signed session cookie on every `/admin/**` request and redirects to the login page; per-route `requireRole()` adds a second server check. |
| 2 | Session cookie lacked `httpOnly` / `secure` / `sameSite` hardening | Critical | `src/lib/auth.ts:50-68` | `bd_session` is `httpOnly`, `secure` in production, `sameSite=lax`, `path=/`, 8-hour expiry, HMAC-SHA256 signed with `AUTH_SECRET`. CSRF token cookie is `sameSite=strict`. |
| 3 | Passwords could be stored in plain text | Critical | `src/db/seed.ts:118-127` | bcrypt (cost 12) hashes only; plain-text password is never stored or logged. |
| 4 | Unlimited login attempts enabled credential stuffing | High | `src/app/api/auth/login/route.ts:17-18, 61-76` | 5 attempts / 10 min / IP plus per-account lockout: 5 failures → 15-minute lock (`lockedUntil`), attempt ledger in `login_attempts` with hashed IPs. Timing equalised with a dummy bcrypt compare (`route.ts:46`). |
| 5 | No CSRF defence on state-changing endpoints | High | `src/lib/security.ts:89-113`, `src/lib/api-guard.ts:9-33` | Origin allow-list (no wildcard) for all POST/PATCH/DELETE, plus double-submit `bd_csrf` cookie ↔ `x-csrf-token` header for `/api/admin/*`. Admin routes call throttle → CSRF → session → RBAC in that order. |
| 6 | IDOR risk on owner CRUD routes | High | `src/app/api/admin/menu/[id]/route.ts:26-78`, `specials/[id]/route.ts:20-72`, `reservations/[id]/route.ts:13-42` | Every mutation requires a verified session with the write permission for that entity; IDs are validated as positive integers and updates return 404 for missing rows. No cross-tenant data exists, so ownership = the cafe itself. |
| 7 | Unvalidated public input (XSS/injection/abuse) | High | `src/lib/validation.ts:1-140` | Zod schemas for reservations, contact, login, menu items, specials, status changes and analytics filters; text passes `sanitizeText()` (strips control chars and `<`/`>`), phone/email/date/price bounded. React escapes all output; no `dangerouslySetInnerHTML` except static JSON-LD with `<` escaped. |
| 8 | Weak/absent rate limiting on APIs | High | `src/lib/security.ts:24-77`; `src/app/api/reservations/route.ts:14`; `contact/route.ts:12`; admin routes via `api-guard.ts:16-24` | Fixed-window limiter: login 5/10 min, reservations 6/h, contact 4/h, admin reads 240/min, admin writes 60/min. 429 + `Retry-After`. |
| 9 | API errors leaked internals / stack traces | Medium | `src/app/api/**/route.ts` catch blocks | All failures return generic messages (`"Could not save this menu item."`, etc.) with `Cache-Control: no-store`; no error objects are serialised. |
| 10 | Secrets had no validation and could silently be missing | High | `src/lib/env.ts:1-62`, `src/instrumentation.ts:1-17` | Zod validates env at boot; failures name only the offending variable. No secrets in client code; only `NEXT_PUBLIC_SITE_URL` is public. |
| 11 | Permissive CORS / cross-origin form abuse | High | `src/middleware.ts:19-27`; `src/lib/security.ts:79-87` | Origin allow-list built from `ALLOWED_ORIGIN`/`NEXT_PUBLIC_SITE_URL` and the request host. No `Access-Control-Allow-Origin: *` anywhere. |
| 12 | Missing browser hardening headers | High | `next.config.ts:9-40` | CSP, HSTS (production), `X-Frame-Options: DENY`, `nosniff`, `Referrer-Policy`, `Permissions-Policy`, COOP/CORP; API + admin responses are `no-store` and `noindex`. |
| 13 | Debug surface / source maps in production | Medium | `next.config.ts:43-44`; `src/instrumentation.ts:8-13` | `poweredByHeader: false`, `productionBrowserSourceMaps: false`, no debug routes; production logs a single startup line and nothing else. |
| 14 | Vulnerable dependencies in the starter lockfile | Critical | `package.json` | `npm audit` originally reported 20 advisories (1 critical, including Next.js middleware-bypass/RCE advisories). Upgraded to `next@16.4.2` + `eslint-config-next@16.4.2`, removed unused starter code. `npm audit --omit=dev` → **0 vulnerabilities**. |
| 15 | Sensitive DB fields stored in clear text | Medium | `src/lib/crypto.ts:1-33`; `src/db/seed.ts:119-127` | Admin TOTP secrets encrypted with AES-256-GCM (key derived from `AUTH_SECRET`, versioned ciphertext); passwords bcrypt-hashed; client IPs SHA-256-hashed in `login_attempts`. |
| 16 | SQL injection risk | Critical (prevented) | `src/lib/data.ts`, `src/db/schema.ts` | Drizzle ORM only — every value is parameterised; no string-concatenated SQL. Shared DB credentials kept server-side; least-privilege role SQL is documented in `README.md`. |
| 17 | Spam bots could flood reservation/contact tables | Medium | `src/lib/validation.ts:51-64`; `src/app/api/reservations/route.ts:25-30`; `contact/route.ts:22-26` | Hidden honeypot field + minimum 1.2 s fill-time, silently answered with a fake success, on top of IP rate limits. |
| 18 | Concurrency could double-seed demo data | Low | `src/db/seed.ts:129-172` | `pg_advisory_xact_lock` inside a transaction + per-table emptiness checks; seeding is idempotent. |

### Accepted residual risks (documented, not exploitable as-is)

1. **CSP allows `'unsafe-inline'` for scripts.** Next.js streams hydration data as inline scripts
   without a nonce under static/prerendered output. Moving to nonce-based CSP requires every route
   to be fully dynamic; tracked as a follow-up. `object-src 'none'`, `base-uri 'self'`,
   `frame-ancestors 'none'` and a strict `connect-src`/`img-src` allow-list still apply.
2. **Rate limiting is per-instance (in-memory).** Exact for a single server; replace `hit()` in
   `src/lib/security.ts` with Redis for multi-instance deployments.
3. **Remote imagery from `images.pexels.com`.** Explicitly allow-listed in
   `next.config.ts:49` and the CSP; no wildcard hosts.
4. **Local sandbox database uses the `postgres` superuser.** Production must use the dedicated
   least-privilege role documented in `README.md`.

---

## 2. Git history scan — what to rotate and how to purge

Scan performed in this sandbox: no `.git` directory exists, so there is no leaked history here and
nothing was committed. Before publishing your own repository:

```bash
# 1. Find committed secrets (whole history)
git log -p --all | grep -InE "(AUTH_SECRET|ADMIN_PASSWORD|DATABASE_URL|api[_-]?key|secret|token)\s*[:=]" | head -50
git log --all --name-only --pretty=format: | sort -u | grep -E '(^|/)\.env|\.pem$|\.key$'

# 2. Rotate everything that appears:
#    - PostgreSQL password (ALTER ROLE blue_door_app PASSWORD '<new>';)
#    - AUTH_SECRET  -> openssl rand -base64 48  (invalidates all admin sessions)
#    - ADMIN_PASSWORD -> change after next login
#    - ADMIN_TOTP_SECRET -> re-enrol the authenticator
#    - any third-party API token found (revoke in provider dashboard, then reissue)

# 3. Purge the history with git-filter-repo (recommended) or BFG
pip install git-filter-repo
git filter-repo --invert-paths --path .env --path .env.local
git push --force --all && git push --force --tags

# 4. Invalidate caches: GitHub → Settings → secret scanning alerts, then ask support
#    to purge cached views if a live secret was exposed for a long period.

# 5. Prevent recurrence
git secrets --install    # or gitleaks pre-commit
```

Rotation order matters: rotate the credential **before** force-pushing, then force-push, then
invalidate old sessions/tokens.

---

## 3. 14-point security checklist

| # | Requirement | Status | Evidence |
| --- | --- | --- | --- |
| 1 | Secrets in env only, `.env` ignored, `.env.example`, startup validation | ✅ | `.gitignore` (`.env`), `.env.example`, `src/lib/env.ts`, `src/instrumentation.ts` |
| 2 | Git history scanned; rotation + purge documented | ✅ | no `.git` in sandbox; procedure in section 2 |
| 3 | Admin auth: bcrypt hashes, signed httpOnly sameSite cookie with expiry, login lockout, optional 2FA | ✅ | `src/lib/auth.ts`, `src/lib/session.ts`, `src/app/api/auth/login/route.ts`, `src/lib/totp.ts` |
| 4 | Server-side route + API protection, RBAC, ownership/IDOR checks | ✅ | `src/middleware.ts`, `src/lib/auth.ts:29-46`, `src/lib/api-guard.ts`, all `/api/admin/*` routes |
| 5 | Zod validation/sanitisation on every input, escaped output, XSS/injection/CSRF + honeypot | ✅ | `src/lib/validation.ts`, `src/lib/security.ts`, forms in `src/components/home/forms.tsx` |
| 6 | Rate limiting everywhere, stricter on login/contact/reservation | ✅ | `src/lib/security.ts`, per-route limits |
| 7 | API security: auth where needed, method allow-lists, generic errors | ✅ | each route exports only supported verbs; generic catch blocks |
| 8 | CORS restricted to own domain (no wildcard) | ✅ | `src/middleware.ts:19-27`, `src/lib/security.ts:79-87` |
| 9 | CSP, HSTS, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy | ✅ | `next.config.ts:9-40` (verified live with `curl -I`) |
| 10 | Production mode: no debug, no verbose logs, no source maps | ✅ | `next.config.ts:43-44`, `src/instrumentation.ts` |
| 11 | `npm audit`, upgrades, unused code removed | ✅ | `next@16.4.2`; `npm audit --omit=dev` → 0 vulnerabilities; starter page removed |
| 12 | `.env`, `.git`, backups, config, debug routes not public; robots.txt opaque | ✅ | `.gitignore`, no `public/` copies, `src/app/robots.ts` disallows only `/api/` (does not reveal `/admin`) |
| 13 | DB least privilege, ORM/parameterised queries, no public DB, RLS or app-level checks, encrypted sensitive fields | ✅ | role SQL in `README.md`, Drizzle-only access, app-level RBAC + audit log, AES-256-GCM TOTP + bcrypt passwords + hashed IPs |
| 14 | Full OWASP audit with fixes re-verified | ✅ | section 1 + final validation run documented below |

### Final verification commands

```bash
npx next typegen            # route types
npx tsc --noEmit            # 0 type errors
npm run build               # production build
npm audit --omit=dev        # 0 vulnerabilities
bash scripts/check-security.sh
# build_and_start → /api/health returns {"ok":true}
```

---

## 4. Manual test list

**Public site**
1. Open `/` → blue door intro plays once, then hides; reload keeps it hidden for the session.
2. Scroll → progress bar fills, navbar shrinks, each section fades/slides in.
3. Toggle dark/light → whole site restyles, choice persists after reload, no flash.
4. Menu → switch category tabs, search “chai”, filter Veg / Non-veg / Vegan; clear search shows empty state.
5. Hover a menu card → lift + tilt; prices animate from ₹0 to the stored rupee value.
6. Gallery → hover zoom, click opens lightbox, arrow keys navigate, Esc closes.
7. Reviews → auto-advances every 5.5 s, pauses on hover, arrows/dots work.
8. Reserve → submit valid data → confirmation shows a `BDC-######` reference (visible in `/admin/reservations`).
9. Reserve with a 3-digit phone or past date → inline server validation errors appear.
10. Contact → submit → success panel; message appears in `/admin/reservations` → Contact messages.
11. Click phone → `tel:+919784104113`; WhatsApp button opens `wa.me`; map iframe loads address.
12. Resize to 375 px → mobile drawer animates, no horizontal scroll, map and forms usable.

**Authentication & access control**
13. Visit `/admin` while signed out → redirect to `/admin/login?next=/admin`.
14. Wrong password 5× → account locks for 15 minutes with a generic message.
15. Correct credentials → `/admin` dashboard loads; cookie is `httpOnly`, `SameSite=Lax`, `Secure` in production.
16. Sign out → session + CSRF cookies cleared; `/admin` redirects again.
17. As `viewer` role → menu/specials buttons hidden and PATCH returns 401/403.
18. POST `/api/admin/menu` without `x-csrf-token` → 403; with token → 201.
19. POST any API route with `Origin: https://evil.example` → 403.

**Dashboard**
20. Change preset 7 / 30 / 90 / 180 days → KPIs, charts, donut, bars, table update.
21. Custom date range → all views recalc; >366-day range rejected (422).
22. Toggle segment chips (dine-in/takeaway/delivery/catering) → every metric changes.
23. Switch chart metric Revenue ↔ Orders ↔ Avg ticket → line re-animates with tooltip on hover.
24. Hover a donut slice → segment grows, centre label updates.
25. Sort each table column, search a guest, filter by status, page through, export CSV.
26. Add a menu item at ₹1,250 → appears on the public menu instantly; edit price; hide → disappears; delete.
27. Publish a special → appears in “Specials of the day”; unpublish hides it.
28. Change a reservation status → persists after reload.

**Security regression**
29. `curl -I /` shows CSP, HSTS, X-Frame-Options, nosniff, Referrer-Policy, Permissions-Policy.
30. `curl /api/admin/analytics` without cookie → 401; `/admin` → 307 to login.
31. Repeated login attempts → 429 with `Retry-After`.
32. `GET /robots.txt` → only `/api/` disallowed, no admin paths; `GET /.env` and `/.git/config` → 404.
33. `npm audit --omit=dev` → 0 vulnerabilities; `bash scripts/check-security.sh` → PASSED.

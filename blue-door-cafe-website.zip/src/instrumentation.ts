/**
 * Runs once when the server boots. Validates every required environment
 * variable before the first request, so a misconfigured deployment fails fast
 * instead of leaking a half-configured app.
 */
export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const { env } = await import("@/lib/env");
    env();
    if (process.env.NODE_ENV === "production") {
      // Keep production logs minimal — no request bodies, no secrets.
      console.info("[blue-door] production mode: debug logging disabled");
    }
  }
}

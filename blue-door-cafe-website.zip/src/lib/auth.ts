import { createHash, randomUUID } from "node:crypto";
import { cookies } from "next/headers";
import { env } from "@/lib/env";
import {
  SESSION_COOKIE,
  SESSION_TTL_SECONDS,
  signSessionToken,
  verifySessionToken,
  type SessionPayload,
} from "@/lib/session";

/** Server-only session helpers (Node runtime). Edge-safe primitives live in session.ts. */

export const CSRF_COOKIE = "bd_csrf";
export const CSRF_HEADER = "x-csrf-token";

export type Role = "owner" | "manager" | "viewer";

export type AdminSession = SessionPayload & { role: Role };

const PERMISSIONS: Record<Role, ReadonlySet<string>> = {
  owner: new Set(["menu:write", "specials:write", "reservations:write", "analytics:read", "messages:read"]),
  manager: new Set(["menu:write", "specials:write", "reservations:write", "analytics:read", "messages:read"]),
  viewer: new Set(["analytics:read", "messages:read"]),
};

export function can(role: Role, permission: string): boolean {
  return PERMISSIONS[role]?.has(permission) ?? false;
}

/** Reads and verifies the signed session cookie. Returns null when absent/invalid. */
export async function getSession(): Promise<AdminSession | null> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const payload = await verifySessionToken(token, env().AUTH_SECRET);
  if (!payload) return null;
  if (!["owner", "manager", "viewer"].includes(payload.role)) return null;
  return payload as AdminSession;
}

/** Per-route authorisation. Never rely on middleware alone (defence in depth). */
export async function requireRole(permission: string): Promise<AdminSession | null> {
  const session = await getSession();
  if (!session) return null;
  return can(session.role, permission) ? session : null;
}

export async function createSessionCookie(payload: SessionPayload): Promise<void> {
  const jar = await cookies();
  const token = await signSessionToken(payload, env().AUTH_SECRET);
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_TTL_SECONDS,
  });

  // Double-submit CSRF token: readable by our own JS only, validated server-side.
  jar.set(CSRF_COOKIE, randomUUID().replaceAll("-", ""), {
    httpOnly: false,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    path: "/",
    maxAge: SESSION_TTL_SECONDS,
  });
}

export async function destroySessionCookies(): Promise<void> {
  const jar = await cookies();
  jar.delete(SESSION_COOKIE);
  jar.delete(CSRF_COOKIE);
}

/** Hashes a client IP so the lockout ledger never stores raw addresses. */
export function hashIp(ip: string): string {
  return createHash("sha256").update(`${ip}:${env().AUTH_SECRET}`).digest("hex").slice(0, 32);
}

import { env } from "@/lib/env";

/**
 * In-memory fixed-window rate limiter + CSRF helpers shared by every API route.
 * For horizontally-scaled deployments swap `hit()` for a Redis/Upstash counter —
 * the call signature is intentionally identical.
 */

type Bucket = { count: number; resetAt: number };

const buckets = new Map<string, Bucket>();
const MAX_KEYS = 5000;

function sweep(now: number) {
  if (buckets.size < MAX_KEYS) return;
  for (const [key, bucket] of buckets) {
    if (bucket.resetAt <= now) buckets.delete(key);
  }
}

export type RateLimitOptions = { key: string; limit: number; windowMs: number };

export type RateLimitResult = {
  allowed: boolean;
  remaining: number;
  retryAfter: number;
};

export function hit({ key, limit, windowMs }: RateLimitOptions): RateLimitResult {
  const now = Date.now();
  sweep(now);
  const existing = buckets.get(key);
  if (!existing || existing.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, remaining: limit - 1, retryAfter: 0 };
  }
  existing.count += 1;
  const allowed = existing.count <= limit;
  return {
    allowed,
    remaining: Math.max(0, limit - existing.count),
    retryAfter: Math.ceil((existing.resetAt - now) / 1000),
  };
}

/** Coarse client identifier — never trusted for authorisation, only throttling. */
export function clientIp(headers: Headers): string {
  const forwarded = headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0]!.trim().slice(0, 45);
  return headers.get("x-real-ip")?.slice(0, 45) ?? "local";
}

/** Applies a bucket and returns a 429 response when exceeded. */
export function rateLimit(
  headers: Headers,
  bucket: string,
  limit: number,
  windowMs: number,
): { response: Response | null; retryAfter: number } {
  const result = hit({ key: `${bucket}:${clientIp(headers)}`, limit, windowMs });
  if (result.allowed) return { response: null, retryAfter: 0 };
  return {
    response: Response.json(
      { error: "Too many requests. Please try again shortly." },
      {
        status: 429,
        headers: {
          "Retry-After": String(result.retryAfter),
          "Cache-Control": "no-store",
        },
      },
    ),
    retryAfter: result.retryAfter,
  };
}

/** Restricts cross-origin calls to our own deployment (never "*"). */
export function allowedOrigins(headers: Headers): string[] {
  const configured = env().ALLOWED_ORIGIN ?? env().NEXT_PUBLIC_SITE_URL;
  const origins = new Set<string>([configured]);
  // Include the deployment's own host (direct + reverse-proxied) so previews and
  // custom domains work without ever allowing a third-party origin.
  for (const host of [headers.get("x-forwarded-host"), headers.get("host")]) {
    if (!host) continue;
    const clean = host.split(",")[0]!.trim().replace(/:\d+$/, "");
    if (!clean) continue;
    origins.add(`https://${clean}`);
    origins.add(`http://${clean}`);
  }
  return [...origins];
}

/**
 * CSRF defence: state-changing requests must come from an allow-listed origin
 * and present the double-submit token issued at login.
 */
export async function assertCsrf(request: Request): Promise<Response | null> {
  const method = request.method.toUpperCase();
  if (["GET", "HEAD", "OPTIONS"].includes(method)) return null;

  const origin = request.headers.get("origin");
  if (!origin || !allowedOrigins(request.headers).includes(origin)) {
    return Response.json({ error: "Request rejected." }, { status: 403 });
  }

  // Only authenticated admin mutations carry the CSRF header/cookie pair.
  if (new URL(request.url).pathname.startsWith("/api/admin")) {
    const header = request.headers.get("x-csrf-token");
    const cookie = parseCookie(request.headers.get("cookie"), "bd_csrf");
    if (!header || !cookie || header !== cookie) {
      return Response.json({ error: "Request rejected." }, { status: 403 });
    }
  }
  return null;
}

export function parseCookie(header: string | null, name: string): string | null {
  if (!header) return null;
  for (const part of header.split(";")) {
    const [key, ...rest] = part.trim().split("=");
    if (key === name) return decodeURIComponent(rest.join("="));
  }
  return null;
}

/** Generic API error — never leaks stack traces or database internals. */
export function apiError(status = 400, message = "Something went wrong."): Response {
  return Response.json({ error: message }, { status, headers: { "Cache-Control": "no-store" } });
}

/** Removes control characters and angle brackets from free-text input. */
export function sanitizeText(value: string): string {
  return value
    .replace(/[\u0000-\u001F\u007F]/g, " ")
    .replace(/[<>]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

"use client";

import {
  AnimatePresence,
  motion,
  useMotionValue,
  useReducedMotion,
  useScroll,
  useSpring,
  useMotionValueEvent,
} from "framer-motion";
import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { ThemeToggle } from "@/components/theme-provider";
import { RippleLink } from "@/components/motion-primitives";
import { CAFE } from "@/lib/format";

const NAV_LINKS = [
  { label: "Story", href: "#about" },
  { label: "Menu", href: "#menu" },
  { label: "Specials", href: "#specials" },
  { label: "Gallery", href: "#gallery" },
  { label: "Reviews", href: "#reviews" },
  { label: "Visit", href: "#visit" },
];

/** Brand mark: an arched blue door drawn with SVG. */
export function DoorMark({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 56" className={className} aria-hidden="true" fill="none">
      <path d="M4 54V20C4 9.5 12.5 2 24 2s20 7.5 20 18v34" stroke="currentColor" strokeWidth="2.4" />
      <path d="M12 54V22c0-6.6 5.4-12 12-12s12 5.4 12 12v32" fill="currentColor" opacity="0.16" />
      <path d="M24 10v44M12 54h24" stroke="currentColor" strokeWidth="1.4" opacity="0.7" />
      <circle cx="29" cy="34" r="1.8" fill="currentColor" />
    </svg>
  );
}

/** Blue door that swings open once per browsing session, with a loader. */
export function DoorIntro() {
  const reduce = useReducedMotion();
  const [visible, setVisible] = useState(true);
  const [open, setOpen] = useState(false);
  const [progress, setProgress] = useState(8);

  useEffect(() => {
    if (sessionStorage.getItem("bd-intro-seen") === "1") {
      const dismiss = window.setTimeout(() => setVisible(false), 0);
      return () => window.clearTimeout(dismiss);
    }
    const progressTimer = window.setInterval(() => {
      setProgress((p) => Math.min(100, p + Math.ceil(Math.random() * 17)));
    }, 160);
    const openTimer = window.setTimeout(() => setOpen(true), reduce ? 200 : 1150);
    const closeTimer = window.setTimeout(
      () => {
        sessionStorage.setItem("bd-intro-seen", "1");
        setVisible(false);
      },
      reduce ? 400 : 2050,
    );
    return () => {
      window.clearInterval(progressTimer);
      window.clearTimeout(openTimer);
      window.clearTimeout(closeTimer);
    };
  }, [reduce]);

  if (!visible) return null;

  return (
    <motion.div
      className="fixed inset-0 z-[100] flex items-center justify-center overflow-hidden bg-[#0a1f33]"
      initial={{ opacity: 1 }}
      animate={{ opacity: open ? 0 : 1 }}
      transition={{ duration: 0.6, delay: reduce ? 0 : 0.55 }}
      aria-hidden="true"
    >
      <div className="absolute inset-0 grain opacity-60" />
      <div className="relative z-10 flex flex-col items-center">
        <div className="relative h-44 w-32 [perspective:900px] sm:h-52 sm:w-36">
          <div className="absolute inset-0 arch border-2 border-[#3c6c94]" />
          <motion.div
            className="absolute inset-y-0 left-0 w-1/2 origin-left rounded-tl-[14rem] border-2 border-[#4d82ad] bg-gradient-to-b from-[#1b4e7a] to-[#123b63]"
            animate={{ rotateY: open ? -105 : 0 }}
            transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          >
            <span className="absolute right-2 top-1/2 h-2 w-2 rounded-full bg-[#c99a44]" />
            <span className="absolute inset-3 rounded-tl-[10rem] border border-[#4d82ad]/60" />
          </motion.div>
          <motion.div
            className="absolute inset-y-0 right-0 w-1/2 origin-right rounded-tr-[14rem] border-2 border-[#4d82ad] bg-gradient-to-b from-[#1b4e7a] to-[#123b63]"
            animate={{ rotateY: open ? 105 : 0 }}
            transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          >
            <span className="absolute left-2 top-1/2 h-2 w-2 rounded-full bg-[#c99a44]" />
            <span className="absolute inset-3 rounded-tr-[10rem] border border-[#4d82ad]/60" />
          </motion.div>
        </div>
        <p className="mt-8 font-display text-2xl tracking-tight text-[#fbf6ec]">Blue Door Cafe</p>
        <p className="mt-1 text-[10px] uppercase tracking-[0.4em] text-[#9fb8cc]">Gangori Bazaar · Jaipur</p>
        <div className="mt-6 h-[3px] w-40 overflow-hidden rounded-full bg-white/15">
          <motion.div
            className="h-full rounded-full bg-[#c99a44]"
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>
      </div>
    </motion.div>
  );
}

/** Top scroll-progress bar. */
export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 24, restDelta: 0.001 });

  return (
    <motion.div
      className="fixed inset-x-0 top-0 z-[80] h-[3px] origin-left bg-gradient-to-r from-jaipur via-gold to-brand"
      style={{ scaleX }}
      aria-hidden="true"
    />
  );
}

/** Desktop-only spring cursor with hover growth. */
export function CustomCursor() {
  const reduce = useReducedMotion();
  const [enabled, setEnabled] = useState(false);
  const [hovering, setHovering] = useState(false);
  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const springX = useSpring(x, { stiffness: 380, damping: 34, mass: 0.35 });
  const springY = useSpring(y, { stiffness: 380, damping: 34, mass: 0.35 });

  useEffect(() => {
    if (reduce) return;
    const finePointer = window.matchMedia("(pointer: fine)").matches;
    if (!finePointer) return;
    const enableTimer = window.setTimeout(() => setEnabled(true), 0);

    const move = (event: PointerEvent) => {
      x.set(event.clientX);
      y.set(event.clientY);
      const target = event.target as HTMLElement | null;
      setHovering(Boolean(target?.closest("a,button,[data-cursor='grow']")));
    };
    window.addEventListener("pointermove", move, { passive: true });
    return () => {
      window.clearTimeout(enableTimer);
      window.removeEventListener("pointermove", move);
    };
  }, [reduce, x, y]);

  if (!enabled) return null;

  return (
    <>
      <motion.div
        aria-hidden="true"
        className="pointer-events-none fixed left-0 top-0 z-[90] h-2 w-2 rounded-full bg-brand mix-blend-difference"
        style={{ x, y, translateX: "-50%", translateY: "-50%" }}
      />
      <motion.div
        aria-hidden="true"
        className="pointer-events-none fixed left-0 top-0 z-[90] rounded-full border border-jaipur/70"
        style={{ x: springX, y: springY, translateX: "-50%", translateY: "-50%" }}
        animate={{ width: hovering ? 46 : 26, height: hovering ? 46 : 26, opacity: hovering ? 1 : 0.6 }}
        transition={{ duration: 0.2 }}
      />
    </>
  );
}

/** Sticky navbar that shrinks after scrolling, with an animated mobile drawer. */
export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const { scrollY } = useScroll();
  const reduce = useReducedMotion();

  useMotionValueEvent(scrollY, "change", (latest) => setScrolled(latest > 32));

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  const shell = useMemo(
    () =>
      scrolled
        ? "border-line/70 bg-surface/85 backdrop-blur-xl py-2 shadow-warm"
        : "border-transparent bg-transparent py-4",
    [scrolled],
  );
  const onDark = !scrolled;
  const wordmark = onDark ? "text-[#fbf6ec]" : "text-ink";
  const sublabel = onDark ? "text-[#a9c0d3]" : "text-muted";
  const navLink = onDark
    ? "text-[#e2dccf] hover:text-white"
    : "text-muted hover:text-ink";
  const outlineBtn = onDark
    ? "border-white/25 text-[#fbf6ec] hover:border-white/60"
    : "border-line text-ink hover:border-brand/50";

  return (
    <motion.header
      className={`fixed inset-x-0 top-0 z-[70] border-b transition-colors duration-300 ${shell}`}
      initial={reduce ? false : { y: -70, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8" aria-label="Main">
        <Link href="/" className="group flex items-center gap-3" aria-label="Blue Door Cafe home">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand text-[#fbf6ec] transition-transform duration-300 group-hover:-rotate-6">
            <DoorMark className="h-7 w-7" />
          </span>
          <span className="leading-none">
            <span className={`block font-display text-lg tracking-tight ${wordmark}`}>Blue Door</span>
            <span className={`block text-[9px] font-semibold uppercase tracking-[0.32em] ${sublabel}`}>Cafe · Jaipur</span>
          </span>
        </Link>

        <ul className="hidden items-center gap-1 lg:flex">
          {NAV_LINKS.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className={`relative rounded-full px-3 py-2 text-[13px] font-medium transition-colors ${navLink}`}
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <a
            href={CAFE.phoneHref}
            className={`hidden rounded-full border px-3 py-2 text-[12px] font-semibold transition-colors sm:block ${outlineBtn}`}
          >
            {CAFE.phoneDisplay}
          </a>
          <ThemeToggle />
          <RippleLink href="#reserve" className="hidden !px-4 !py-2 !text-[13px] sm:inline-flex">
            Reserve
          </RippleLink>
          <button
            type="button"
            className={`flex h-10 w-10 items-center justify-center rounded-full border lg:hidden ${outlineBtn}`}
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((value) => !value)}
          >
            <span className="relative block h-3 w-5">
              <motion.span
                className="absolute left-0 block h-[2px] w-5 rounded bg-current"
                animate={menuOpen ? { rotate: 45, y: 5 } : { rotate: 0, y: 0 }}
              />
              <motion.span
                className="absolute left-0 top-[5px] block h-[2px] w-5 rounded bg-current"
                animate={menuOpen ? { opacity: 0 } : { opacity: 1 }}
              />
              <motion.span
                className="absolute left-0 top-[10px] block h-[2px] w-5 rounded bg-current"
                animate={menuOpen ? { rotate: -45, y: -5 } : { rotate: 0, y: 0 }}
              />
            </span>
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {menuOpen ? (
          <motion.div
            className="fixed inset-x-0 top-[68px] z-[69] mx-4 overflow-hidden rounded-3xl border border-line bg-surface p-6 shadow-warm lg:hidden"
            initial={{ opacity: 0, y: -12, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -12, scale: 0.98 }}
            transition={{ duration: 0.25 }}
          >
            <ul className="space-y-1">
              {NAV_LINKS.map((link, index) => (
                <motion.li
                  key={link.href}
                  initial={{ opacity: 0, x: -16 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 + index * 0.045 }}
                >
                  <a
                    href={link.href}
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center justify-between border-b border-line/70 py-3 font-display text-xl text-ink"
                  >
                    {link.label}
                    <span aria-hidden="true" className="text-jaipur">→</span>
                  </a>
                </motion.li>
              ))}
            </ul>
            <div className="mt-5 flex flex-wrap gap-3">
              <a
                href={CAFE.phoneHref}
                className="rounded-full border border-line px-4 py-2 text-sm font-semibold text-ink"
              >
                Call {CAFE.phoneDisplay}
              </a>
              <a
                href={CAFE.whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="rounded-full bg-[#1f7a4d] px-4 py-2 text-sm font-semibold text-white"
              >
                WhatsApp
              </a>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </motion.header>
  );
}

import { guardAdmin, noStoreJson } from "@/lib/api-guard";
import { getAnalytics } from "@/lib/data";
import { analyticsQuerySchema } from "@/lib/validation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const guard = await guardAdmin(request, "analytics:read");
  if (guard.response) return guard.response;

  const url = new URL(request.url);
  const parsed = analyticsQuerySchema.safeParse({
    from: url.searchParams.get("from") ?? "",
    to: url.searchParams.get("to") ?? "",
    segments: url.searchParams.get("segments") ?? "",
  });

  if (!parsed.success) {
    return noStoreJson({ error: "Invalid filters." }, 422);
  }

  const { from, to, segments } = parsed.data;
  const fromDate = new Date(`${from}T00:00:00.000Z`);
  const toDate = new Date(`${to}T00:00:00.000Z`);
  const spanDays = Math.round((toDate.getTime() - fromDate.getTime()) / 86_400_000) + 1;
  if (Number.isNaN(spanDays) || spanDays < 1 || spanDays > 366) {
    return noStoreJson({ error: "Choose a range between 1 and 366 days." }, 422);
  }

  try {
    const payload = await getAnalytics({ from, to, segments });
    return noStoreJson({ ...payload, generatedAt: new Date().toISOString() });
  } catch {
    return noStoreJson({ error: "Analytics are unavailable right now." }, 500);
  }
}

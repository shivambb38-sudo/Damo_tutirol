"use client";

/** Browser-side API helper: sends the double-submit CSRF token on mutations. */
export function csrfToken(): string {
  if (typeof document === "undefined") return "";
  const cookie = document.cookie
    .split("; ")
    .find((part) => part.startsWith("bd_csrf="));
  return cookie ? cookie.split("=").slice(1).join("=") : "";
}

export async function apiRequest<T>(
  url: string,
  options: { method?: "GET" | "POST" | "PATCH" | "DELETE"; body?: unknown } = {},
): Promise<{ ok: boolean; status: number; data: T & { error?: string; fields?: { field: string; message: string }[] } }> {
  const method = options.method ?? "GET";
  const response = await fetch(url, {
    method,
    credentials: "same-origin",
    headers: {
      ...(options.body ? { "Content-Type": "application/json" } : {}),
      ...(method === "GET" ? {} : { "x-csrf-token": csrfToken() }),
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });

  let data: unknown = {};
  try {
    data = await response.json();
  } catch {
    data = {};
  }
  return { ok: response.ok, status: response.status, data: data as T & { error?: string } };
}

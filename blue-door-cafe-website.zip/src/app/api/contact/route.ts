import { db } from "@/db";
import { contactMessages } from "@/db/schema";
import { assertCsrf, rateLimit } from "@/lib/security";
import { contactSchema, parseJson } from "@/lib/validation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MIN_FORM_MS = 1200;

export async function POST(request: Request) {
  const limited = rateLimit(request.headers, "public:contact", 4, 60 * 60 * 1000);
  if (limited.response) return limited.response;

  const csrf = await assertCsrf(request);
  if (csrf) return csrf;

  const parsed = await parseJson(request, contactSchema);
  if (!parsed.ok) return parsed.response;

  const data = parsed.data;
  const filledTooFast = data.formStartedAt ? Date.now() - data.formStartedAt < MIN_FORM_MS : false;
  if (data.website || filledTooFast) {
    return Response.json({ ok: true }, { status: 202 });
  }

  try {
    await db.insert(contactMessages).values({
      name: data.name,
      email: data.email,
      phone: data.phone || null,
      subject: data.subject,
      message: data.message,
      status: "new",
    });
    return Response.json({ ok: true }, { status: 201, headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json(
      { error: "Could not send your message. Please call us on 97841 04113." },
      { status: 500, headers: { "Cache-Control": "no-store" } },
    );
  }
}

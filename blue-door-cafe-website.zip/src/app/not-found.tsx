import Link from "next/link";

export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-surface px-6 text-center">
      <p className="font-display text-6xl text-brand">404</p>
      <h1 className="mt-4 font-display text-2xl text-ink">This page is behind a different door.</h1>
      <p className="mt-2 max-w-sm text-sm text-muted">
        The page you were looking for has moved. The coffee, happily, has not.
      </p>
      <Link href="/" className="mt-6 rounded-full bg-brand px-5 py-2.5 text-sm font-semibold text-white">
        Back to Blue Door Cafe
      </Link>
    </main>
  );
}

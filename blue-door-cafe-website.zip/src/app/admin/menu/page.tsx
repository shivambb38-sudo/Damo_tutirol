import { redirect } from "next/navigation";
import { MenuManager } from "@/components/admin/menu-manager";
import { can, getSession } from "@/lib/auth";
import { getMenu } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function AdminMenuPage() {
  const session = await getSession();
  if (!session) redirect("/admin/login");
  if (!can(session.role, "menu:write") && !can(session.role, "analytics:read")) redirect("/admin");

  const { categories, items } = await getMenu();
  return (
    <MenuManager
      categories={categories}
      initialItems={items}
      canWrite={can(session.role, "menu:write")}
    />
  );
}

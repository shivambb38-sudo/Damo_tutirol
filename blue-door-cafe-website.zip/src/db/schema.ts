/**
 * Drizzle schema for Blue Door Cafe.
 *
 * All money is stored as whole Indian Rupees (integers) — never floats — so
 * totals stay exact. Access is exclusively through Drizzle's parameterised
 * query builder, which prevents SQL injection.
 */
import {
  boolean,
  date,
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/** Admin accounts. Roles are enforced server-side on every request. */
export const adminUsers = pgTable(
  "admin_users",
  {
    id: serial("id").primaryKey(),
    email: text("email").notNull(),
    passwordHash: text("password_hash").notNull(),
    role: text("role").notNull().default("owner"), // owner | manager | viewer
    totpSecret: text("totp_secret"), // optional 2FA, stored encrypted-at-rest by the operator
    lockedUntil: timestamp("locked_until", { withTimezone: true }),
    failedAttempts: integer("failed_attempts").notNull().default(0),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("admin_users_email_idx").on(table.email)],
);

/** Append-only login attempt ledger, used for lockout + abuse review. */
export const loginAttempts = pgTable(
  "login_attempts",
  {
    id: serial("id").primaryKey(),
    email: text("email").notNull(),
    ipHash: text("ip_hash").notNull(),
    success: boolean("success").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("login_attempts_created_idx").on(table.createdAt)],
);

/** Admin action audit trail (who changed what). */
export const auditLog = pgTable("audit_log", {
  id: serial("id").primaryKey(),
  actorId: integer("actor_id").notNull(),
  action: text("action").notNull(),
  entity: text("entity").notNull(),
  entityId: text("entity_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const menuCategories = pgTable(
  "menu_categories",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    blurb: text("blurb").notNull().default(""),
    sortOrder: integer("sort_order").notNull().default(0),
  },
  (table) => [uniqueIndex("menu_categories_slug_idx").on(table.slug)],
);

export const menuItems = pgTable(
  "menu_items",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    description: text("description").notNull().default(""),
    priceInr: integer("price_inr").notNull(),
    categorySlug: text("category_slug").notNull(),
    diet: text("diet").notNull().default("veg"), // veg | nonveg | vegan
    available: boolean("available").notNull().default(true),
    signature: boolean("signature").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("menu_items_category_idx").on(table.categorySlug)],
);

export const specials = pgTable("specials", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  priceInr: integer("price_inr").notNull(),
  badge: text("badge").notNull().default("Chef's pick"),
  active: boolean("active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const reservations = pgTable(
  "reservations",
  {
    id: serial("id").primaryKey(),
    reference: text("reference").notNull(),
    name: text("name").notNull(),
    phone: text("phone").notNull(),
    email: text("email"),
    guests: integer("guests").notNull(),
    reservationDate: date("reservation_date").notNull(),
    reservationTime: text("reservation_time").notNull(),
    notes: text("notes"),
    status: text("status").notNull().default("pending"), // pending | confirmed | seated | cancelled
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("reservations_reference_idx").on(table.reference),
    index("reservations_date_idx").on(table.reservationDate),
  ],
);

export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  status: text("status").notNull().default("new"), // new | read | archived
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  guestName: text("guest_name").notNull(),
  rating: integer("rating").notNull(),
  quote: text("quote").notNull(),
  source: text("source").notNull().default("Google"),
  featured: boolean("featured").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/**
 * Analytics fact table. `channel` doubles as the dashboard "segment" filter.
 * Sample rows are generated deterministically by src/db/seed.ts.
 */
export const orders = pgTable(
  "orders",
  {
    id: serial("id").primaryKey(),
    reference: text("reference").notNull(),
    orderedAt: timestamp("ordered_at", { withTimezone: true }).notNull(),
    channel: text("channel").notNull(), // dine-in | takeaway | delivery | catering
    customerName: text("customer_name").notNull(),
    itemsCount: integer("items_count").notNull().default(1),
    totalInr: integer("total_inr").notNull(),
    returningGuest: boolean("returning_guest").notNull().default(false),
    status: text("status").notNull().default("completed"), // completed | refunded | pending
  },
  (table) => [
    uniqueIndex("orders_reference_idx").on(table.reference),
    index("orders_ordered_at_idx").on(table.orderedAt),
    index("orders_channel_idx").on(table.channel),
  ],
);

export const orderItems = pgTable(
  "order_items",
  {
    id: serial("id").primaryKey(),
    orderId: integer("order_id")
      .notNull()
      .references(() => orders.id, { onDelete: "cascade" }),
    itemName: text("item_name").notNull(),
    categorySlug: text("category_slug").notNull(),
    quantity: integer("quantity").notNull(),
    unitPriceInr: integer("unit_price_inr").notNull(),
  },
  (table) => [
    index("order_items_order_idx").on(table.orderId),
    index("order_items_category_idx").on(table.categorySlug),
  ],
);

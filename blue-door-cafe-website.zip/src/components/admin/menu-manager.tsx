"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import { apiRequest } from "@/lib/client-api";
import { formatINR } from "@/lib/format";
import type { CategoryRow, MenuItemRow } from "@/lib/data";

const inputClass =
  "w-full rounded-xl border border-line bg-surface px-3 py-2 text-sm text-ink focus:border-brand focus:outline-none";
const labelClass = "mb-1 block text-[10px] font-semibold uppercase tracking-[0.16em] text-muted";

type Draft = {
  id?: number;
  name: string;
  description: string;
  priceInr: number;
  categorySlug: string;
  diet: "veg" | "nonveg" | "vegan";
  available: boolean;
  signature: boolean;
};

const emptyDraft = (categorySlug: string): Draft => ({
  name: "",
  description: "",
  priceInr: 150,
  categorySlug,
  diet: "veg",
  available: true,
  signature: false,
});

export function MenuManager({
  categories,
  initialItems,
  canWrite,
}: {
  categories: CategoryRow[];
  initialItems: MenuItemRow[];
  canWrite: boolean;
}) {
  const [items, setItems] = useState(initialItems);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return items.filter((item) => {
      if (category !== "all" && item.categorySlug !== category) return false;
      if (!needle) return true;
      return `${item.name} ${item.description}`.toLowerCase().includes(needle);
    });
  }, [category, items, query]);

  async function save() {
    if (!draft) return;
    setBusy(true);
    setError("");
    const payload = {
      name: draft.name,
      description: draft.description,
      priceInr: draft.priceInr,
      categorySlug: draft.categorySlug,
      diet: draft.diet,
      available: draft.available,
      signature: draft.signature,
    };

    const result = draft.id
      ? await apiRequest<{ item: MenuItemRow }>(`/api/admin/menu/${draft.id}`, { method: "PATCH", body: payload })
      : await apiRequest<{ item: MenuItemRow }>("/api/admin/menu", { method: "POST", body: payload });

    setBusy(false);
    if (!result.ok || !result.data.item) {
      setError(result.data.error ?? "Please check the fields and try again.");
      return;
    }
    const saved = result.data.item;
    setItems((current) =>
      draft.id ? current.map((item) => (item.id === saved.id ? saved : item)) : [saved, ...current],
    );
    setDraft(null);
  }

  async function patch(id: number, body: Partial<MenuItemRow>) {
    const result = await apiRequest<{ item: MenuItemRow }>(`/api/admin/menu/${id}`, { method: "PATCH", body });
    if (result.ok && result.data.item) {
      const updated = result.data.item;
      setItems((current) => current.map((item) => (item.id === updated.id ? updated : item)));
    }
  }

  async function remove(id: number) {
    if (!window.confirm("Delete this menu item permanently?")) return;
    const result = await apiRequest<{ ok: boolean }>(`/api/admin/menu/${id}`, { method: "DELETE" });
    if (result.ok) setItems((current) => current.filter((item) => item.id !== id));
    else setError(result.data.error ?? "Could not delete this item.");
  }

  const categoryName = (slug: string) => categories.find((entry) => entry.slug === slug)?.name ?? slug;

  return (
    <div className="pb-16">
      <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-[0.28em] text-brand">Menu management</p>
          <h1 className="mt-2 font-display text-3xl tracking-tight text-ink">Dishes & prices</h1>
          <p className="mt-1 text-sm text-muted">
            {items.length} items across {categories.length} categories. Prices are whole rupees and appear on the live site instantly.
          </p>
        </div>
        {canWrite ? (
          <button
            type="button"
            onClick={() => setDraft(emptyDraft(categories[0]?.slug ?? "chai-coffee"))}
            className="rounded-full bg-brand px-4 py-2.5 text-xs font-semibold text-white hover:bg-brand-soft"
          >
            + Add menu item
          </button>
        ) : null}
      </header>

      <div className="mt-5 flex flex-col gap-2 sm:flex-row sm:items-center">
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value.slice(0, 60))}
          placeholder="Search dishes…"
          className="w-full rounded-full border border-line bg-card px-4 py-2 text-sm text-ink sm:max-w-xs"
          aria-label="Search menu items"
        />
        <select
          value={category}
          onChange={(event) => setCategory(event.target.value)}
          aria-label="Filter by category"
          className="rounded-full border border-line bg-card px-3 py-2 text-sm text-ink"
        >
          <option value="all">All categories</option>
          {categories.map((entry) => (
            <option key={entry.slug} value={entry.slug}>{entry.name}</option>
          ))}
        </select>
      </div>

      {error ? (
        <p role="alert" className="mt-3 rounded-xl border border-[#b3261e]/30 bg-[#b3261e]/5 px-3 py-2 text-xs text-[#8d1d17] dark:text-[#f0a9a2]">
          {error}
        </p>
      ) : null}

      <div className="mt-4 overflow-x-auto rounded-3xl border border-line bg-card">
        <table className="w-full min-w-[720px] border-collapse text-left text-xs">
          <thead>
            <tr className="border-b border-line text-[10px] uppercase tracking-[0.14em] text-muted">
              <th className="px-4 py-3 font-semibold">Item</th>
              <th className="px-4 py-3 font-semibold">Category</th>
              <th className="px-4 py-3 font-semibold">Diet</th>
              <th className="px-4 py-3 font-semibold">Price</th>
              <th className="px-4 py-3 font-semibold">Status</th>
              <th className="px-4 py-3 text-right font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((item) => (
              <tr key={item.id} className="border-b border-line/60 last:border-0 hover:bg-surface-2/50">
                <td className="px-4 py-3">
                  <p className="font-semibold text-ink">{item.name}</p>
                  <p className="max-w-sm truncate text-[10px] text-muted">{item.description}</p>
                </td>
                <td className="px-4 py-3 text-muted">{categoryName(item.categorySlug)}</td>
                <td className="px-4 py-3 text-muted capitalize">{item.diet}</td>
                <td className="px-4 py-3 font-semibold text-ink">{formatINR(item.priceInr)}</td>
                <td className="px-4 py-3">
                  <span
                    className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                      item.available
                        ? "bg-[#2f7d5a]/12 text-[#1f6a4a] dark:text-[#7fd3ab]"
                        : "bg-jaipur/15 text-[#96394a] dark:text-[#f0a3b0]"
                    }`}
                  >
                    {item.available ? "Available" : "Hidden"}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-1.5">
                    {canWrite ? (
                      <>
                        <button
                          type="button"
                          onClick={() => patch(item.id, { available: !item.available })}
                          className="rounded-full border border-line px-2.5 py-1 text-[10px] font-semibold text-ink"
                        >
                          {item.available ? "Hide" : "Publish"}
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setDraft({
                              id: item.id,
                              name: item.name,
                              description: item.description,
                              priceInr: item.priceInr,
                              categorySlug: item.categorySlug,
                              diet: (item.diet as Draft["diet"]) ?? "veg",
                              available: item.available,
                              signature: item.signature,
                            })
                          }
                          className="rounded-full border border-line px-2.5 py-1 text-[10px] font-semibold text-ink"
                        >
                          Edit
                        </button>
                        <button
                          type="button"
                          onClick={() => remove(item.id)}
                          className="rounded-full border border-jaipur/40 px-2.5 py-1 text-[10px] font-semibold text-jaipur"
                        >
                          Delete
                        </button>
                      </>
                    ) : (
                      <span className="text-[10px] text-muted">Read-only role</span>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 ? <p className="py-10 text-center text-xs text-muted">No items match this filter.</p> : null}
      </div>

      <AnimatePresence>
        {draft ? (
          <motion.div
            className="fixed inset-0 z-[85] flex items-end justify-center bg-[#04121f]/60 p-0 backdrop-blur-sm sm:items-center sm:p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setDraft(null)}
          >
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-label={draft.id ? "Edit menu item" : "Add menu item"}
              className="max-h-[92vh] w-full overflow-y-auto rounded-t-3xl border border-line bg-card p-6 shadow-warm sm:max-w-lg sm:rounded-3xl"
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 40, opacity: 0 }}
              transition={{ duration: 0.3 }}
              onClick={(event) => event.stopPropagation()}
            >
              <div className="flex items-start justify-between">
                <h2 className="font-display text-2xl text-ink">{draft.id ? "Edit item" : "New menu item"}</h2>
                <button type="button" onClick={() => setDraft(null)} aria-label="Close" className="text-muted hover:text-ink">
                  ✕
                </button>
              </div>

              <div className="mt-5 space-y-4">
                <div>
                  <label className={labelClass} htmlFor="item-name">Name</label>
                  <input
                    id="item-name"
                    value={draft.name}
                    maxLength={80}
                    onChange={(event) => setDraft({ ...draft, name: event.target.value })}
                    className={inputClass}
                    placeholder="Kadak Masala Chai"
                  />
                </div>
                <div>
                  <label className={labelClass} htmlFor="item-desc">Description</label>
                  <textarea
                    id="item-desc"
                    value={draft.description}
                    maxLength={240}
                    rows={3}
                    onChange={(event) => setDraft({ ...draft, description: event.target.value })}
                    className={inputClass}
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className={labelClass} htmlFor="item-price">Price (₹)</label>
                    <input
                      id="item-price"
                      type="number"
                      min={10}
                      max={100000}
                      value={draft.priceInr}
                      onChange={(event) => setDraft({ ...draft, priceInr: Number(event.target.value) })}
                      className={inputClass}
                    />
                  </div>
                  <div>
                    <label className={labelClass} htmlFor="item-category">Category</label>
                    <select
                      id="item-category"
                      value={draft.categorySlug}
                      onChange={(event) => setDraft({ ...draft, categorySlug: event.target.value })}
                      className={inputClass}
                    >
                      {categories.map((entry) => (
                        <option key={entry.slug} value={entry.slug}>{entry.name}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className={labelClass} htmlFor="item-diet">Diet</label>
                    <select
                      id="item-diet"
                      value={draft.diet}
                      onChange={(event) => setDraft({ ...draft, diet: event.target.value as Draft["diet"] })}
                      className={inputClass}
                    >
                      <option value="veg">Vegetarian</option>
                      <option value="nonveg">Non-vegetarian</option>
                      <option value="vegan">Vegan</option>
                    </select>
                  </div>
                  <div className="flex flex-col justify-end gap-2 pb-1">
                    <label className="flex items-center gap-2 text-xs text-ink">
                      <input
                        type="checkbox"
                        checked={draft.available}
                        onChange={(event) => setDraft({ ...draft, available: event.target.checked })}
                      />
                      Available
                    </label>
                    <label className="flex items-center gap-2 text-xs text-ink">
                      <input
                        type="checkbox"
                        checked={draft.signature}
                        onChange={(event) => setDraft({ ...draft, signature: event.target.checked })}
                      />
                      Signature dish
                    </label>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex justify-end gap-2 border-t border-line pt-4">
                <button type="button" onClick={() => setDraft(null)} className="rounded-full border border-line px-4 py-2 text-xs font-semibold text-ink">
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={save}
                  disabled={busy}
                  className="rounded-full bg-brand px-5 py-2 text-xs font-semibold text-white disabled:opacity-60"
                >
                  {busy ? "Saving…" : draft.id ? "Save changes" : "Add item"}
                </button>
              </div>
            </motion.div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  );
}

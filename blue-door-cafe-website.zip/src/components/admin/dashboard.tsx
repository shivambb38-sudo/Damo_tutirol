"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useEffect, useMemo, useRef, useState } from "react";
import { DonutChart, Sparkline, TrendLineChart, WeekdayBarChart } from "@/components/admin/charts";
import { apiRequest } from "@/lib/client-api";
import { formatCompactINR, formatDateShort, formatINR, formatNumber, formatPercent } from "@/lib/format";
import type { AnalyticsPayload, Kpi } from "@/lib/data";

type SortKey = "reference" | "orderedAt" | "customerName" | "channel" | "itemsCount" | "totalInr" | "status";

const PRESETS = [
  { key: "7", label: "7 days", days: 7 },
  { key: "30", label: "30 days", days: 30 },
  { key: "90", label: "90 days", days: 90 },
  { key: "180", label: "6 months", days: 180 },
] as const;

const SEGMENT_LABELS: Record<string, string> = {
  "dine-in": "Dine-in",
  takeaway: "Takeaway",
  delivery: "Delivery",
  catering: "Catering",
};

const STATUS_STYLES: Record<string, string> = {
  completed: "bg-[#2f7d5a]/12 text-[#1f6a4a] dark:text-[#7fd3ab]",
  pending: "bg-gold/15 text-[#8a621b] dark:text-[#e6c07a]",
  refunded: "bg-jaipur/15 text-[#96394a] dark:text-[#f0a3b0]",
};

function isoDaysAgo(days: number): string {
  const date = new Date();
  date.setUTCDate(date.getUTCDate() - (days - 1));
  return date.toISOString().slice(0, 10);
}

function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

function formatSlot(iso: string): string {
  return new Intl.DateTimeFormat("en-IN", {
    day: "2-digit",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
    timeZone: "Asia/Kolkata",
  }).format(new Date(iso));
}

function KpiValue({ kpi }: { kpi: Kpi }) {
  const reduce = useReducedMotion();
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    // Animation runs in rAF so no state is set synchronously during the effect.
    let frame = 0;
    let start: number | null = null;
    const duration = reduce ? 0 : 750;
    const tick = (now: number) => {
      if (start === null) start = now;
      const progress = duration === 0 ? 1 : Math.min(1, (now - start) / duration);
      setDisplay(kpi.value * (1 - Math.pow(1 - progress, 3)));
      if (progress < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [kpi.value, reduce]);

  if (kpi.format === "currency") return <>{formatINR(Math.round(display))}</>;
  if (kpi.format === "percent") return <>{display.toFixed(1)}%</>;
  return <>{formatNumber(Math.round(display))}</>;
}

export function Dashboard({ initial, role }: { initial: AnalyticsPayload; role: string }) {
  const reduce = useReducedMotion();
  const [data, setData] = useState<AnalyticsPayload>(initial);
  const [preset, setPreset] = useState<string>("30");
  const [from, setFrom] = useState(initial.range.from);
  const [to, setTo] = useState(initial.range.to);
  const [segments, setSegments] = useState<string[]>([]);
  const [metric, setMetric] = useState<"revenue" | "orders" | "aov">("revenue");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [lastUpdated, setLastUpdated] = useState<string>("just now");

  const firstRun = useRef(true);

  useEffect(() => {
    if (firstRun.current) {
      firstRun.current = false;
      return;
    }
    const controller = new AbortController();
    setLoading(true);
    setError("");
    const params = new URLSearchParams({ from, to });
    if (segments.length > 0) params.set("segments", segments.join(","));

    fetch(`/api/admin/analytics?${params.toString()}`, {
      signal: controller.signal,
      credentials: "same-origin",
    })
      .then(async (response) => {
        if (!response.ok) throw new Error("Unable to load analytics.");
        return (await response.json()) as AnalyticsPayload;
      })
      .then((payload) => {
        setData(payload);
        setLastUpdated(new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }));
      })
      .catch((cause: unknown) => {
        if (cause instanceof DOMException && cause.name === "AbortError") return;
        setError("Could not refresh the dashboard. Please retry.");
      })
      .finally(() => setLoading(false));

    return () => controller.abort();
  }, [from, to, segments]);

  function applyPreset(days: number, key: string) {
    setPage(0);
    setPreset(key);
    setFrom(isoDaysAgo(days));
    setTo(todayIso());
  }

  function toggleSegment(channel: string) {
    setPage(0);
    setPreset("custom");
    setSegments((current) =>
      current.includes(channel) ? current.filter((value) => value !== channel) : [...current, channel],
    );
  }

  const chartData = useMemo(
    () =>
      data.series.map((point) => ({
        label: formatDateShort(point.day),
        value: metric === "revenue" ? point.revenue : metric === "orders" ? point.orders : point.aov,
      })),
    [data.series, metric],
  );

  const spark = useMemo(() => data.series.slice(-14).map((point) => point.revenue), [data.series]);

  // Table state
  const [sort, setSort] = useState<{ key: SortKey; dir: "asc" | "desc" }>({ key: "orderedAt", dir: "desc" });
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [page, setPage] = useState(0);
  const pageSize = 10;

  const tableRows = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const filtered = data.rows.filter((row) => {
      if (statusFilter !== "all" && row.status !== statusFilter) return false;
      if (!needle) return true;
      return `${row.reference} ${row.customerName} ${row.channel} ${row.status}`.toLowerCase().includes(needle);
    });
    return [...filtered].sort((a, b) => {
      const dir = sort.dir === "asc" ? 1 : -1;
      const key = sort.key;
      if (key === "orderedAt") return (new Date(a.orderedAt).getTime() - new Date(b.orderedAt).getTime()) * dir;
      if (key === "itemsCount" || key === "totalInr") return (a[key] - b[key]) * dir;
      return String(a[key]).localeCompare(String(b[key])) * dir;
    });
  }, [data.rows, query, sort, statusFilter]);

  const pageCount = Math.max(1, Math.ceil(tableRows.length / pageSize));
  const safePage = Math.min(page, pageCount - 1);
  const visibleRows = tableRows.slice(safePage * pageSize, safePage * pageSize + pageSize);

  function toggleSort(key: SortKey) {
    setPage(0);
    setSort((current) =>
      current.key === key ? { key, dir: current.dir === "asc" ? "desc" : "asc" } : { key, dir: "asc" },
    );
  }

  function exportCsv() {
    const header = ["Reference", "Date", "Guest", "Segment", "Items", "Total INR", "Status"];
    const lines = tableRows.map((row) =>
      [row.reference, new Date(row.orderedAt).toISOString(), row.customerName, row.channel, row.itemsCount, row.totalInr, row.status]
        .map((cell) => `"${String(cell).replaceAll('"', '""')}"`)
        .join(","),
    );
    const blob = new Blob([[header.join(","), ...lines].join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `blue-door-orders-${from}-to-${to}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="pb-16">
      <header className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.28em] text-brand">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#2f7d5a] opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-[#2f7d5a]" />
            </span>
            Live · refreshed {lastUpdated}
          </p>
          <h1 className="mt-2 font-display text-3xl tracking-tight text-ink sm:text-[2.4rem]">Cafe performance</h1>
          <p className="mt-1 max-w-xl text-sm text-muted">
            Revenue, order mix and guest behaviour for Blue Door Cafe, Gangori Bazaar. Filters update every chart instantly.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <span className="rounded-full border border-line bg-card px-3 py-1.5 text-[11px] font-semibold text-muted">
            Signed in as {role}
          </span>
          <button
            type="button"
            onClick={exportCsv}
            className="rounded-full border border-line bg-card px-4 py-2 text-xs font-semibold text-ink transition-colors hover:border-brand/50"
          >
            Export CSV
          </button>
          <button
            type="button"
            onClick={() => {
              setFrom(isoDaysAgo(30));
              setTo(todayIso());
              setSegments([]);
              setPreset("30");
              setLastUpdated("just now");
            }}
            className="rounded-full bg-brand px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-brand-soft"
          >
            Reset view
          </button>
        </div>
      </header>

      {/* Filters */}
      <section aria-label="Filters" className="mt-6 rounded-3xl border border-line bg-card p-4 shadow-warm sm:p-5">
        <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
          <div className="flex flex-wrap items-center gap-1.5">
            {PRESETS.map((option) => (
              <button
                key={option.key}
                type="button"
                onClick={() => applyPreset(option.days, option.key)}
                aria-pressed={preset === option.key}
                className={`rounded-full px-3.5 py-2 text-xs font-semibold transition-colors ${
                  preset === option.key ? "bg-brand text-white" : "bg-surface-2 text-muted hover:text-ink"
                }`}
              >
                {option.label}
              </button>
            ))}
            <div className="ml-1 flex flex-wrap items-center gap-1.5 rounded-full border border-line px-2 py-1">
              <label className="text-[10px] uppercase tracking-[0.14em] text-muted" htmlFor="from">
                From
              </label>
              <input
                id="from"
                type="date"
                value={from}
                max={to}
                onChange={(event) => {
                  setPage(0);
                  setFrom(event.target.value);
                  setPreset("custom");
                }}
                className="bg-transparent text-xs text-ink outline-none"
              />
              <span className="text-muted">→</span>
              <label className="text-[10px] uppercase tracking-[0.14em] text-muted" htmlFor="to">
                To
              </label>
              <input
                id="to"
                type="date"
                value={to}
                min={from}
                max={todayIso()}
                onChange={(event) => {
                  setPage(0);
                  setTo(event.target.value);
                  setPreset("custom");
                }}
                className="bg-transparent text-xs text-ink outline-none"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={() => setSegments([])}
              aria-pressed={segments.length === 0}
              className={`rounded-full px-3 py-1.5 text-[11px] font-semibold transition-colors ${
                segments.length === 0 ? "bg-ink text-surface" : "border border-line text-muted hover:text-ink"
              }`}
            >
              All segments
            </button>
            {data.channels.map((channel) => {
              const active = segments.includes(channel);
              return (
                <button
                  key={channel}
                  type="button"
                  onClick={() => toggleSegment(channel)}
                  aria-pressed={active}
                  className={`rounded-full px-3 py-1.5 text-[11px] font-semibold transition-colors ${
                    active
                      ? "bg-jaipur text-white"
                      : "border border-line text-muted hover:border-jaipur/50 hover:text-ink"
                  }`}
                >
                  {SEGMENT_LABELS[channel] ?? channel}
                </button>
              );
            })}
            <span className="ml-1 text-[11px] text-muted">
              {data.range.days} days · {formatNumber(data.kpis.find((kpi) => kpi.key === "orders")?.value ?? 0)} orders
            </span>
          </div>
        </div>
        <AnimatePresence>
          {loading ? (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 20 }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-3 h-1 overflow-hidden rounded-full bg-surface-2"
            >
              <div className="shimmer h-full w-full" />
            </motion.div>
          ) : null}
        </AnimatePresence>
        {error ? <p className="mt-3 text-xs text-[#b3261e]">{error}</p> : null}
      </section>

      {/* KPIs */}
      <section aria-label="Key performance indicators" className="mt-4 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {data.kpis.map((kpi, index) => {
          const positive = kpi.deltaPct >= 0;
          return (
            <motion.article
              key={kpi.key}
              initial={reduce ? { opacity: 0 } : { opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: index * 0.06 }}
              className="group relative overflow-hidden rounded-3xl border border-line bg-card p-5 transition-shadow hover:shadow-warm"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-muted">{kpi.label}</p>
                  <p className="mt-2 font-display text-[1.7rem] leading-none tracking-tight text-ink">
                    <KpiValue kpi={kpi} />
                  </p>
                </div>
                <span
                  className={`inline-flex items-center gap-1 rounded-full px-2 py-1 text-[10px] font-bold ${
                    positive
                      ? "bg-[#2f7d5a]/12 text-[#1f6a4a] dark:text-[#7fd3ab]"
                      : "bg-jaipur/15 text-[#96394a] dark:text-[#f0a3b0]"
                  }`}
                >
                  <span aria-hidden="true">{positive ? "▲" : "▼"}</span>
                  {formatPercent(kpi.deltaPct)}
                </span>
              </div>
              <div className="mt-4 flex items-end justify-between gap-2">
                <p className="text-[11px] text-muted">
                  vs {kpi.format === "currency" ? formatCompactINR(kpi.previous) : formatNumber(kpi.previous)} · {kpi.hint}
                </p>
                <Sparkline data={spark.length > 1 ? spark : [0, 1]} positive={positive} />
              </div>
            </motion.article>
          );
        })}
      </section>

      {/* Charts */}
      <section className="mt-4 grid gap-4 lg:grid-cols-3">
        <article className="rounded-3xl border border-line bg-card p-5 lg:col-span-2">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h2 className="font-display text-xl text-ink">Trend over time</h2>
              <p className="text-xs text-muted">Hover the line for a daily breakdown.</p>
            </div>
            <div className="flex rounded-full border border-line bg-surface-2 p-1">
              {(["revenue", "orders", "aov"] as const).map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => setMetric(option)}
                  aria-pressed={metric === option}
                  className={`rounded-full px-3 py-1.5 text-[11px] font-semibold transition-colors ${
                    metric === option ? "bg-card text-ink shadow-sm" : "text-muted"
                  }`}
                >
                  {option === "aov" ? "Avg ticket" : option === "revenue" ? "Revenue" : "Orders"}
                </button>
              ))}
            </div>
          </div>
          <div className="mt-4">
            <TrendLineChart key={`${metric}-${from}-${to}-${segments.join()}`} data={chartData} mode={metric === "orders" ? "number" : "currency"} />
          </div>
        </article>

        <article className="rounded-3xl border border-line bg-card p-5">
          <h2 className="font-display text-xl text-ink">Revenue mix</h2>
          <p className="text-xs text-muted">By menu category · hover a slice.</p>
          <div className="mt-4">
            <DonutChart
              key={`${from}-${to}-${segments.join()}`}
              data={data.categorySplit.map((entry) => ({ label: entry.category, value: entry.revenue }))}
              centerLabel="All categories"
            />
          </div>
        </article>

        <article className="rounded-3xl border border-line bg-card p-5">
          <h2 className="font-display text-xl text-ink">Busiest days</h2>
          <p className="text-xs text-muted">Orders by weekday.</p>
          <div className="mt-6">
            <WeekdayBarChart key={`${from}-${to}-${segments.join()}`} data={data.weekday} />
          </div>
        </article>

        <article className="rounded-3xl border border-line bg-card p-5">
          <h2 className="font-display text-xl text-ink">Segment split</h2>
          <p className="text-xs text-muted">Revenue by order channel.</p>
          <ul className="mt-4 space-y-3">
            {data.channelSplit
              .slice()
              .sort((a, b) => b.revenue - a.revenue)
              .map((entry, index) => {
                const total = data.channelSplit.reduce((sum, item) => sum + item.revenue, 0) || 1;
                const pct = (entry.revenue / total) * 100;
                return (
                  <li key={entry.channel}>
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-ink">{SEGMENT_LABELS[entry.channel] ?? entry.channel}</span>
                      <span className="text-muted">{formatINR(entry.revenue)}</span>
                    </div>
                    <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-surface-2">
                      <motion.div
                        className="h-full rounded-full bg-brand-soft"
                        style={{ opacity: 1 - index * 0.16 }}
                        initial={{ width: 0 }}
                        animate={{ width: `${pct}%` }}
                        transition={{ duration: 0.7, delay: index * 0.06 }}
                      />
                    </div>
                  </li>
                );
              })}
          </ul>
        </article>

        <article className="rounded-3xl border border-line bg-card p-5">
          <h2 className="font-display text-xl text-ink">Top sellers</h2>
          <p className="text-xs text-muted">By revenue in this range.</p>
          <ol className="mt-4 space-y-3">
            {data.topItems.map((item, index) => (
              <li key={item.name} className="flex items-start justify-between gap-3">
                <span className="flex min-w-0 items-start gap-2">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-surface-2 text-[10px] font-bold text-brand">
                    {index + 1}
                  </span>
                  <span className="min-w-0">
                    <span className="block truncate text-xs font-semibold text-ink">{item.name}</span>
                    <span className="block text-[10px] text-muted">{item.units} units</span>
                  </span>
                </span>
                <span className="text-xs font-semibold text-ink">{formatINR(item.revenue)}</span>
              </li>
            ))}
            {data.topItems.length === 0 ? <li className="text-xs text-muted">No orders in this range.</li> : null}
          </ol>
        </article>
      </section>

      {/* Order table */}
      <section className="mt-4 rounded-3xl border border-line bg-card p-5">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2 className="font-display text-xl text-ink">Order feed</h2>
            <p className="text-xs text-muted">
              {formatNumber(tableRows.length)} matching orders · sort any column, search any guest.
            </p>
          </div>
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <label className="relative">
              <span className="sr-only">Search orders</span>
              <input
                value={query}
                onChange={(event) => {
                  setPage(0);
                  setQuery(event.target.value.slice(0, 60));
                }}
                placeholder="Search reference, guest, segment…"
                className="w-full rounded-full border border-line bg-surface px-4 py-2 text-xs text-ink placeholder:text-muted/70 sm:w-64"
              />
            </label>
            <select
              value={statusFilter}
              onChange={(event) => {
                setPage(0);
                setStatusFilter(event.target.value);
              }}
              aria-label="Filter by status"
              className="rounded-full border border-line bg-surface px-3 py-2 text-xs text-ink"
            >
              <option value="all">All statuses</option>
              <option value="completed">Completed</option>
              <option value="pending">Pending</option>
              <option value="refunded">Refunded</option>
            </select>
          </div>
        </div>

        <div className="mt-4 -mx-5 overflow-x-auto px-5">
          <table className="w-full min-w-[680px] border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-line text-[10px] uppercase tracking-[0.14em] text-muted">
                {(
                  [
                    ["reference", "Reference"],
                    ["orderedAt", "Date & time"],
                    ["customerName", "Guest"],
                    ["channel", "Segment"],
                    ["itemsCount", "Items"],
                    ["totalInr", "Total"],
                    ["status", "Status"],
                  ] as [SortKey, string][]
                ).map(([key, label]) => (
                  <th key={key} scope="col" className="py-2.5 pr-4 font-semibold">
                    <button
                      type="button"
                      onClick={() => toggleSort(key)}
                      className="inline-flex items-center gap-1 transition-colors hover:text-ink"
                      aria-label={`Sort by ${label}`}
                    >
                      {label}
                      <span aria-hidden="true" className={sort.key === key ? "text-brand" : "text-line"}>
                        {sort.key === key ? (sort.dir === "asc" ? "↑" : "↓") : "↕"}
                      </span>
                    </button>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <AnimatePresence initial={false}>
                {visibleRows.map((row) => (
                  <motion.tr
                    key={row.id}
                    layout
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="border-b border-line/60 transition-colors last:border-0 hover:bg-surface-2/60"
                  >
                    <td className="py-3 pr-4 font-mono text-[11px] text-ink">{row.reference}</td>
                    <td className="py-3 pr-4 text-muted">{formatSlot(row.orderedAt)}</td>
                    <td className="py-3 pr-4 text-ink">
                      {row.customerName}
                      {row.returningGuest ? <span className="ml-1.5 text-[9px] font-bold uppercase text-jaipur">repeat</span> : null}
                    </td>
                    <td className="py-3 pr-4 text-muted">{SEGMENT_LABELS[row.channel] ?? row.channel}</td>
                    <td className="py-3 pr-4 text-muted">{row.itemsCount}</td>
                    <td className="py-3 pr-4 font-semibold text-ink">{formatINR(row.totalInr)}</td>
                    <td className="py-3 pr-4">
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold capitalize ${STATUS_STYLES[row.status] ?? ""}`}>
                        {row.status}
                      </span>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
          {visibleRows.length === 0 ? (
            <p className="py-10 text-center text-xs text-muted">No orders match these filters.</p>
          ) : null}
        </div>

        <div className="mt-4 flex flex-col gap-2 border-t border-line pt-3 text-xs text-muted sm:flex-row sm:items-center sm:justify-between">
          <p>
            Page {safePage + 1} of {pageCount}
          </p>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setPage((current) => Math.max(0, current - 1))}
              disabled={safePage === 0}
              className="rounded-full border border-line px-3 py-1.5 font-semibold text-ink disabled:opacity-40"
            >
              Previous
            </button>
            <button
              type="button"
              onClick={() => setPage((current) => Math.min(pageCount - 1, current + 1))}
              disabled={safePage >= pageCount - 1}
              className="rounded-full border border-line px-3 py-1.5 font-semibold text-ink disabled:opacity-40"
            >
              Next
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}

import { destroySessionCookies } from "@/lib/auth";
import { assertCsrf } from "@/lib/security";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const csrf = await assertCsrf(request);
  if (csrf) return csrf;
  await destroySessionCookies();
  return Response.json({ ok: true }, { headers: { "Cache-Control": "no-store" } });
}

import { redirect } from "next/navigation";
import { ReservationsManager } from "@/components/admin/reservations-manager";
import { can, getSession } from "@/lib/auth";
import { getMessages, getReservations } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function AdminReservationsPage() {
  const session = await getSession();
  if (!session) redirect("/admin/login");
  if (!can(session.role, "analytics:read")) redirect("/admin");

  const [rows, messages] = await Promise.all([getReservations(100), getMessages(20)]);

  return (
    <ReservationsManager
      initial={rows.map((row) => ({
        id: row.id,
        reference: row.reference,
        name: row.name,
        phone: row.phone,
        email: row.email,
        guests: row.guests,
        reservationDate: row.reservationDate,
        reservationTime: row.reservationTime,
        notes: row.notes,
        status: row.status,
      }))}
      messages={messages.map((message) => ({
        id: message.id,
        name: message.name,
        email: message.email,
        phone: message.phone,
        subject: message.subject,
        message: message.message,
        status: message.status,
        createdAt: message.createdAt,
      }))}
      canWrite={can(session.role, "reservations:write")}
    />
  );
}

"use client";

import Image from "next/image";
import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import { AnimatedPrice, Reveal, RippleLink, SectionHeading } from "@/components/motion-primitives";
import { ContactForm, ReservationForm } from "@/components/home/forms";
import { DoorMark } from "@/components/site-chrome";
import { CAFE, formatINR } from "@/lib/format";
import { IMAGES } from "@/lib/images";
import type { SpecialRow } from "@/lib/data";

const STATS = [
  { value: "2016", label: "Serving since" },
  { value: "42", label: "Courtyard seats" },
  { value: "18 hr", label: "Cold brew steep" },
  { value: "4.9", label: "Guest rating" },
];

export function About() {
  return (
    <section id="about" className="relative scroll-mt-24 overflow-hidden bg-surface py-20 sm:py-24 lg:py-28">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:gap-16 lg:px-8">
        <div className="relative">
          <Reveal className="relative mx-auto max-w-md lg:mx-0">
            <div className="relative aspect-[4/5] overflow-hidden arch border border-line">
              <Image
                src={IMAGES.about.src}
                alt={IMAGES.about.alt}
                fill
                sizes="(max-width: 1024px) 90vw, 420px"
                className="object-cover"
              />
            </div>
            <div className="absolute -right-2 bottom-8 w-36 overflow-hidden rounded-2xl border-4 border-surface shadow-warm sm:w-44">
              <div className="relative aspect-[4/5]">
                <Image
                  src={IMAGES.aboutDetail.src}
                  alt={IMAGES.aboutDetail.alt}
                  fill
                  sizes="180px"
                  className="object-cover"
                />
              </div>
            </div>
            <div className="absolute -left-3 top-6 rounded-2xl border border-line bg-card px-4 py-3 shadow-warm">
              <p className="font-display text-2xl text-ink">Since 2016</p>
              <p className="text-[10px] uppercase tracking-[0.2em] text-muted">Gangori Bazaar</p>
            </div>
          </Reveal>
        </div>

        <div>
          <SectionHeading
            align="left"
            eyebrow="Our story"
            title="A cafe that opens like a friend's door."
            description="Blue Door began as a two-table coffee counter behind Jaipur's Gangori Bazaar. The paint was left over from a haveli restoration, the recipe book came from a grandmother in Bani Park, and the door was always blue."
          />
          <div className="mt-6 space-y-4 text-[15px] leading-relaxed text-muted">
            <Reveal delay={0.1}>
              <p>
                Today we roast small batches, bake before sunrise, and plate the food we grew up eating —
                kachori with tamarind, laal maas with smoked chilli, tres leches with kesar. Every plate is
                made to be shared across a courtyard table.
              </p>
            </Reveal>
            <Reveal delay={0.16}>
              <ul className="grid gap-2 sm:grid-cols-2">
                {[
                  "Single-origin, roasted weekly",
                  "Vegetarian & non-veg kitchens",
                  "Courtyard & jharokha seating",
                  "Work-friendly, dog-friendly",
                ].map((point) => (
                  <li key={point} className="flex items-start gap-2 text-sm text-ink">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-jaipur" aria-hidden="true" />
                    {point}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>

          <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {STATS.map((stat, index) => (
              <Reveal key={stat.label} delay={0.08 * index}>
                <div className="rounded-2xl border border-line bg-card px-3 py-4 text-center">
                  <p className="font-display text-2xl text-ink">{stat.value}</p>
                  <p className="mt-1 text-[9px] font-semibold uppercase tracking-[0.18em] text-muted">{stat.label}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export function Specials({ specials }: { specials: SpecialRow[] }) {
  const reduce = useReducedMotion();
  if (specials.length === 0) return null;

  return (
    <section id="specials" className="relative scroll-mt-24 overflow-hidden bg-[#0d2a45] py-20 text-[#fbf6ec] sm:py-24 lg:py-28">
      <div className="absolute inset-0 grain opacity-60" aria-hidden="true" />
      <div className="pointer-events-none absolute -right-20 top-16 h-72 w-72 rounded-full border border-[#e6b98a]/20" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading
            light
            align="left"
            eyebrow="Specials of the day"
            title="What the kitchen is excited about today."
            description="Small runs, seasonal produce, and whatever the baker pulled out of the oven first. Available today only."
          />
          <Reveal delay={0.15} className="shrink-0">
            <a
              href="#reserve"
              className="inline-flex items-center gap-2 rounded-full border border-white/25 px-5 py-2.5 text-sm font-semibold text-[#fbf6ec] transition-colors hover:bg-white/10"
            >
              Reserve before they run out <span aria-hidden="true">→</span>
            </a>
          </Reveal>
        </div>

        <ul className="mt-12 grid gap-4 sm:grid-cols-2">
          {specials.map((special, index) => (
            <motion.li
              key={special.id}
              initial={reduce ? { opacity: 0 } : { opacity: 0, y: 26 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.25 }}
              transition={{ duration: 0.55, delay: index * 0.08 }}
              whileHover={reduce ? undefined : { y: -5 }}
              className={`relative overflow-hidden rounded-3xl border border-white/15 p-6 backdrop-blur-sm transition-shadow hover:shadow-2xl ${
                index === 0 ? "bg-[#fbf6ec] text-[#12263b] sm:col-span-2" : "bg-white/[0.06] text-[#fbf6ec]"
              }`}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="max-w-xl">
                  <span
                    className={`inline-flex rounded-full px-2.5 py-1 text-[9px] font-bold uppercase tracking-[0.18em] ${
                      index === 0 ? "bg-[#b1713f]/15 text-[#8e5527]" : "bg-[#e6b98a]/20 text-[#f0c9a2]"
                    }`}
                  >
                    {special.badge}
                  </span>
                  <h3 className={`mt-3 font-display leading-tight ${index === 0 ? "text-2xl sm:text-3xl" : "text-xl"}`}>
                    {special.title}
                  </h3>
                  <p className={`mt-2 text-sm leading-relaxed ${index === 0 ? "text-[#4a5568]" : "text-[#d8dfe6]/80"}`}>
                    {special.description}
                  </p>
                </div>
                <div className="text-right">
                  <AnimatedPrice value={special.priceInr} className="font-display text-2xl" />
                  <p className={`mt-1 text-[9px] uppercase tracking-[0.18em] ${index === 0 ? "text-[#8e5527]" : "text-[#e6b98a]"}`}>
                    incl. taxes
                  </p>
                </div>
              </div>
            </motion.li>
          ))}
        </ul>
      </div>
    </section>
  );
}

export function ReserveSection() {
  return (
    <section id="reserve" className="scroll-mt-24 bg-surface-2 py-20 sm:py-24 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:gap-14">
          <div>
            <SectionHeading
              align="left"
              eyebrow="Reservations"
              title="Hold a table under the arches."
              description="We keep a handful of courtyard tables for walk-ins, but the best seats are booked ahead — especially on Pink City weekends."
            />
            <div className="mt-8 space-y-3">
              {[
                { icon: "⌚", title: "Open daily", body: "8:00 am – 10:30 pm (11:30 pm on weekends)" },
                { icon: "☎", title: "Prefer to talk?", body: `${CAFE.phoneDisplay} · call or WhatsApp` },
                { icon: "◈", title: "Groups & events", body: "Up to 12 guests online, larger parties by phone" },
              ].map((item, index) => (
                <Reveal key={item.title} delay={index * 0.08}>
                  <div className="flex items-start gap-3 rounded-2xl border border-line bg-card p-4">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-surface-2 text-brand">
                      {item.icon}
                    </span>
                    <div>
                      <p className="text-sm font-semibold text-ink">{item.title}</p>
                      <p className="text-[13px] text-muted">{item.body}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
            <Reveal delay={0.24} className="mt-6">
              <a
                href={CAFE.whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-[#1f7a4d] px-5 py-3 text-sm font-semibold text-white transition-transform hover:-translate-y-0.5"
              >
                WhatsApp us on {CAFE.phoneDisplay}
              </a>
            </Reveal>
          </div>
          <Reveal delay={0.12}>
            <ReservationForm />
          </Reveal>
        </div>
      </div>
    </section>
  );
}

export function ContactSection() {
  return (
    <section id="contact" className="scroll-mt-24 bg-surface py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:gap-14">
          <SectionHeading
            align="left"
            eyebrow="Contact"
            title="Say hello, or book the whole courtyard."
            description="Private dinners, book clubs, photo shoots and coffee-bean pickups — write to us and we will make it work."
          />
          <Reveal delay={0.1}>
            <ContactForm />
          </Reveal>
        </div>
      </div>
    </section>
  );
}

export function Visit() {
  return (
    <section id="visit" className="scroll-mt-24 bg-surface-2 py-20 sm:py-24 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Find us"
          title="Two minutes from Hawa Mahal."
          description="Walk down Tulsi Marg into Gangori Bazaar — look for the blue door, second archway on the left."
        />

        <div className="mt-12 grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
          <Reveal className="overflow-hidden rounded-[2rem] border border-line bg-card shadow-warm">
            <div className="relative aspect-[16/11] w-full sm:aspect-[16/9]">
              <iframe
                title="Blue Door Cafe location on Google Maps"
                src={CAFE.mapEmbed}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="absolute inset-0 h-full w-full border-0"
              />
            </div>
          </Reveal>

          <div className="grid gap-4">
            <Reveal delay={0.08} className="rounded-3xl border border-line bg-card p-6">
              <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-accent">Address</p>
              <address className="mt-2 not-italic text-[15px] leading-relaxed text-ink">{CAFE.address}</address>
              <div className="mt-4 flex flex-wrap gap-2">
                <a href={CAFE.phoneHref} className="rounded-full bg-brand px-4 py-2 text-xs font-semibold text-white">
                  Call {CAFE.phoneDisplay}
                </a>
                <a
                  href={CAFE.whatsappHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-full bg-[#1f7a4d] px-4 py-2 text-xs font-semibold text-white"
                >
                  WhatsApp
                </a>
                <a
                  href={CAFE.mapLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-full border border-line px-4 py-2 text-xs font-semibold text-ink"
                >
                  Directions ↗
                </a>
              </div>
            </Reveal>

            <Reveal delay={0.14} className="rounded-3xl border border-line bg-card p-6">
              <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-accent">Opening hours</p>
              <dl className="mt-3 space-y-2 text-sm">
                {CAFE.hours.map((row) => (
                  <div key={row.day} className="flex items-baseline justify-between gap-4 border-b border-line/60 pb-2 last:border-0">
                    <dt className="text-muted">{row.day}</dt>
                    <dd className="font-semibold text-ink">{row.time}</dd>
                  </div>
                ))}
              </dl>
            </Reveal>

            <Reveal delay={0.2} className="rounded-3xl border border-line bg-[#123b63] p-6 text-[#fbf6ec]">
              <p className="font-display text-lg">Planning a celebration?</p>
              <p className="mt-1 text-sm text-[#dce7f0]/80">
                We host birthdays, book launches and slow Sunday brunches from {formatINR(1200)} per guest.
              </p>
              <a href="#contact" className="mt-4 inline-flex text-sm font-semibold text-[#e6b98a] hover:underline">
                Enquire about private events →
              </a>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="relative overflow-hidden bg-[#08192b] pt-16 text-[#dbe5ec]">
      <div className="absolute inset-0 grain opacity-40" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-10 border-b border-white/10 pb-12 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#1b4e7a] text-[#fbf6ec]">
                <DoorMark className="h-7 w-7" />
              </span>
              <div>
                <p className="font-display text-xl text-[#fbf6ec]">Blue Door Cafe</p>
                <p className="text-[9px] uppercase tracking-[0.3em] text-[#9fb8cc]">Pink City · Jaipur</p>
              </div>
            </div>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-[#b9cad8]">{CAFE.tagline}</p>
            <ul className="mt-5 flex flex-wrap gap-2">
              {CAFE.socials.map((social) => (
                <li key={social.label}>
                  <a
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex rounded-full border border-white/15 px-3 py-1.5 text-[11px] font-semibold text-[#dbe5ec] transition-colors hover:border-[#e6b98a] hover:text-[#e6b98a]"
                  >
                    {social.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-[10px] font-semibold uppercase tracking-[0.28em] text-[#e6b98a]">Visit</h3>
            <address className="mt-4 not-italic text-sm leading-relaxed text-[#b9cad8]">{CAFE.address}</address>
            <a href={CAFE.phoneHref} className="mt-3 block text-sm font-semibold text-[#fbf6ec]">
              {CAFE.phoneDisplay}
            </a>
            <a href={`mailto:${CAFE.email}`} className="mt-1 block text-sm text-[#b9cad8] hover:text-[#fbf6ec]">
              {CAFE.email}
            </a>
          </div>

          <div>
            <h3 className="text-[10px] font-semibold uppercase tracking-[0.28em] text-[#e6b98a]">Hours</h3>
            <dl className="mt-4 space-y-2 text-sm">
              {CAFE.hours.map((row) => (
                <div key={row.day}>
                  <dt className="text-[#9fb8cc]">{row.day}</dt>
                  <dd className="text-[#fbf6ec]">{row.time}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div>
            <h3 className="text-[10px] font-semibold uppercase tracking-[0.28em] text-[#e6b98a]">Explore</h3>
            <ul className="mt-4 space-y-2 text-sm">
              {[
                ["Story", "#about"],
                ["Menu", "#menu"],
                ["Specials", "#specials"],
                ["Gallery", "#gallery"],
                ["Reserve", "#reserve"],
                ["Contact", "#contact"],
              ].map(([label, href]) => (
                <li key={href}>
                  <a href={href} className="text-[#b9cad8] transition-colors hover:text-[#fbf6ec]">
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="flex flex-col gap-4 py-6 text-[11px] text-[#8fa7bb] sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} Blue Door Cafe. All prices in Indian Rupees (₹) and inclusive of taxes.</p>
          <div className="flex flex-wrap items-center gap-4">
            <span className="inline-flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-[#5fbf8a]" aria-hidden="true" />
              Secure forms · rate limited
            </span>
            <Link href="/admin/login" className="font-semibold text-[#c7d6e2] hover:text-[#fbf6ec]">
              Owner login
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

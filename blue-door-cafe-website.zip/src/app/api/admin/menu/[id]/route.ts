import { eq } from "drizzle-orm";
import { db } from "@/db";
import { auditLog, menuItems } from "@/db/schema";
import { guardAdmin, noStoreJson } from "@/lib/api-guard";
import { menuItemUpdateSchema, parseJson } from "@/lib/validation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

function parseId(raw: string): number | null {
  const id = Number(raw);
  return Number.isInteger(id) && id > 0 && id < 1_000_000 ? id : null;
}

export async function PATCH(request: Request, { params }: Params) {
  const guard = await guardAdmin(request, "menu:write");
  if (guard.response) return guard.response;

  const { id: rawId } = await params;
  const id = parseId(rawId);
  if (!id) return noStoreJson({ error: "Invalid item." }, 400);

  const parsed = await parseJson(request, menuItemUpdateSchema);
  if (!parsed.ok) return parsed.response;

  try {
    // Ownership/role verified above; scoped update prevents IDOR.
    const [updated] = await db
      .update(menuItems)
      .set({ ...parsed.data, updatedAt: new Date() })
      .where(eq(menuItems.id, id))
      .returning();
    if (!updated) return noStoreJson({ error: "Menu item not found." }, 404);

    await db.insert(auditLog).values({
      actorId: guard.session.sub,
      action: "update",
      entity: "menu_item",
      entityId: String(id),
    });
    return noStoreJson({ item: updated });
  } catch {
    return noStoreJson({ error: "Could not update this menu item." }, 500);
  }
}

export async function DELETE(request: Request, { params }: Params) {
  const guard = await guardAdmin(request, "menu:write");
  if (guard.response) return guard.response;

  const { id: rawId } = await params;
  const id = parseId(rawId);
  if (!id) return noStoreJson({ error: "Invalid item." }, 400);

  try {
    const [deleted] = await db.delete(menuItems).where(eq(menuItems.id, id)).returning({ id: menuItems.id });
    if (!deleted) return noStoreJson({ error: "Menu item not found." }, 404);

    await db.insert(auditLog).values({
      actorId: guard.session.sub,
      action: "delete",
      entity: "menu_item",
      entityId: String(id),
    });
    return noStoreJson({ ok: true });
  } catch {
    return noStoreJson({ error: "Could not delete this menu item." }, 500);
  }
}

import { assertCsrf, rateLimit } from "@/lib/security";
import { requireRole, type AdminSession } from "@/lib/auth";

/**
 * Shared guard for every /api/admin/* route handler.
 * Order matters: throttle → CSRF/origin → authenticated session → role check.
 */
export async function guardAdmin(
  request: Request,
  permission: string,
): Promise<{ session: AdminSession; response: null } | { session: null; response: Response }> {
  const mutating = !["GET", "HEAD", "OPTIONS"].includes(request.method.toUpperCase());
  const limited = rateLimit(
    request.headers,
    mutating ? "admin:write" : "admin:read",
    mutating ? 60 : 240,
    60_000,
  );
  if (limited.response) return { session: null, response: limited.response };

  const csrf = await assertCsrf(request);
  if (csrf) return { session: null, response: csrf };

  const session = await requireRole(permission);
  if (!session) {
    return {
      session: null,
      response: Response.json(
        { error: "Not authorised." },
        { status: 401, headers: { "Cache-Control": "no-store" } },
      ),
    };
  }
  return { session, response: null };
}

export function noStoreJson(body: unknown, status = 200): Response {
  return Response.json(body, { status, headers: { "Cache-Control": "no-store" } });
}

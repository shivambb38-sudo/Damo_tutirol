"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useMemo, useState } from "react";
import { AnimatedPrice, SectionHeading } from "@/components/motion-primitives";
import type { CategoryRow, MenuItemRow } from "@/lib/data";

const DIETS = [
  { key: "all", label: "Everything" },
  { key: "veg", label: "Veg" },
  { key: "nonveg", label: "Non-veg" },
  { key: "vegan", label: "Vegan" },
] as const;

const DIET_DOT: Record<string, string> = {
  veg: "bg-[#1f7a4d]",
  nonveg: "bg-[#b3261e]",
  vegan: "bg-[#2f7d5a]",
};

const CATEGORY_GLYPH: Record<string, string> = {
  "chai-coffee": "◗",
  espresso: "☕",
  "cold-brew": "❄",
  "jaipur-plates": "◈",
  bakes: "✦",
};

export function MenuSection({ categories, items }: { categories: CategoryRow[]; items: MenuItemRow[] }) {
  const [category, setCategory] = useState<string>("all");
  const [diet, setDiet] = useState<(typeof DIETS)[number]["key"]>("all");
  const [query, setQuery] = useState("");
  const reduce = useReducedMotion();

  const tabs = useMemo(
    () => [{ slug: "all", name: "All day" }, ...categories.map((c) => ({ slug: c.slug, name: c.name }))],
    [categories],
  );

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return items.filter((item) => {
      if (category !== "all" && item.categorySlug !== category) return false;
      if (diet !== "all" && item.diet !== diet) return false;
      if (!item.available) return false;
      if (!needle) return true;
      return `${item.name} ${item.description}`.toLowerCase().includes(needle);
    });
  }, [category, diet, items, query]);

  return (
    <section id="menu" className="relative scroll-mt-24 bg-surface py-20 sm:py-24 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="The menu"
          title="Everything worth lingering over."
          description="Brewed, baked and plated in-house. Prices are in Indian Rupees and include taxes — search the board or filter by your preference."
        />

        <div className="mt-12 space-y-6">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto p-1">
              {tabs.map((tab) => {
                const active = tab.slug === category;
                return (
                  <button
                    key={tab.slug}
                    type="button"
                    onClick={() => setCategory(tab.slug)}
                    aria-pressed={active}
                    className={`relative shrink-0 rounded-full px-4 py-2 text-[13px] font-semibold transition-colors ${
                      active ? "text-white" : "text-muted hover:text-ink"
                    }`}
                  >
                    {active ? (
                      <motion.span
                        layoutId="menu-tab"
                        className="absolute inset-0 rounded-full bg-brand"
                        transition={{ type: "spring", stiffness: 380, damping: 32 }}
                      />
                    ) : null}
                    <span className="relative z-10">{tab.name}</span>
                  </button>
                );
              })}
            </div>

            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <label className="relative block">
                <span className="sr-only">Search the menu</span>
                <input
                  value={query}
                  onChange={(event) => setQuery(event.target.value.slice(0, 60))}
                  placeholder="Search coffee, kachori…"
                  className="w-full rounded-full border border-line bg-card py-2.5 pl-10 pr-4 text-sm text-ink placeholder:text-muted/70 sm:w-60"
                />
                <svg className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="1.7" />
                  <path d="m16.5 16.5 4 4" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
                </svg>
              </label>
              <div className="flex rounded-full border border-line bg-card p-1">
                {DIETS.map((option) => (
                  <button
                    key={option.key}
                    type="button"
                    onClick={() => setDiet(option.key)}
                    aria-pressed={diet === option.key}
                    className={`rounded-full px-3 py-1.5 text-[12px] font-semibold transition-colors ${
                      diet === option.key ? "bg-surface-2 text-ink shadow-sm" : "text-muted hover:text-ink"
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <p className="text-xs text-muted">
            Showing <span className="font-semibold text-ink">{filtered.length}</span> of {items.length} dishes & drinks
          </p>

          <motion.ul layout className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <AnimatePresence mode="popLayout">
              {filtered.map((item, index) => {
                const categoryName = categories.find((c) => c.slug === item.categorySlug)?.name ?? "Cafe";
                return (
                  <motion.li
                    key={item.id}
                    layout
                    initial={reduce ? { opacity: 0 } : { opacity: 0, y: 24, scale: 0.97 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.97 }}
                    transition={{ duration: 0.4, delay: Math.min(index * 0.04, 0.28) }}
                    whileHover={reduce ? undefined : { y: -6, rotate: index % 2 === 0 ? -0.5 : 0.5 }}
                    className="group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-line bg-card p-5 transition-shadow duration-300 hover:shadow-warm"
                  >
                    <div className="pointer-events-none absolute -right-10 -top-10 h-28 w-28 rounded-full bg-jaipur/10 transition-transform duration-500 group-hover:scale-125" aria-hidden="true" />
                    <div>
                      <div className="flex items-start justify-between gap-3">
                        <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-surface-2 text-lg text-brand">
                          {CATEGORY_GLYPH[item.categorySlug] ?? "✦"}
                        </span>
                        <div className="flex items-center gap-2">
                          {item.signature ? (
                            <span className="rounded-full bg-gold/15 px-2 py-0.5 text-[9px] font-bold uppercase tracking-[0.16em] text-accent">
                              Signature
                            </span>
                          ) : null}
                          <span
                            className="flex h-4 w-4 items-center justify-center rounded-sm border border-line"
                            title={item.diet === "nonveg" ? "Non-vegetarian" : item.diet === "vegan" ? "Vegan" : "Vegetarian"}
                          >
                            <span className={`h-2 w-2 rounded-full ${DIET_DOT[item.diet] ?? DIET_DOT.veg}`} />
                          </span>
                        </div>
                      </div>
                      <p className="mt-4 text-[10px] font-semibold uppercase tracking-[0.24em] text-muted">{categoryName}</p>
                      <h3 className="mt-1 font-display text-xl leading-snug text-ink">{item.name}</h3>
                      <p className="mt-2 text-[13px] leading-relaxed text-muted">{item.description}</p>
                    </div>
                    <div className="mt-5 flex items-center justify-between border-t border-line/70 pt-3">
                      <AnimatedPrice value={item.priceInr} className="text-lg font-semibold text-ink" />
                      <a
                        href="#reserve"
                        className="rounded-full border border-line px-3 py-1.5 text-[11px] font-semibold text-ink transition-colors group-hover:border-brand group-hover:bg-brand group-hover:text-white"
                      >
                        Table for this →
                      </a>
                    </div>
                  </motion.li>
                );
              })}
            </AnimatePresence>
          </motion.ul>

          {filtered.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-3xl border border-dashed border-line bg-card px-6 py-14 text-center"
            >
              <p className="font-display text-xl text-ink">Nothing on the board for that search.</p>
              <p className="mt-2 text-sm text-muted">Try “chai”, “kachori” or clear the filters.</p>
              <button
                type="button"
                onClick={() => {
                  setQuery("");
                  setDiet("all");
                  setCategory("all");
                }}
                className="mt-5 rounded-full bg-brand px-4 py-2 text-sm font-semibold text-white"
              >
                Reset filters
              </button>
            </motion.div>
          ) : null}
        </div>
      </div>
    </section>
  );
}

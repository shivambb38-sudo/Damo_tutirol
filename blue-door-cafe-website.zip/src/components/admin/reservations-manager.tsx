"use client";

import { useMemo, useState } from "react";
import { apiRequest } from "@/lib/client-api";
import { formatDateLong } from "@/lib/format";

type Reservation = {
  id: number;
  reference: string;
  name: string;
  phone: string;
  email: string | null;
  guests: number;
  reservationDate: string;
  reservationTime: string;
  notes: string | null;
  status: string;
};

type Message = {
  id: number;
  name: string;
  email: string;
  phone: string | null;
  subject: string;
  message: string;
  status: string;
  createdAt: Date | string;
};

const STATUSES = ["pending", "confirmed", "seated", "cancelled"] as const;

const STATUS_STYLE: Record<string, string> = {
  pending: "bg-gold/15 text-[#8a621b] dark:text-[#e6c07a]",
  confirmed: "bg-[#2f7d5a]/12 text-[#1f6a4a] dark:text-[#7fd3ab]",
  seated: "bg-brand/10 text-brand",
  cancelled: "bg-jaipur/15 text-[#96394a] dark:text-[#f0a3b0]",
};

export function ReservationsManager({
  initial,
  messages,
  canWrite,
}: {
  initial: Reservation[];
  messages: Message[];
  canWrite: boolean;
}) {
  const [rows, setRows] = useState(initial);
  const [filter, setFilter] = useState("all");
  const [error, setError] = useState("");

  const filtered = useMemo(
    () => (filter === "all" ? rows : rows.filter((row) => row.status === filter)),
    [filter, rows],
  );

  async function updateStatus(id: number, status: string) {
    setError("");
    const result = await apiRequest<{ reservation: Reservation }>(`/api/admin/reservations/${id}`, {
      method: "PATCH",
      body: { status },
    });
    if (!result.ok || !result.data.reservation) {
      setError(result.data.error ?? "Could not update this reservation.");
      return;
    }
    const updated = result.data.reservation;
    setRows((current) => current.map((row) => (row.id === updated.id ? updated : row)));
  }

  return (
    <div className="pb-16">
      <header>
        <p className="text-[10px] font-semibold uppercase tracking-[0.28em] text-brand">Front of house</p>
        <h1 className="mt-2 font-display text-3xl tracking-tight text-ink">Reservations & messages</h1>
        <p className="mt-1 text-sm text-muted">
          {rows.length} bookings on file. Confirm by phone, then mark the status so the floor team knows.
        </p>
      </header>

      {error ? (
        <p role="alert" className="mt-3 rounded-xl border border-[#b3261e]/30 bg-[#b3261e]/5 px-3 py-2 text-xs text-[#8d1d17] dark:text-[#f0a9a2]">{error}</p>
      ) : null}

      <div className="mt-5 flex flex-wrap gap-1.5">
        {["all", ...STATUSES].map((status) => (
          <button
            key={status}
            type="button"
            onClick={() => setFilter(status)}
            aria-pressed={filter === status}
            className={`rounded-full px-3 py-1.5 text-[11px] font-semibold capitalize transition-colors ${
              filter === status ? "bg-brand text-white" : "border border-line text-muted hover:text-ink"
            }`}
          >
            {status}
          </button>
        ))}
      </div>

      <div className="mt-4 overflow-x-auto rounded-3xl border border-line bg-card">
        <table className="w-full min-w-[820px] border-collapse text-left text-xs">
          <thead>
            <tr className="border-b border-line text-[10px] uppercase tracking-[0.14em] text-muted">
              <th className="px-4 py-3 font-semibold">Reference</th>
              <th className="px-4 py-3 font-semibold">Guest</th>
              <th className="px-4 py-3 font-semibold">Slot</th>
              <th className="px-4 py-3 font-semibold">Party</th>
              <th className="px-4 py-3 font-semibold">Notes</th>
              <th className="px-4 py-3 font-semibold">Status</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((row) => (
              <tr key={row.id} className="border-b border-line/60 last:border-0 hover:bg-surface-2/50">
                <td className="px-4 py-3 font-mono text-[11px] text-ink">{row.reference}</td>
                <td className="px-4 py-3">
                  <p className="font-semibold text-ink">{row.name}</p>
                  <a href={`tel:${row.phone}`} className="text-[10px] text-brand">{row.phone}</a>
                </td>
                <td className="px-4 py-3 text-muted">
                  {formatDateLong(row.reservationDate)}
                  <span className="block text-[10px]">{row.reservationTime}</span>
                </td>
                <td className="px-4 py-3 text-muted">{row.guests}</td>
                <td className="max-w-[200px] px-4 py-3 text-muted">{row.notes ?? "—"}</td>
                <td className="px-4 py-3">
                  {canWrite ? (
                    <select
                      value={row.status}
                      onChange={(event) => updateStatus(row.id, event.target.value)}
                      aria-label={`Status for ${row.reference}`}
                      className="rounded-full border border-line bg-surface px-2 py-1 text-[10px] font-semibold capitalize text-ink"
                    >
                      {STATUSES.map((status) => (
                        <option key={status} value={status}>{status}</option>
                      ))}
                    </select>
                  ) : (
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold capitalize ${STATUS_STYLE[row.status] ?? ""}`}>
                      {row.status}
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 ? <p className="py-10 text-center text-xs text-muted">No reservations with this status.</p> : null}
      </div>

      <section className="mt-6">
        <h2 className="font-display text-2xl text-ink">Contact messages</h2>
        <p className="text-xs text-muted">{messages.length} messages · newest first.</p>
        <ul className="mt-3 grid gap-3 md:grid-cols-2">
          {messages.map((message) => (
            <li key={message.id} className="rounded-3xl border border-line bg-card p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-ink">{message.subject}</p>
                  <p className="text-[11px] text-muted">
                    {message.name} · {message.email}
                    {message.phone ? ` · ${message.phone}` : ""}
                  </p>
                </div>
                <span className="rounded-full bg-surface-2 px-2 py-0.5 text-[9px] font-bold uppercase tracking-[0.16em] text-muted">
                  {message.status}
                </span>
              </div>
              <p className="mt-2 text-xs leading-relaxed text-muted">{message.message}</p>
            </li>
          ))}
          {messages.length === 0 ? <li className="text-xs text-muted">No messages yet.</li> : null}
        </ul>
      </section>
    </div>
  );
}

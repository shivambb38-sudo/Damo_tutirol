"use client";

import Image from "next/image";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { RippleLink } from "@/components/motion-primitives";
import { DoorMark } from "@/components/site-chrome";
import { CAFE, formatINR } from "@/lib/format";
import { IMAGES } from "@/lib/images";

const headline = ["Step", "through", "the"];

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.09, delayChildren: 0.2 } },
};

const word = {
  hidden: { opacity: 0, y: 34, rotate: 1.5 },
  show: { opacity: 1, y: 0, rotate: 0, transition: { duration: 0.85, ease: [0.22, 1, 0.36, 1] as const } },
};

export function Hero() {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const imageY = useTransform(scrollYProgress, [0, 1], ["0%", reduce ? "0%" : "16%"]);
  const contentY = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : 60]);
  const fade = useTransform(scrollYProgress, [0, 0.8], [1, 0.25]);

  return (
    <section
      ref={ref}
      id="top"
      className="relative flex min-h-[100svh] items-center overflow-hidden bg-[#0a1f33] pt-28 pb-16 text-[#fbf6ec] sm:pt-32"
    >
      <motion.div className="absolute inset-0" style={{ y: imageY }} aria-hidden="true">
        <Image
          src={IMAGES.hero.src}
          alt={IMAGES.hero.alt}
          fill
          priority
          sizes="100vw"
          className="object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-[#08203a]/95 via-[#0d2c48]/80 to-[#123b63]/60" />
        <div className="absolute inset-0 grain opacity-50" />
      </motion.div>

      <motion.div
        style={{ y: contentY, opacity: fade }}
        className="relative mx-auto grid w-full max-w-7xl items-center gap-14 px-4 sm:px-6 lg:grid-cols-[1.08fr_0.92fr] lg:px-8"
      >
        <div>
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.6 }}
            className="inline-flex items-center gap-3 rounded-full border border-white/20 bg-white/5 px-4 py-1.5 text-[10px] font-semibold uppercase tracking-[0.3em] text-[#f3e8d6]/85 backdrop-blur"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-[#c99a44]" aria-hidden="true" />
            Pink City · Est. 2016
          </motion.div>

          <motion.h1
            variants={container}
            initial="hidden"
            animate="show"
            className="mt-6 font-display text-[2.7rem] leading-[0.98] tracking-[-0.02em] sm:text-6xl lg:text-[4.35rem]"
          >
            <span className="flex flex-wrap gap-x-3">
              {headline.map((token) => (
                <motion.span key={token} variants={word} className="inline-block">
                  {token}
                </motion.span>
              ))}
            </span>
            <motion.span variants={word} className="mt-1 block italic text-[#e6b98a]">
              blue door
            </motion.span>
            <motion.span variants={word} className="block">
              into slow mornings.
            </motion.span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 0.7 }}
            className="mt-6 max-w-lg text-[15px] leading-relaxed text-[#e8dfd0]/85 sm:text-base"
          >
            Filter coffee and rose-cardamom lattes, baked-at-dawn pastries, and Jaipur plates in a
            courtyard that slows the day down. Find us on {CAFE.addressShort}.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.85, duration: 0.7 }}
            className="mt-8 flex flex-wrap items-center gap-3"
          >
            <RippleLink
              href="#reserve"
              className="!bg-[#fbf6ec] !px-7 !py-3.5 !text-[#12263b] hover:!bg-white"
            >
              Reserve a table <span aria-hidden="true">→</span>
            </RippleLink>
            <RippleLink href="#menu" variant="ghost" className="!px-6 !py-3.5">
              Explore the menu
            </RippleLink>
          </motion.div>

          <motion.dl
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.05, duration: 0.8 }}
            className="mt-10 grid max-w-lg grid-cols-3 gap-4 border-t border-white/15 pt-6 text-[#f3e8d6]"
          >
            {[
              { label: "Guest rating", value: "4.9 / 5" },
              { label: "Open daily", value: "8 am – 10:30 pm" },
              { label: "All prices in", value: "₹ INR" },
            ].map((stat) => (
              <div key={stat.label}>
                <dt className="text-[9px] font-semibold uppercase tracking-[0.22em] text-[#a9c0d3]">{stat.label}</dt>
                <dd className="mt-1.5 text-sm font-semibold sm:text-[15px]">{stat.value}</dd>
              </div>
            ))}
          </motion.dl>
        </div>

        {/* Floating coffee cup composition */}
        <div className="relative hidden justify-center lg:flex">
          <motion.div
            className="absolute -top-8 right-6 h-52 w-52 rounded-full border border-[#e6b98a]/30"
            animate={reduce ? undefined : { rotate: 360 }}
            transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
            aria-hidden="true"
          />
          <motion.div
            className="relative w-[340px]"
            initial={{ opacity: 0, scale: 0.92, y: 24 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="float-slow relative overflow-hidden arch border border-white/20 bg-white/5 p-3 backdrop-blur-sm">
              <div className="relative aspect-[4/5] overflow-hidden arch">
                <Image
                  src={IMAGES.latte.src}
                  alt={IMAGES.latte.alt}
                  fill
                  sizes="(min-width: 1024px) 340px, 80vw"
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#08203a]/70 via-transparent to-transparent" />
              </div>
              <svg
                viewBox="0 0 80 120"
                className="steam pointer-events-none absolute left-1/2 top-6 h-24 w-16 -translate-x-1/2"
                aria-hidden="true"
                fill="none"
              >
                <path d="M30 110C20 92 42 84 32 64C24 48 40 42 34 22" stroke="#f6ead9" strokeWidth="3" strokeLinecap="round" opacity="0.6" />
                <path d="M48 108C38 90 58 82 48 62C40 46 56 40 50 20" stroke="#f6ead9" strokeWidth="2.4" strokeLinecap="round" opacity="0.45" />
                <path d="M64 112C56 94 74 86 64 66C56 50 70 44 64 26" stroke="#f6ead9" strokeWidth="2" strokeLinecap="round" opacity="0.3" />
              </svg>
              <div className="absolute inset-x-4 bottom-4 flex items-end justify-between gap-3 rounded-2xl bg-[#fbf6ec]/95 p-3 text-[#12263b] shadow-lg">
                <div>
                  <p className="text-[9px] font-semibold uppercase tracking-[0.22em] text-[#b1713f]">Signature</p>
                  <p className="font-display text-base leading-tight">Blue Door Latte</p>
                </div>
                <span className="rounded-full bg-[#123b63] px-3 py-1 text-xs font-semibold text-white">
                  {formatINR(190)}
                </span>
              </div>
            </div>

            <motion.div
              className="absolute -left-8 top-10 flex items-center gap-2 rounded-2xl border border-white/20 bg-[#fbf6ec]/95 px-3 py-2 text-[11px] font-semibold text-[#12263b] shadow-xl"
              animate={reduce ? undefined : { y: [0, -8, 0] }}
              transition={{ duration: 5.5, repeat: Infinity, ease: "easeInOut" }}
            >
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#123b63] text-[#fbf6ec]">
                <DoorMark className="h-4 w-4" />
              </span>
              Freshly pulled, always
            </motion.div>

            <motion.div
              className="absolute -bottom-6 -right-6 rounded-2xl border border-white/15 bg-[#123b63]/90 px-4 py-3 text-[11px] text-[#f3e8d6] shadow-xl backdrop-blur"
              animate={reduce ? undefined : { y: [0, 8, 0] }}
              transition={{ duration: 6.5, repeat: Infinity, ease: "easeInOut" }}
            >
              <p className="font-semibold uppercase tracking-[0.22em] text-[#e6b98a]">Today</p>
              <p className="mt-1 font-display text-base text-[#fbf6ec]">Kachori & filter, {formatINR(230)}</p>
            </motion.div>
          </motion.div>
        </div>
      </motion.div>

      <a
        href="#about"
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-[#c7d6e2] sm:flex"
      >
        Scroll
        <span className="flex h-9 w-5 items-start justify-center rounded-full border border-white/30 p-1">
          <motion.span
            className="h-1.5 w-1.5 rounded-full bg-[#e6b98a]"
            animate={reduce ? undefined : { y: [0, 16, 0] }}
            transition={{ duration: 1.9, repeat: Infinity, ease: "easeInOut" }}
          />
        </span>
      </a>
    </section>
  );
}

/** Infinite marquee strip below the hero. */
export function Marquee() {
  const items = [
    "Single-origin espresso",
    "Kadak masala chai",
    "Baked at dawn",
    "Pink City plates",
    "Courtyard seating",
    "Vegetarian friendly",
    "Open daily",
  ];
  return (
    <div className="overflow-hidden border-y border-line bg-surface-2 py-3">
      <div className="marquee-track flex w-max gap-8 whitespace-nowrap">
        {[...items, ...items].map((item, index) => (
          <span
            key={`${item}-${index}`}
            className="flex items-center gap-8 text-[11px] font-semibold uppercase tracking-[0.28em] text-muted"
          >
            {item}
            <span className="h-1 w-1 rounded-full bg-jaipur" aria-hidden="true" />
          </span>
        ))}
      </div>
    </div>
  );
}

/**
 * Startup environment validation with Zod.
 *
 * Rules:
 *  - Only values that are genuinely public may use the NEXT_PUBLIC_ prefix.
 *  - Anything secret stays server-only and is never imported by a client component.
 *  - Production hard-fails when a required secret is missing; development falls
 *    back to a clearly-labelled local value so the app remains runnable.
 */
import { z } from "zod";

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  DATABASE_URL: z.string().url().startsWith("postgres"),
  AUTH_SECRET: z.string().min(32, "AUTH_SECRET must be at least 32 characters"),
  ADMIN_EMAIL: z.string().email(),
  ADMIN_PASSWORD: z.string().min(10, "ADMIN_PASSWORD must be at least 10 characters"),
  ADMIN_TOTP_SECRET: z.string().optional(),
  NEXT_PUBLIC_SITE_URL: z.string().url().default("http://localhost:3000"),
  ALLOWED_ORIGIN: z.string().url().optional(),
});

export type Env = z.infer<typeof envSchema>;

let cached: Env | null = null;

/** Validated server env. Throws a redacted error if misconfigured. */
export function env(): Env {
  if (cached) return cached;

  const parsed = envSchema.safeParse({
    NODE_ENV: process.env.NODE_ENV,
    DATABASE_URL: process.env.DATABASE_URL,
    AUTH_SECRET: process.env.AUTH_SECRET,
    ADMIN_EMAIL: process.env.ADMIN_EMAIL,
    ADMIN_PASSWORD: process.env.ADMIN_PASSWORD,
    ADMIN_TOTP_SECRET: process.env.ADMIN_TOTP_SECRET || undefined,
    NEXT_PUBLIC_SITE_URL: process.env.NEXT_PUBLIC_SITE_URL,
    ALLOWED_ORIGIN: process.env.ALLOWED_ORIGIN || undefined,
  });

  if (!parsed.success) {
    // Never echo secret values — only the field names that failed validation.
    const fields = parsed.error.issues.map((issue) => issue.path.join(".")).join(", ");
    throw new Error(`Invalid environment configuration: ${fields}`);
  }

  cached = parsed.data;
  return cached;
}

/** Public base URL used for canonical links, OG tags and CORS allow-lists. */
export function siteUrl(): string {
  return env().ALLOWED_ORIGIN ?? env().NEXT_PUBLIC_SITE_URL;
}

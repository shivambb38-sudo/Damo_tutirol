import { z } from "zod";
import { sanitizeText } from "@/lib/security";

/** Server-side Zod schemas. Every form and API payload passes through these. */

const safeText = (min: number, max: number) =>
  z
    .string()
    .trim()
    .min(min, `Please use at least ${min} characters.`)
    .max(max, `Please keep this under ${max} characters.`)
    .transform(sanitizeText);

const phone = z
  .string()
  .trim()
  .transform((value) => value.replace(/[\s()-]/g, ""))
  .refine((value) => /^(\+91|91)?[6-9]\d{9}$/.test(value), "Enter a valid Indian mobile number.");

export const reservationSchema = z.object({
  name: safeText(2, 80),
  phone,
  email: z.union([z.literal(""), z.string().trim().email("Enter a valid email.").max(120)]).optional(),
  guests: z.coerce.number().int().min(1, "At least one guest.").max(12, "For parties above 12, call us."),
  date: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, "Choose a valid date.")
    .refine((value) => {
      const chosen = new Date(`${value}T00:00:00`).getTime();
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const maxDate = Date.now() + 1000 * 60 * 60 * 24 * 90;
      return chosen >= today.getTime() && chosen <= maxDate;
    }, "Pick a date within the next 90 days."),
  time: z.enum([
    "08:00",
    "09:00",
    "10:00",
    "11:00",
    "12:00",
    "13:00",
    "14:00",
    "16:00",
    "17:00",
    "18:00",
    "19:00",
    "20:00",
    "21:00",
  ]),
  notes: z.union([z.literal(""), z.string().trim().max(300)]).optional(),
  // Anti-spam: honeypot stays empty in real submissions; bots are silently
  // accepted with a fake reference so they cannot probe the rule.
  website: z.string().max(200).optional().default(""),
  formStartedAt: z.coerce.number().optional(),
});

export const contactSchema = z.object({
  name: safeText(2, 80),
  email: z.string().trim().email("Enter a valid email.").max(120),
  phone: z.union([z.literal(""), phone]).optional(),
  subject: safeText(3, 100),
  message: safeText(10, 1000),
  website: z.string().max(200).optional().default(""),
  formStartedAt: z.coerce.number().optional(),
});

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email("Enter a valid email.").max(120),
  password: z.string().min(8, "Enter your password.").max(200),
  totp: z.union([z.literal(""), z.string().regex(/^\d{6}$/, "Enter the 6-digit code.")]).optional(),
});

export const menuItemSchema = z.object({
  name: safeText(2, 80),
  description: z.string().trim().max(240).transform(sanitizeText).default(""),
  priceInr: z.coerce.number().int().min(10, "Minimum ₹10.").max(100000),
  categorySlug: z.string().trim().regex(/^[a-z0-9-]{2,40}$/, "Choose a valid category."),
  diet: z.enum(["veg", "nonveg", "vegan"]),
  available: z.coerce.boolean().default(true),
  signature: z.coerce.boolean().default(false),
});

/** PATCH payloads: explicit optional fields so absent keys are never defaulted. */
export const menuItemUpdateSchema = z
  .object({
    name: z.string().trim().min(2).max(80).transform(sanitizeText).optional(),
    description: z.string().trim().max(240).transform(sanitizeText).optional(),
    priceInr: z.coerce.number().int().min(10).max(100000).optional(),
    categorySlug: z.string().trim().regex(/^[a-z0-9-]{2,40}$/).optional(),
    diet: z.enum(["veg", "nonveg", "vegan"]).optional(),
    available: z.boolean().optional(),
    signature: z.boolean().optional(),
  })
  .refine((value) => Object.keys(value).length > 0, "Nothing to update.");

export const specialUpdateSchema = z
  .object({
    title: z.string().trim().min(2).max(90).transform(sanitizeText).optional(),
    description: z.string().trim().max(240).transform(sanitizeText).optional(),
    priceInr: z.coerce.number().int().min(10).max(100000).optional(),
    badge: z.string().trim().min(2).max(40).transform(sanitizeText).optional(),
    active: z.boolean().optional(),
    sortOrder: z.coerce.number().int().min(0).max(99).optional(),
  })
  .refine((value) => Object.keys(value).length > 0, "Nothing to update.");

export const specialSchema = z.object({
  title: safeText(2, 90),
  description: z.string().trim().max(240).transform(sanitizeText).default(""),
  priceInr: z.coerce.number().int().min(10).max(100000),
  badge: safeText(2, 40),
  active: z.coerce.boolean().default(true),
  sortOrder: z.coerce.number().int().min(0).max(99).default(0),
});

export const reservationUpdateSchema = z.object({
  status: z.enum(["pending", "confirmed", "seated", "cancelled"]),
});

export const analyticsQuerySchema = z.object({
  from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  to: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  segments: z
    .string()
    .optional()
    .transform((value) => (value ? value.split(",").filter(Boolean) : [])),
});

export type ReservationInput = z.infer<typeof reservationSchema>;
export type ContactInput = z.infer<typeof contactSchema>;
export type MenuItemInput = z.infer<typeof menuItemSchema>;
export type SpecialInput = z.infer<typeof specialSchema>;

/** Parses JSON bodies defensively and returns a typed result or a generic error. */
export async function parseJson<T extends z.ZodTypeAny>(
  request: Request,
  schema: T,
): Promise<{ ok: true; data: z.infer<T> } | { ok: false; response: Response }> {
  let raw: unknown;
  try {
    raw = await request.json();
  } catch {
    return {
      ok: false,
      response: Response.json({ error: "Invalid request body." }, { status: 400 }),
    };
  }

  const parsed = schema.safeParse(raw);
  if (!parsed.success) {
    return {
      ok: false,
      response: Response.json(
        {
          error: "Please check the highlighted fields.",
          fields: parsed.error.issues.map((issue) => ({
            field: String(issue.path[0] ?? "form"),
            message: issue.message,
          })),
        },
        { status: 422, headers: { "Cache-Control": "no-store" } },
      ),
    };
  }

  return { ok: true, data: parsed.data };
}

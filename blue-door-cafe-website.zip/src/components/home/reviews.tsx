"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { SectionHeading } from "@/components/motion-primitives";
import type { ReviewRow } from "@/lib/data";

function Stars({ rating }: { rating: number }) {
  return (
    <span className="flex gap-0.5" aria-label={`${rating} out of 5 stars`}>
      {Array.from({ length: 5 }).map((_, index) => (
        <span key={index} className={index < rating ? "text-gold" : "text-line"} aria-hidden="true">
          ★
        </span>
      ))}
    </span>
  );
}

export function Reviews({ reviews }: { reviews: ReviewRow[] }) {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const reduce = useReducedMotion();
  const count = reviews.length;

  useEffect(() => {
    if (paused || reduce || count <= 1) return;
    const timer = window.setInterval(() => setIndex((current) => (current + 1) % count), 5500);
    return () => window.clearInterval(timer);
  }, [count, paused, reduce]);

  const average = useMemo(() => {
    if (count === 0) return "5.0";
    return (reviews.reduce((sum, review) => sum + review.rating, 0) / count).toFixed(1);
  }, [count, reviews]);

  if (count === 0) return null;
  const review = reviews[index % count]!;

  return (
    <section id="reviews" className="relative scroll-mt-24 overflow-hidden bg-surface py-20 sm:py-24 lg:py-28">
      <div
        className="pointer-events-none absolute -left-24 top-10 h-64 w-64 rounded-full bg-jaipur/10 blur-2xl"
        aria-hidden="true"
      />
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Guest book"
          title="Kind words from the courtyard."
          description={`${average} out of 5 across ${count} featured reviews from Google, Zomato and Instagram.`}
        />

        <div
          className="relative mt-12"
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
          onFocusCapture={() => setPaused(true)}
          onBlurCapture={() => setPaused(false)}
        >
          <div className="relative min-h-[290px] overflow-hidden rounded-[2rem] border border-line bg-card p-6 shadow-warm sm:min-h-[260px] sm:p-10">
            <span className="pointer-events-none absolute -right-2 -top-6 font-display text-[9rem] leading-none text-jaipur/15" aria-hidden="true">
              &rdquo;
            </span>
            <AnimatePresence mode="wait">
              <motion.figure
                key={review.id}
                initial={reduce ? { opacity: 0 } : { opacity: 0, x: 40, scale: 0.98 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                exit={reduce ? { opacity: 0 } : { opacity: 0, x: -40, scale: 0.98 }}
                transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                className="relative"
              >
                <Stars rating={review.rating} />
                <blockquote className="mt-4 max-w-3xl font-display text-xl leading-snug text-ink sm:text-2xl">
                  {review.quote}
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-3">
                  <span className="flex h-11 w-11 items-center justify-center rounded-full bg-brand font-display text-lg text-white">
                    {review.guestName.charAt(0)}
                  </span>
                  <span>
                    <span className="block text-sm font-semibold text-ink">{review.guestName}</span>
                    <span className="block text-[11px] uppercase tracking-[0.2em] text-muted">via {review.source}</span>
                  </span>
                </figcaption>
              </motion.figure>
            </AnimatePresence>
          </div>

          <div className="mt-6 flex items-center justify-between">
            <div className="flex items-center gap-2" role="tablist" aria-label="Choose a review">
              {reviews.map((item, dotIndex) => (
                <button
                  key={item.id}
                  type="button"
                  role="tab"
                  aria-selected={dotIndex === index}
                  aria-label={`Review ${dotIndex + 1} of ${count}`}
                  onClick={() => setIndex(dotIndex)}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    dotIndex === index ? "w-8 bg-brand" : "w-2 bg-line hover:bg-jaipur/60"
                  }`}
                />
              ))}
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setIndex((current) => (current - 1 + count) % count)}
                aria-label="Previous review"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-line text-ink transition-colors hover:bg-surface-2"
              >
                ←
              </button>
              <button
                type="button"
                onClick={() => setIndex((current) => (current + 1) % count)}
                aria-label="Next review"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-line text-ink transition-colors hover:bg-surface-2"
              >
                →
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

import type { ReactNode } from "react";
import { CustomCursor, DoorIntro, Navbar, ScrollProgress } from "@/components/site-chrome";
import { Footer } from "@/components/home/sections";

export default function SiteLayout({ children }: { children: ReactNode }) {
  return (
    <>
      <DoorIntro />
      <ScrollProgress />
      <CustomCursor />
      <Navbar />
      <main id="main">{children}</main>
      <Footer />
    </>
  );
}

import { redirect } from "next/navigation";
import { Dashboard } from "@/components/admin/dashboard";
import { requireRole } from "@/lib/auth";
import { getAnalytics } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function AdminOverviewPage() {
  const session = await requireRole("analytics:read");
  if (!session) redirect("/admin/login");

  const to = new Date();
  const from = new Date(to.getTime() - 29 * 86_400_000);
  const payload = await getAnalytics({
    from: from.toISOString().slice(0, 10),
    to: to.toISOString().slice(0, 10),
    segments: [],
  });

  return <Dashboard initial={payload} role={session.role} />;
}

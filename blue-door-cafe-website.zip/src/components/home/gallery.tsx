"use client";

import Image from "next/image";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useCallback, useEffect, useState } from "react";
import { Reveal, SectionHeading } from "@/components/motion-primitives";
import { IMAGES } from "@/lib/images";

const SPANS = [
  "sm:col-span-2 sm:row-span-2",
  "sm:col-span-1",
  "sm:col-span-1",
  "sm:col-span-1",
  "sm:col-span-1",
  "sm:col-span-2",
];

export function Gallery() {
  const [active, setActive] = useState<number | null>(null);
  const reduce = useReducedMotion();
  const photos = IMAGES.gallery;

  const close = useCallback(() => setActive(null), []);
  const step = useCallback(
    (direction: 1 | -1) => {
      setActive((current) => (current === null ? null : (current + direction + photos.length) % photos.length));
    },
    [photos.length],
  );

  useEffect(() => {
    if (active === null) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") close();
      if (event.key === "ArrowRight") step(1);
      if (event.key === "ArrowLeft") step(-1);
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [active, close, step]);

  return (
    <section id="gallery" className="relative scroll-mt-24 bg-surface-2 py-20 sm:py-24 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Inside the blue door"
          title="Arches, amber light and the hum of the grinder."
          description="A courtyard built for long conversations. Tap any frame to look closer."
        />

        <div className="mt-12 grid auto-rows-[170px] grid-cols-2 gap-3 sm:auto-rows-[190px] sm:grid-cols-4">
          {photos.map((photo, index) => (
            <Reveal key={photo.src} delay={index * 0.05} className={`${SPANS[index]} h-full`}>
              <button
                type="button"
                onClick={() => setActive(index)}
                className="group relative block h-full w-full overflow-hidden rounded-2xl border border-line bg-card focus-visible:outline-offset-4"
                aria-label={`Open photo: ${photo.caption}`}
              >
                <Image
                  src={photo.src}
                  alt={photo.alt}
                  fill
                  sizes="(max-width: 640px) 50vw, (max-width: 1024px) 40vw, 30vw"
                  loading="lazy"
                  className="object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                />
                <span className="absolute inset-0 bg-gradient-to-t from-[#08192b]/85 via-[#08192b]/10 to-transparent opacity-70 transition-opacity duration-500 group-hover:opacity-95" />
                <span className="absolute inset-x-3 bottom-3 translate-y-2 text-left text-[11px] font-semibold uppercase tracking-[0.18em] text-[#fbf6ec] opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                  {photo.caption}
                </span>
                <span className="absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-full bg-[#fbf6ec]/90 text-sm text-[#123b63] opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                  ⤢
                </span>
              </button>
            </Reveal>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {active !== null ? (
          <motion.div
            className="fixed inset-0 z-[95] flex items-center justify-center bg-[#04121f]/90 p-4 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={close}
            role="dialog"
            aria-modal="true"
            aria-label="Photo viewer"
          >
            <motion.div
              className="relative w-full max-w-3xl"
              initial={reduce ? { opacity: 0 } : { opacity: 0, scale: 0.94, y: 18 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={reduce ? { opacity: 0 } : { opacity: 0, scale: 0.96, y: 12 }}
              transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              onClick={(event) => event.stopPropagation()}
            >
              <div className="relative aspect-[4/3] overflow-hidden rounded-3xl border border-white/15">
                <Image
                  src={photos[active]!.src}
                  alt={photos[active]!.alt}
                  fill
                  sizes="(max-width: 1024px) 100vw, 768px"
                  className="object-cover"
                />
              </div>
              <div className="mt-4 flex items-center justify-between gap-4 text-[#fbf6ec]">
                <p className="font-display text-lg">{photos[active]!.caption}</p>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => step(-1)}
                    className="flex h-9 w-9 items-center justify-center rounded-full border border-white/30 transition-colors hover:bg-white/15"
                    aria-label="Previous photo"
                  >
                    ←
                  </button>
                  <button
                    type="button"
                    onClick={() => step(1)}
                    className="flex h-9 w-9 items-center justify-center rounded-full border border-white/30 transition-colors hover:bg-white/15"
                    aria-label="Next photo"
                  >
                    →
                  </button>
                  <button
                    type="button"
                    onClick={close}
                    className="ml-2 rounded-full bg-[#fbf6ec] px-4 py-2 text-xs font-semibold text-[#12263b]"
                  >
                    Close
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </section>
  );
}

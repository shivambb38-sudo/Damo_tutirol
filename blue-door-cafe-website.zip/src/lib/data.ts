import { and, asc, desc, eq, gte, inArray, lte, ne, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  contactMessages,
  menuCategories,
  menuItems,
  orderItems,
  orders,
  reservations,
  reviews,
  specials,
} from "@/db/schema";
import { ensureSeeded } from "@/db/seed";

/** Server-side read layer. Every query is parameterised through Drizzle. */

export type MenuItemRow = {
  id: number;
  name: string;
  description: string;
  priceInr: number;
  categorySlug: string;
  diet: "veg" | "nonveg" | "vegan" | string;
  available: boolean;
  signature: boolean;
};

export type CategoryRow = { id: number; slug: string; name: string; blurb: string; sortOrder: number };

export type SpecialRow = {
  id: number;
  title: string;
  description: string;
  priceInr: number;
  badge: string;
  active: boolean;
  sortOrder: number;
};

export type ReviewRow = { id: number; guestName: string; rating: number; quote: string; source: string };

export async function getPublicData() {
  await ensureSeeded();
  const [categories, items, dailySpecials, reviewList] = await Promise.all([
    db.select().from(menuCategories).orderBy(asc(menuCategories.sortOrder)),
    db
      .select()
      .from(menuItems)
      .orderBy(asc(menuItems.categorySlug), asc(menuItems.id)),
    db.select().from(specials).where(eq(specials.active, true)).orderBy(asc(specials.sortOrder)),
    db.select().from(reviews).where(eq(reviews.featured, true)).orderBy(asc(reviews.id)),
  ]);
  return { categories, items, specials: dailySpecials, reviews: reviewList };
}

export async function getMenu() {
  await ensureSeeded();
  const [categories, items] = await Promise.all([
    db.select().from(menuCategories).orderBy(asc(menuCategories.sortOrder)),
    db.select().from(menuItems).orderBy(asc(menuItems.id)),
  ]);
  return { categories, items };
}

export async function getSpecials() {
  await ensureSeeded();
  return db.select().from(specials).orderBy(asc(specials.sortOrder), asc(specials.id));
}

export async function getReservations(limit = 200) {
  await ensureSeeded();
  return db
    .select()
    .from(reservations)
    .orderBy(desc(reservations.createdAt))
    .limit(limit);
}

export async function getMessages(limit = 50) {
  await ensureSeeded();
  return db.select().from(contactMessages).orderBy(desc(contactMessages.createdAt)).limit(limit);
}

export type AnalyticsRange = { from: string; to: string; segments: string[] };

export type Kpi = {
  key: "revenue" | "orders" | "aov" | "returning";
  label: string;
  value: number;
  previous: number;
  deltaPct: number;
  format: "currency" | "number" | "percent";
  hint: string;
};

export type AnalyticsPayload = {
  range: { from: string; to: string; days: number };
  segments: string[];
  channels: string[];
  kpis: Kpi[];
  series: { day: string; revenue: number; orders: number; aov: number }[];
  channelSplit: { channel: string; revenue: number; orders: number }[];
  categorySplit: { category: string; revenue: number; units: number }[];
  weekday: { weekday: number; orders: number; revenue: number }[];
  topItems: { name: string; units: number; revenue: number }[];
  rows: {
    id: number;
    reference: string;
    orderedAt: string;
    channel: string;
    customerName: string;
    itemsCount: number;
    totalInr: number;
    status: string;
    returningGuest: boolean;
  }[];
};

const DAY_MS = 86_400_000;

function dayStart(iso: string): Date {
  return new Date(`${iso}T00:00:00.000Z`);
}

function dayEnd(iso: string): Date {
  return new Date(`${iso}T23:59:59.999Z`);
}

export const ANALYTICS_CHANNELS = ["dine-in", "takeaway", "delivery", "catering"] as const;

/**
 * Aggregates the analytics fact tables for a date range + segment selection.
 * Refunds are excluded so revenue matches the P&L view.
 */
export async function getAnalytics({ from, to, segments }: AnalyticsRange): Promise<AnalyticsPayload> {
  await ensureSeeded();

  const start = dayStart(from);
  const end = dayEnd(to);
  const span = end.getTime() - start.getTime() + 1;
  const prevEnd = new Date(start.getTime() - 1);
  const prevStart = new Date(prevEnd.getTime() - span + 1);

  const baseFilter = (windowStart: Date, windowEnd: Date) => {
    const clauses = [
      gte(orders.orderedAt, windowStart),
      lte(orders.orderedAt, windowEnd),
      ne(orders.status, "refunded"),
    ];
    if (segments.length > 0) clauses.push(inArray(orders.channel, segments));
    return and(...clauses);
  };

  const totalsQuery = (windowStart: Date, windowEnd: Date) =>
    db
      .select({
        revenue: sql<number>`coalesce(sum(${orders.totalInr}), 0)::int`,
        orderCount: sql<number>`count(*)::int`,
        aov: sql<number>`coalesce(round(avg(${orders.totalInr})), 0)::int`,
        returning: sql<number>`coalesce(sum(case when ${orders.returningGuest} then 1 else 0 end), 0)::int`,
      })
      .from(orders)
      .where(baseFilter(windowStart, windowEnd));

  const [current, previous, daily, channelSplit, categorySplit, weekday, topItems, rows] =
    await Promise.all([
      totalsQuery(start, end),
      totalsQuery(prevStart, prevEnd),
      db
        .select({
          day: sql<string>`to_char(${orders.orderedAt}, 'YYYY-MM-DD')`,
          revenue: sql<number>`coalesce(sum(${orders.totalInr}), 0)::int`,
          orders: sql<number>`count(*)::int`,
        })
        .from(orders)
        .where(baseFilter(start, end))
        .groupBy(sql`to_char(${orders.orderedAt}, 'YYYY-MM-DD')`)
        .orderBy(sql`to_char(${orders.orderedAt}, 'YYYY-MM-DD')`),
      db
        .select({
          channel: orders.channel,
          revenue: sql<number>`coalesce(sum(${orders.totalInr}), 0)::int`,
          orders: sql<number>`count(*)::int`,
        })
        .from(orders)
        .where(baseFilter(start, end))
        .groupBy(orders.channel),
      db
        .select({
          category: orderItems.categorySlug,
          revenue: sql<number>`coalesce(sum(${orderItems.quantity} * ${orderItems.unitPriceInr}), 0)::int`,
          units: sql<number>`coalesce(sum(${orderItems.quantity}), 0)::int`,
        })
        .from(orderItems)
        .innerJoin(orders, eq(orderItems.orderId, orders.id))
        .where(baseFilter(start, end))
        .groupBy(orderItems.categorySlug),
      db
        .select({
          weekday: sql<number>`extract(isodow from ${orders.orderedAt})::int`,
          orders: sql<number>`count(*)::int`,
          revenue: sql<number>`coalesce(sum(${orders.totalInr}), 0)::int`,
        })
        .from(orders)
        .where(baseFilter(start, end))
        .groupBy(sql`extract(isodow from ${orders.orderedAt})`)
        .orderBy(sql`extract(isodow from ${orders.orderedAt})`),
      db
        .select({
          name: orderItems.itemName,
          units: sql<number>`coalesce(sum(${orderItems.quantity}), 0)::int`,
          revenue: sql<number>`coalesce(sum(${orderItems.quantity} * ${orderItems.unitPriceInr}), 0)::int`,
        })
        .from(orderItems)
        .innerJoin(orders, eq(orderItems.orderId, orders.id))
        .where(baseFilter(start, end))
        .groupBy(orderItems.itemName)
        .orderBy(sql`coalesce(sum(${orderItems.quantity} * ${orderItems.unitPriceInr}), 0) desc`)
        .limit(6),
      db
        .select({
          id: orders.id,
          reference: orders.reference,
          orderedAt: orders.orderedAt,
          channel: orders.channel,
          customerName: orders.customerName,
          itemsCount: orders.itemsCount,
          totalInr: orders.totalInr,
          status: orders.status,
          returningGuest: orders.returningGuest,
        })
        .from(orders)
        .where(baseFilter(start, end))
        .orderBy(desc(orders.orderedAt))
        .limit(600),
    ]);

  const now = current[0] ?? { revenue: 0, orderCount: 0, aov: 0, returning: 0 };
  const before = previous[0] ?? { revenue: 0, orderCount: 0, aov: 0, returning: 0 };

  const delta = (latest: number, earlier: number) => {
    if (earlier === 0) return latest === 0 ? 0 : 100;
    return Number((((latest - earlier) / earlier) * 100).toFixed(1));
  };

  const returningRate = now.orderCount ? (now.returning / now.orderCount) * 100 : 0;
  const previousReturningRate = before.orderCount ? (before.returning / before.orderCount) * 100 : 0;

  const kpis: Kpi[] = [
    {
      key: "revenue",
      label: "Net revenue",
      value: now.revenue,
      previous: before.revenue,
      deltaPct: delta(now.revenue, before.revenue),
      format: "currency",
      hint: "Refunds excluded",
    },
    {
      key: "orders",
      label: "Orders",
      value: now.orderCount,
      previous: before.orderCount,
      deltaPct: delta(now.orderCount, before.orderCount),
      format: "number",
      hint: "Completed + pending",
    },
    {
      key: "aov",
      label: "Avg. order value",
      value: now.aov,
      previous: before.aov,
      deltaPct: delta(now.aov, before.aov),
      format: "currency",
      hint: "Per paid order",
    },
    {
      key: "returning",
      label: "Returning guests",
      value: Number(returningRate.toFixed(1)),
      previous: Number(previousReturningRate.toFixed(1)),
      deltaPct: Number((returningRate - previousReturningRate).toFixed(1)),
      format: "percent",
      hint: "Share of repeat guests",
    },
  ];

  const seriesMap = new Map(daily.map((row) => [row.day, row]));
  const series: AnalyticsPayload["series"] = [];
  for (let cursor = new Date(start); cursor <= end; cursor = new Date(cursor.getTime() + DAY_MS)) {
    const key = cursor.toISOString().slice(0, 10);
    const row = seriesMap.get(key);
    series.push({
      day: key,
      revenue: row?.revenue ?? 0,
      orders: row?.orders ?? 0,
      aov: row && row.orders > 0 ? Math.round(row.revenue / row.orders) : 0,
    });
  }

  return {
    range: { from, to, days: series.length },
    segments,
    channels: [...ANALYTICS_CHANNELS],
    kpis,
    series,
    channelSplit,
    categorySplit,
    weekday: [1, 2, 3, 4, 5, 6, 7].map((weekdayNumber) => {
      const match = weekday.find((row) => row.weekday === weekdayNumber);
      return {
        weekday: weekdayNumber,
        orders: match?.orders ?? 0,
        revenue: match?.revenue ?? 0,
      };
    }),
    topItems,
    rows: rows.map((row) => ({
      ...row,
      orderedAt: row.orderedAt.toISOString(),
    })),
  };
}

import { db } from "@/db";
import { auditLog, menuItems } from "@/db/schema";
import { guardAdmin, noStoreJson } from "@/lib/api-guard";
import { getMenu } from "@/lib/data";
import { menuItemSchema } from "@/lib/validation";
import { parseJson } from "@/lib/validation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const guard = await guardAdmin(request, "analytics:read");
  if (guard.response) return guard.response;

  try {
    return noStoreJson(await getMenu());
  } catch {
    return noStoreJson({ error: "Menu is unavailable right now." }, 500);
  }
}

export async function POST(request: Request) {
  const guard = await guardAdmin(request, "menu:write");
  if (guard.response) return guard.response;

  const parsed = await parseJson(request, menuItemSchema);
  if (!parsed.ok) return parsed.response;

  try {
    const [created] = await db.insert(menuItems).values(parsed.data).returning();
    await db.insert(auditLog).values({
      actorId: guard.session.sub,
      action: "create",
      entity: "menu_item",
      entityId: String(created?.id ?? ""),
    });
    return noStoreJson({ item: created }, 201);
  } catch {
    return noStoreJson({ error: "Could not save this menu item." }, 500);
  }
}

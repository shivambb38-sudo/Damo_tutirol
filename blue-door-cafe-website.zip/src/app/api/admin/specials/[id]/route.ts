import { eq } from "drizzle-orm";
import { db } from "@/db";
import { auditLog, specials } from "@/db/schema";
import { guardAdmin, noStoreJson } from "@/lib/api-guard";
import { parseJson, specialUpdateSchema } from "@/lib/validation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

function parseId(raw: string): number | null {
  const id = Number(raw);
  return Number.isInteger(id) && id > 0 && id < 1_000_000 ? id : null;
}

export async function PATCH(request: Request, { params }: Params) {
  const guard = await guardAdmin(request, "specials:write");
  if (guard.response) return guard.response;

  const { id: rawId } = await params;
  const id = parseId(rawId);
  if (!id) return noStoreJson({ error: "Invalid special." }, 400);

  const parsed = await parseJson(request, specialUpdateSchema);
  if (!parsed.ok) return parsed.response;

  try {
    const [updated] = await db.update(specials).set(parsed.data).where(eq(specials.id, id)).returning();
    if (!updated) return noStoreJson({ error: "Special not found." }, 404);

    await db.insert(auditLog).values({
      actorId: guard.session.sub,
      action: "update",
      entity: "special",
      entityId: String(id),
    });
    return noStoreJson({ special: updated });
  } catch {
    return noStoreJson({ error: "Could not update this special." }, 500);
  }
}

export async function DELETE(request: Request, { params }: Params) {
  const guard = await guardAdmin(request, "specials:write");
  if (guard.response) return guard.response;

  const { id: rawId } = await params;
  const id = parseId(rawId);
  if (!id) return noStoreJson({ error: "Invalid special." }, 400);

  try {
    const [deleted] = await db.delete(specials).where(eq(specials.id, id)).returning({ id: specials.id });
    if (!deleted) return noStoreJson({ error: "Special not found." }, 404);
    await db.insert(auditLog).values({
      actorId: guard.session.sub,
      action: "delete",
      entity: "special",
      entityId: String(id),
    });
    return noStoreJson({ ok: true });
  } catch {
    return noStoreJson({ error: "Could not delete this special." }, 500);
  }
}

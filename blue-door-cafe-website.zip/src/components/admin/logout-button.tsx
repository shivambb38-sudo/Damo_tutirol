"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { apiRequest } from "@/lib/client-api";

export function LogoutButton({ compact = false }: { compact?: boolean }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  return (
    <button
      type="button"
      disabled={busy}
      onClick={async () => {
        setBusy(true);
        await apiRequest("/api/auth/logout", { method: "POST" });
        router.replace("/admin/login");
        router.refresh();
      }}
      className={`rounded-full border border-line font-semibold text-ink transition-colors hover:border-jaipur/60 hover:text-jaipur disabled:opacity-50 ${
        compact ? "px-3 py-1.5 text-[11px]" : "px-3.5 py-2 text-xs"
      }`}
    >
      {busy ? "Signing out…" : "Sign out"}
    </button>
  );
}

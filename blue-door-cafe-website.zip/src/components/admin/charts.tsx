"use client";

import { motion, useReducedMotion } from "framer-motion";
import { useMemo, useState } from "react";
import { formatCompactINR, formatINR, formatNumber } from "@/lib/format";

export const CHART_COLORS = [
  "var(--brand-soft)",
  "var(--jaipur)",
  "var(--gold)",
  "var(--accent)",
  "#2f7d5a",
  "#7a6bb0",
];

type Point = { label: string; value: number };

/** Smoothing helper keeps the line legible without pulling in a chart library. */
function buildPath(points: { x: number; y: number }[]): string {
  if (points.length === 0) return "";
  if (points.length === 1) return `M ${points[0]!.x} ${points[0]!.y}`;
  return points
    .map((point, index) => {
      if (index === 0) return `M ${point.x} ${point.y}`;
      const previous = points[index - 1]!;
      const controlX = (previous.x + point.x) / 2;
      return `C ${controlX} ${previous.y} ${controlX} ${point.y} ${point.x} ${point.y}`;
    })
    .join(" ");
}

export function TrendLineChart({
  data,
  mode = "currency",
  height = 260,
}: {
  data: Point[];
  mode?: "currency" | "number";
  height?: number;
}) {
  const reduce = useReducedMotion();
  const [hover, setHover] = useState<number | null>(null);
  const width = 820;
  const padding = { top: 18, right: 18, bottom: 28, left: 48 };
  const innerW = width - padding.left - padding.right;
  const innerH = height - padding.top - padding.bottom;

  const { max, points, labels } = useMemo(() => {
    const values = data.map((d) => d.value);
    const highest = Math.max(1, ...values);
    const maxValue = Math.ceil(highest / 4) * 4 || 4;
    const step = data.length > 1 ? innerW / (data.length - 1) : 0;
    const coords = data.map((point, index) => ({
      x: padding.left + index * step,
      y: padding.top + innerH - (point.value / maxValue) * innerH,
    }));
    const tickEvery = Math.max(1, Math.ceil(data.length / 6));
    const tickLabels = data
      .map((point, index) => ({ ...point, index }))
      .filter((point) => point.index % tickEvery === 0 || point.index === data.length - 1);
    return { max: maxValue, points: coords, labels: tickLabels };
  }, [data, innerH, innerW, padding.left, padding.top]);

  const path = buildPath(points);
  const area = points.length
    ? `${path} L ${points[points.length - 1]!.x} ${padding.top + innerH} L ${points[0]!.x} ${padding.top + innerH} Z`
    : "";
  const hoverPoint = hover !== null ? points[hover] : null;
  const hoverData = hover !== null ? data[hover] : null;
  const format = (value: number) => (mode === "currency" ? formatINR(value) : formatNumber(value));

  return (
    <div className="relative w-full">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="h-auto w-full"
        role="img"
        aria-label="Trend chart"
        onPointerLeave={() => setHover(null)}
        onPointerMove={(event) => {
          const rect = event.currentTarget.getBoundingClientRect();
          const x = ((event.clientX - rect.left) / rect.width) * width;
          const ratio = (x - padding.left) / (innerW || 1);
          const index = Math.round(ratio * (data.length - 1));
          setHover(Math.min(data.length - 1, Math.max(0, index)));
        }}
      >
        <defs>
          <linearGradient id="trend-fill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--brand-soft)" stopOpacity="0.35" />
            <stop offset="100%" stopColor="var(--brand-soft)" stopOpacity="0" />
          </linearGradient>
        </defs>

        {[0, 0.25, 0.5, 0.75, 1].map((tick) => {
          const y = padding.top + innerH * tick;
          const value = Math.round(max * (1 - tick));
          return (
            <g key={tick}>
              <line
                x1={padding.left}
                x2={width - padding.right}
                y1={y}
                y2={y}
                stroke="var(--line)"
                strokeDasharray="3 6"
                strokeWidth="1"
              />
              <text x={padding.left - 8} y={y + 4} textAnchor="end" fontSize="10" fill="var(--muted)">
                {mode === "currency" ? formatCompactINR(value) : formatNumber(value)}
              </text>
            </g>
          );
        })}

        {area ? <motion.path d={area} fill="url(#trend-fill)" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6 }} /> : null}
        <motion.path
          key={path}
          d={path}
          fill="none"
          stroke="var(--brand-soft)"
          strokeWidth="2.5"
          strokeLinecap="round"
          initial={reduce ? { opacity: 0 } : { pathLength: 0, opacity: 0.4 }}
          animate={{ pathLength: 1, opacity: 1 }}
          transition={{ duration: 0.9, ease: "easeOut" }}
        />

        {labels.map((label) => {
          const x = padding.left + (label.index / Math.max(1, data.length - 1)) * innerW;
          return (
            <text key={label.label} x={x} y={height - 8} textAnchor="middle" fontSize="10" fill="var(--muted)">
              {label.label}
            </text>
          );
        })}

        {hoverPoint && hoverData ? (
          <g>
            <line
              x1={hoverPoint.x}
              x2={hoverPoint.x}
              y1={padding.top}
              y2={padding.top + innerH}
              stroke="var(--jaipur)"
              strokeDasharray="4 4"
            />
            <circle cx={hoverPoint.x} cy={hoverPoint.y} r="9" fill="var(--jaipur)" opacity="0.18" />
            <circle cx={hoverPoint.x} cy={hoverPoint.y} r="4" fill="var(--jaipur)" stroke="var(--card)" strokeWidth="2" />
          </g>
        ) : null}
      </svg>

      {hoverPoint && hoverData ? (
        <div
          className="pointer-events-none absolute z-10 -translate-x-1/2 -translate-y-full rounded-xl border border-line bg-card px-3 py-2 text-xs shadow-warm"
          style={{ left: `${(hoverPoint.x / width) * 100}%`, top: `${(hoverPoint.y / height) * 100}%` }}
        >
          <p className="font-semibold text-ink">{format(hoverData.value)}</p>
          <p className="text-[10px] text-muted">{hoverData.label}</p>
        </div>
      ) : null}
    </div>
  );
}

export function WeekdayBarChart({ data }: { data: { weekday: number; orders: number; revenue: number }[] }) {
  const [hover, setHover] = useState<number | null>(null);
  const max = Math.max(1, ...data.map((d) => d.orders));
  const names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  return (
    <div className="relative">
      <div className="flex h-[200px] items-end gap-2">
        {data.map((entry, index) => {
          const height = Math.max(4, (entry.orders / max) * 100);
          const active = hover === index;
          return (
            <button
              key={entry.weekday}
              type="button"
              className="group relative flex h-full flex-1 flex-col justify-end focus-visible:outline-offset-4"
              onMouseEnter={() => setHover(index)}
              onMouseLeave={() => setHover(null)}
              onFocus={() => setHover(index)}
              onBlur={() => setHover(null)}
              aria-label={`${names[index]}: ${entry.orders} orders, ${formatINR(entry.revenue)}`}
            >
              {active ? (
                <span className="absolute inset-x-0 bottom-full z-10 mb-2 rounded-xl border border-line bg-card px-2 py-1.5 text-center text-[10px] shadow-warm">
                  <span className="block font-semibold text-ink">{formatINR(entry.revenue)}</span>
                  <span className="block text-muted">{entry.orders} orders</span>
                </span>
              ) : null}
              <motion.span
                className={`block w-full rounded-t-lg ${active ? "bg-jaipur" : "bg-brand-soft/80"}`}
                initial={{ height: 0 }}
                animate={{ height: `${height}%` }}
                transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1], delay: index * 0.04 }}
              />
              <span className="mt-2 block text-center text-[10px] text-muted">{names[index]}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function DonutChart({
  data,
  centerLabel,
}: {
  data: { label: string; value: number }[];
  centerLabel: string;
}) {
  const [hover, setHover] = useState<number | null>(null);
  const total = data.reduce((sum, entry) => sum + entry.value, 0);
  const size = 220;
  const radius = 82;
  const stroke = 26;
  const circumference = 2 * Math.PI * radius;
  const fractions = data.map((entry) => (total > 0 ? entry.value / total : 0));

  const segments = data.map((entry, index) => {
    const fraction = fractions[index] ?? 0;
    const preceding = fractions.slice(0, index).reduce((sum, value) => sum + value, 0);
    return {
      ...entry,
      index,
      length: fraction * circumference,
      offset: -preceding * circumference,
      color: CHART_COLORS[index % CHART_COLORS.length]!,
      fraction,
    };
  });

  const active = hover !== null ? segments[hover] : null;

  return (
    <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="relative">
        <svg viewBox={`0 0 ${size} ${size}`} className="h-[200px] w-[200px] -rotate-90" role="img" aria-label="Category mix">
          <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="var(--line)" strokeWidth={stroke} opacity="0.35" />
          {segments.map((segment) => (
            <motion.circle
              key={`${segment.label}-${segment.index}`}
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="none"
              stroke={segment.color}
              strokeWidth={hover === segment.index ? stroke + 6 : stroke}
              strokeDasharray={`${Math.max(0, segment.length - 2)} ${circumference}`}
              strokeDashoffset={segment.offset}
              strokeLinecap="butt"
              initial={{ opacity: 0 }}
              animate={{ opacity: hover === null || hover === segment.index ? 1 : 0.4 }}
              transition={{ duration: 0.3 }}
              onMouseEnter={() => setHover(segment.index)}
              onMouseLeave={() => setHover(null)}
            />
          ))}
        </svg>
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
          <p className="text-[10px] uppercase tracking-[0.18em] text-muted">{active ? active.label : centerLabel}</p>
          <p className="mt-1 font-display text-xl text-ink">{formatCompactINR(active ? active.value : total)}</p>
          <p className="text-[10px] text-muted">{active ? `${(active.fraction * 100).toFixed(1)}% of revenue` : "Total revenue"}</p>
        </div>
      </div>

      <ul className="w-full space-y-2 sm:max-w-[190px]">
        {segments.map((segment) => (
          <li
            key={`legend-${segment.label}`}
            className={`flex items-center justify-between gap-2 rounded-lg px-2 py-1 text-xs transition-colors ${
              hover === segment.index ? "bg-surface-2" : ""
            }`}
            onMouseEnter={() => setHover(segment.index)}
            onMouseLeave={() => setHover(null)}
          >
            <span className="flex min-w-0 items-center gap-2">
              <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: segment.color }} aria-hidden="true" />
              <span className="truncate text-muted">{segment.label.replaceAll("-", " ")}</span>
            </span>
            <span className="font-semibold text-ink">{(segment.fraction * 100).toFixed(0)}%</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function Sparkline({ data, positive = true }: { data: number[]; positive?: boolean }) {
  const width = 96;
  const height = 30;
  const max = Math.max(1, ...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const points = data.map((value, index) => ({
    x: (index / Math.max(1, data.length - 1)) * width,
    y: height - ((value - min) / range) * height,
  }));

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="h-7 w-24" aria-hidden="true">
      <motion.path
        d={buildPath(points)}
        fill="none"
        stroke={positive ? "#2f7d5a" : "var(--jaipur)"}
        strokeWidth="2"
        strokeLinecap="round"
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ pathLength: 1, opacity: 1 }}
        transition={{ duration: 0.8 }}
      />
    </svg>
  );
}

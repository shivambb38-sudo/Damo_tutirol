import type { Metadata } from "next";
import Link from "next/link";
import type { ReactNode } from "react";
import { LogoutButton } from "@/components/admin/logout-button";
import { DoorMark } from "@/components/site-chrome";
import { can, getSession } from "@/lib/auth";

export const metadata: Metadata = {
  title: "Owner dashboard",
  robots: { index: false, follow: false, nocache: true },
};

const NAV = [
  { href: "/admin", label: "Overview", permission: "analytics:read", glyph: "◔" },
  { href: "/admin/menu", label: "Menu & prices", permission: "menu:write", glyph: "☕" },
  { href: "/admin/specials", label: "Specials", permission: "specials:write", glyph: "✦" },
  { href: "/admin/reservations", label: "Reservations", permission: "reservations:write", glyph: "◈" },
];

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const session = await getSession();

  // Login page renders without the dashboard shell.
  if (!session) return <div className="min-h-screen bg-surface">{children}</div>;

  const links = NAV.filter((item) => can(session.role, item.permission));

  return (
    <div className="min-h-screen bg-surface text-ink">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[240px] flex-col border-r border-line bg-card px-4 py-6 lg:flex">
        <Link href="/" className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand text-[#fbf6ec]">
            <DoorMark className="h-7 w-7" />
          </span>
          <span>
            <span className="block font-display text-lg leading-none text-ink">Blue Door</span>
            <span className="block text-[9px] uppercase tracking-[0.28em] text-muted">Cafe analytics</span>
          </span>
        </Link>

        <nav className="mt-8 flex-1 space-y-1" aria-label="Admin">
          {links.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-muted transition-colors hover:bg-surface-2 hover:text-ink"
            >
              <span aria-hidden="true" className="text-brand">{item.glyph}</span>
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="rounded-2xl border border-line bg-surface-2/60 p-3">
          <p className="truncate text-xs font-semibold text-ink">{session.email}</p>
          <p className="text-[10px] uppercase tracking-[0.2em] text-muted">{session.role}</p>
          <div className="mt-3 flex items-center gap-2">
            <LogoutButton compact />
            <Link href="/" className="text-[11px] font-semibold text-brand hover:underline">
              View site
            </Link>
          </div>
        </div>
      </aside>

      <div className="lg:pl-[240px]">
        <header className="sticky top-0 z-30 border-b border-line bg-surface/85 backdrop-blur lg:hidden">
          <div className="flex items-center justify-between px-4 py-3">
            <Link href="/admin" className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand text-[#fbf6ec]">
                <DoorMark className="h-5 w-5" />
              </span>
              <span className="font-display text-base text-ink">Blue Door</span>
            </Link>
            <LogoutButton compact />
          </div>
          <nav className="no-scrollbar flex gap-1 overflow-x-auto px-3 pb-2" aria-label="Admin mobile">
            {links.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="shrink-0 rounded-full border border-line px-3 py-1.5 text-[11px] font-semibold text-muted"
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </header>

        <div className="mx-auto w-full max-w-[1400px] px-4 py-6 sm:px-6 lg:px-8 lg:py-8">{children}</div>
      </div>
    </div>
  );
}

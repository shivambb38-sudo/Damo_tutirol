import { NextResponse, type NextRequest } from "next/server";
import { SESSION_COOKIE, verifySessionToken } from "@/lib/session";
import { env } from "@/lib/env";
import { allowedOrigins } from "@/lib/security";

/**
 * Edge middleware:
 *  1. Gate /admin/** behind a verified, signed session cookie.
 *  2. Reject cross-origin state-changing API calls (CORS/CSRF hard stop).
 *  3. Attach a strict CSP and anti-framing headers to every response.
 */

const PUBLIC_ADMIN_PATHS = ["/admin/login"];

export async function middleware(request: NextRequest) {
  const { pathname, origin } = request.nextUrl;
  const method = request.method.toUpperCase();

  // --- API origin enforcement (CORS: single allowed origin, never wildcard) ---
  if (pathname.startsWith("/api/") && !["GET", "HEAD", "OPTIONS"].includes(method)) {
    const requestOrigin = request.headers.get("origin");
    const permitted = new Set([...allowedOrigins(request.headers), origin]);
    if (requestOrigin && !permitted.has(requestOrigin)) {
      return NextResponse.json({ error: "Request rejected." }, { status: 403 });
    }
  }

  if (pathname.startsWith("/admin") && !PUBLIC_ADMIN_PATHS.includes(pathname)) {
    const token = request.cookies.get(SESSION_COOKIE)?.value;
    const session = token ? await verifySessionToken(token, env().AUTH_SECRET) : null;
    if (!session) {
      const loginUrl = new URL("/admin/login", request.url);
      loginUrl.searchParams.set("next", pathname);
      const redirect = NextResponse.redirect(loginUrl);
      redirect.headers.set("Cache-Control", "no-store");
      return redirect;
    }
  }

  const response = NextResponse.next();
  response.headers.set("Cache-Control", pathname.startsWith("/admin") ? "no-store" : "public, max-age=0, must-revalidate");
  return response;
}

export const config = {
  matcher: ["/admin/:path*", "/api/:path*"],
};

"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";
import { apiRequest } from "@/lib/client-api";
import { formatINR } from "@/lib/format";
import type { SpecialRow } from "@/lib/data";

const inputClass =
  "w-full rounded-xl border border-line bg-surface px-3 py-2 text-sm text-ink focus:border-brand focus:outline-none";
const labelClass = "mb-1 block text-[10px] font-semibold uppercase tracking-[0.16em] text-muted";

type Draft = {
  id?: number;
  title: string;
  description: string;
  priceInr: number;
  badge: string;
  active: boolean;
  sortOrder: number;
};

const emptyDraft: Draft = {
  title: "",
  description: "",
  priceInr: 250,
  badge: "Today only",
  active: true,
  sortOrder: 0,
};

export function SpecialsManager({ initial, canWrite }: { initial: SpecialRow[]; canWrite: boolean }) {
  const [specials, setSpecials] = useState(initial);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function save() {
    if (!draft) return;
    setBusy(true);
    setError("");
    const payload = {
      title: draft.title,
      description: draft.description,
      priceInr: draft.priceInr,
      badge: draft.badge,
      active: draft.active,
      sortOrder: draft.sortOrder,
    };
    const result = draft.id
      ? await apiRequest<{ special: SpecialRow }>(`/api/admin/specials/${draft.id}`, { method: "PATCH", body: payload })
      : await apiRequest<{ special: SpecialRow }>("/api/admin/specials", { method: "POST", body: payload });

    setBusy(false);
    if (!result.ok || !result.data.special) {
      setError(result.data.error ?? "Please check the fields and try again.");
      return;
    }
    const saved = result.data.special;
    setSpecials((current) =>
      draft.id ? current.map((entry) => (entry.id === saved.id ? saved : entry)) : [...current, saved],
    );
    setDraft(null);
  }

  async function toggleActive(entry: SpecialRow) {
    const result = await apiRequest<{ special: SpecialRow }>(`/api/admin/specials/${entry.id}`, {
      method: "PATCH",
      body: { active: !entry.active },
    });
    if (result.ok && result.data.special) {
      setSpecials((current) => current.map((row) => (row.id === entry.id ? result.data.special : row)));
    }
  }

  async function remove(id: number) {
    if (!window.confirm("Delete this special?")) return;
    const result = await apiRequest<{ ok: boolean }>(`/api/admin/specials/${id}`, { method: "DELETE" });
    if (result.ok) setSpecials((current) => current.filter((entry) => entry.id !== id));
    else setError(result.data.error ?? "Could not delete this special.");
  }

  return (
    <div className="pb-16">
      <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-[0.28em] text-brand">Specials of the day</p>
          <h1 className="mt-2 font-display text-3xl tracking-tight text-ink">Today&apos;s board</h1>
          <p className="mt-1 text-sm text-muted">Publish up to four rotating specials. Active items appear on the homepage instantly.</p>
        </div>
        {canWrite ? (
          <button
            type="button"
            onClick={() => setDraft({ ...emptyDraft, sortOrder: specials.length + 1 })}
            className="rounded-full bg-brand px-4 py-2.5 text-xs font-semibold text-white hover:bg-brand-soft"
          >
            + Add special
          </button>
        ) : null}
      </header>

      {error ? (
        <p role="alert" className="mt-3 rounded-xl border border-[#b3261e]/30 bg-[#b3261e]/5 px-3 py-2 text-xs text-[#8d1d17] dark:text-[#f0a9a2]">
          {error}
        </p>
      ) : null}

      <div className="mt-5 grid gap-4 md:grid-cols-2">
        {specials.map((entry) => (
          <article key={entry.id} className="rounded-3xl border border-line bg-card p-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="rounded-full bg-gold/15 px-2 py-0.5 text-[9px] font-bold uppercase tracking-[0.16em] text-accent">
                  {entry.badge}
                </span>
                <h2 className="mt-2 font-display text-xl text-ink">{entry.title}</h2>
                <p className="mt-1 text-xs leading-relaxed text-muted">{entry.description}</p>
              </div>
              <p className="font-display text-xl text-ink">{formatINR(entry.priceInr)}</p>
            </div>
            <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-line pt-3">
              <span
                className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                  entry.active ? "bg-[#2f7d5a]/12 text-[#1f6a4a] dark:text-[#7fd3ab]" : "bg-jaipur/15 text-[#96394a] dark:text-[#f0a3b0]"
                }`}
              >
                {entry.active ? "Live on site" : "Hidden"}
              </span>
              {canWrite ? (
                <div className="flex gap-1.5">
                  <button
                    type="button"
                    onClick={() => toggleActive(entry)}
                    className="rounded-full border border-line px-2.5 py-1 text-[10px] font-semibold text-ink"
                  >
                    {entry.active ? "Unpublish" : "Publish"}
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setDraft({
                        id: entry.id,
                        title: entry.title,
                        description: entry.description,
                        priceInr: entry.priceInr,
                        badge: entry.badge,
                        active: entry.active,
                        sortOrder: entry.sortOrder,
                      })
                    }
                    className="rounded-full border border-line px-2.5 py-1 text-[10px] font-semibold text-ink"
                  >
                    Edit
                  </button>
                  <button
                    type="button"
                    onClick={() => remove(entry.id)}
                    className="rounded-full border border-jaipur/40 px-2.5 py-1 text-[10px] font-semibold text-jaipur"
                  >
                    Delete
                  </button>
                </div>
              ) : null}
            </div>
          </article>
        ))}
        {specials.length === 0 ? (
          <p className="rounded-3xl border border-dashed border-line bg-card p-8 text-center text-sm text-muted">
            No specials yet. Add the first one to show it on the homepage.
          </p>
        ) : null}
      </div>

      <AnimatePresence>
        {draft ? (
          <motion.div
            className="fixed inset-0 z-[85] flex items-end justify-center bg-[#04121f]/60 backdrop-blur-sm sm:items-center sm:p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setDraft(null)}
          >
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-label={draft.id ? "Edit special" : "Add special"}
              className="max-h-[92vh] w-full overflow-y-auto rounded-t-3xl border border-line bg-card p-6 sm:max-w-lg sm:rounded-3xl"
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 40, opacity: 0 }}
              onClick={(event) => event.stopPropagation()}
            >
              <h2 className="font-display text-2xl text-ink">{draft.id ? "Edit special" : "New special"}</h2>
              <div className="mt-5 space-y-4">
                <div>
                  <label className={labelClass} htmlFor="special-title">Title</label>
                  <input
                    id="special-title"
                    value={draft.title}
                    maxLength={90}
                    onChange={(event) => setDraft({ ...draft, title: event.target.value })}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass} htmlFor="special-desc">Description</label>
                  <textarea
                    id="special-desc"
                    value={draft.description}
                    maxLength={240}
                    rows={3}
                    onChange={(event) => setDraft({ ...draft, description: event.target.value })}
                    className={inputClass}
                  />
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className={labelClass} htmlFor="special-price">Price (₹)</label>
                    <input
                      id="special-price"
                      type="number"
                      min={10}
                      max={100000}
                      value={draft.priceInr}
                      onChange={(event) => setDraft({ ...draft, priceInr: Number(event.target.value) })}
                      className={inputClass}
                    />
                  </div>
                  <div>
                    <label className={labelClass} htmlFor="special-badge">Badge</label>
                    <input
                      id="special-badge"
                      value={draft.badge}
                      maxLength={40}
                      onChange={(event) => setDraft({ ...draft, badge: event.target.value })}
                      className={inputClass}
                    />
                  </div>
                  <div>
                    <label className={labelClass} htmlFor="special-order">Order</label>
                    <input
                      id="special-order"
                      type="number"
                      min={0}
                      max={99}
                      value={draft.sortOrder}
                      onChange={(event) => setDraft({ ...draft, sortOrder: Number(event.target.value) })}
                      className={inputClass}
                    />
                  </div>
                </div>
                <label className="flex items-center gap-2 text-xs text-ink">
                  <input
                    type="checkbox"
                    checked={draft.active}
                    onChange={(event) => setDraft({ ...draft, active: event.target.checked })}
                  />
                  Publish immediately
                </label>
              </div>
              <div className="mt-6 flex justify-end gap-2 border-t border-line pt-4">
                <button type="button" onClick={() => setDraft(null)} className="rounded-full border border-line px-4 py-2 text-xs font-semibold text-ink">
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={save}
                  disabled={busy}
                  className="rounded-full bg-brand px-5 py-2 text-xs font-semibold text-white disabled:opacity-60"
                >
                  {busy ? "Saving…" : draft.id ? "Save changes" : "Add special"}
                </button>
              </div>
            </motion.div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  );
}

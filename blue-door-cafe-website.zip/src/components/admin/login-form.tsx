"use client";

import { motion, useReducedMotion } from "framer-motion";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { apiRequest } from "@/lib/client-api";

const inputClass =
  "w-full rounded-xl border border-line bg-surface px-3.5 py-2.5 text-sm text-ink placeholder:text-muted/60 focus:border-brand focus:outline-none";
const labelClass = "mb-1.5 block text-[10px] font-semibold uppercase tracking-[0.18em] text-muted";

export function LoginForm({ nextPath = "/admin" }: { nextPath?: string }) {
  const router = useRouter();
  const reduce = useReducedMotion();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [showTotp, setShowTotp] = useState(false);

  const safeNext = nextPath.startsWith("/") && !nextPath.startsWith("//") ? nextPath : "/admin";

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    setBusy(true);
    setError("");

    const result = await apiRequest<{ redirect?: string }>("/api/auth/login", {
      method: "POST",
      body: {
        email: String(data.get("email") ?? ""),
        password: String(data.get("password") ?? ""),
        totp: String(data.get("totp") ?? ""),
      },
    });

    setBusy(false);
    if (!result.ok) {
      setError(result.data.error ?? "Unable to sign in.");
      return;
    }
    router.replace(safeNext.startsWith("/admin") ? safeNext : "/admin");
    router.refresh();
  }

  return (
    <motion.form
      onSubmit={onSubmit}
      className="w-full max-w-md rounded-[2rem] border border-line bg-card p-7 shadow-warm sm:p-8"
      initial={reduce ? false : { opacity: 0, y: 20, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      noValidate
    >
      <p className="text-[10px] font-semibold uppercase tracking-[0.3em] text-brand">Owner access</p>
      <h1 className="mt-2 font-display text-3xl tracking-tight text-ink">Welcome back</h1>
      <p className="mt-2 text-sm text-muted">
        Sign in to manage the menu, specials, reservations and the analytics dashboard.
      </p>

      <div className="mt-6 space-y-4">
        <div>
          <label className={labelClass} htmlFor="email">Email</label>
          <input
            id="email"
            name="email"
            type="email"
            required
            autoComplete="email"
            maxLength={120}
            className={inputClass}
            placeholder="owner@bluedoorcafe.in"
          />
        </div>
        <div>
          <label className={labelClass} htmlFor="password">Password</label>
          <input
            id="password"
            name="password"
            type="password"
            required
            autoComplete="current-password"
            minLength={8}
            maxLength={200}
            className={inputClass}
            placeholder="••••••••••"
          />
        </div>

        {showTotp ? (
          <div>
            <label className={labelClass} htmlFor="totp">Authenticator code</label>
            <input
              id="totp"
              name="totp"
              inputMode="numeric"
              pattern="\d{6}"
              maxLength={6}
              className={inputClass}
              placeholder="123456"
            />
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setShowTotp(true)}
            className="text-[11px] font-semibold text-brand underline-offset-2 hover:underline"
          >
            I have a two-factor code
          </button>
        )}
      </div>

      {error ? (
        <p role="alert" className="mt-4 rounded-xl border border-[#b3261e]/30 bg-[#b3261e]/5 px-3 py-2 text-xs text-[#8d1d17] dark:text-[#f0a9a2]">
          {error}
        </p>
      ) : null}

      <button
        type="submit"
        disabled={busy}
        className="mt-6 w-full rounded-full bg-brand px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-brand-soft disabled:opacity-60"
      >
        {busy ? "Verifying…" : "Sign in securely"}
      </button>

      <p className="mt-4 text-center text-[10px] leading-relaxed text-muted">
        Sessions are signed, httpOnly and expire in 8 hours. Repeated failures lock the account for 15 minutes.
      </p>

      <div className="mt-5 rounded-xl border border-dashed border-line bg-surface-2/60 px-3 py-2 text-[10px] leading-relaxed text-muted">
        <span className="font-semibold text-ink">Demo credentials</span> · owner@bluedoorcafe.in / BlueDoor-Cafe-2026
        <br />
        Change these in the environment before going live.
      </div>
    </motion.form>
  );
}

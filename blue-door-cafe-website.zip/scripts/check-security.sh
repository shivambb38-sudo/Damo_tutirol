#!/usr/bin/env bash
# Lightweight pre-deploy security scan for Blue Door Cafe.
# Usage: bash scripts/check-security.sh
set -uo pipefail
fail=0

echo "== 1. .env is ignored =="
if grep -qE '^\.env$' .gitignore; then echo "  ok: .env ignored"; else echo "  FAIL: add .env to .gitignore"; fail=1; fi

echo "== 2. No .env or key files tracked by git =="
if git rev-parse --git-dir >/dev/null 2>&1; then
  tracked=$(git ls-files | grep -E '(^|/)\.env($|\.)|\.pem$|\.key$' || true)
  if [ -z "$tracked" ]; then echo "  ok: nothing sensitive tracked"; else echo "  FAIL: tracked secrets:"; echo "$tracked"; fail=1; fi
else
  echo "  note: not a git repository — nothing to inspect"
fi

echo "== 3. No hardcoded secret literals in src =="
if grep -rInE "(sk_live_|sk_test_|AKIA[0-9A-Z]{16}|-----BEGIN [A-Z ]*PRIVATE KEY-----|postgres(ql)?://[^\"']*:[^\"'@]+@)" src 2>/dev/null; then
  echo "  FAIL: possible secret literal above"; fail=1
else
  echo "  ok: none found"
fi

echo "== 4. No NEXT_PUBLIC secrets =="
if grep -rInE "NEXT_PUBLIC_[A-Z_]*(SECRET|PASSWORD|TOKEN|KEY)" src 2>/dev/null; then
  echo "  FAIL: secret exposed via NEXT_PUBLIC_"; fail=1
else
  echo "  ok: only public config uses NEXT_PUBLIC_"
fi

echo "== 5. No dangerouslySetInnerHTML outside JSON-LD/theme bootstrap =="
if grep -rIn "dangerouslySetInnerHTML" src 2>/dev/null | grep -vE "json-ld|layout.tsx"; then
  echo "  FAIL: review the file(s) above"; fail=1
else
  echo "  ok"
fi

echo "== 6. Source maps and debug flags =="
if grep -q "productionBrowserSourceMaps: false" next.config.ts; then echo "  ok: browser source maps off"; else echo "  FAIL"; fail=1; fi
if grep -q "poweredByHeader: false" next.config.ts; then echo "  ok: x-powered-by removed"; else echo "  FAIL"; fail=1; fi

echo "== 7. Production dependency audit =="
npm audit --omit=dev --audit-level=high || { echo "  FAIL: high/critical advisories"; fail=1; }

if [ "$fail" -eq 0 ]; then echo; echo "SECURITY SCAN PASSED"; else echo; echo "SECURITY SCAN FAILED"; fi
exit "$fail"

import type { Metadata } from "next";
import { RestaurantJsonLd } from "@/components/json-ld";
import { Hero, Marquee } from "@/components/home/hero";
import { MenuSection } from "@/components/home/menu-section";
import { Gallery } from "@/components/home/gallery";
import { Reviews } from "@/components/home/reviews";
import { About, ContactSection, ReserveSection, Specials, Visit } from "@/components/home/sections";
import { getPublicData } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Blue Door Cafe — Slow coffee in Pink City, Jaipur",
  description:
    "Single-origin coffee, baked-at-dawn pastries and Jaipur plates in a courtyard on Tulsi Marg, Gangori Bazaar. Reserve a table or call 97841 04113.",
};

export default async function HomePage() {
  const { categories, items, specials, reviews } = await getPublicData();

  return (
    <>
      <RestaurantJsonLd />
      <Hero />
      <Marquee />
      <About />
      <MenuSection categories={categories} items={items} />
      <Specials specials={specials} />
      <Gallery />
      <Reviews reviews={reviews} />
      <ReserveSection />
      <ContactSection />
      <Visit />
    </>
  );
}

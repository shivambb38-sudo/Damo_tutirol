import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";
import { env } from "@/lib/env";

/**
 * Field-level encryption for sensitive at-rest values (admin TOTP secrets).
 * AES-256-GCM with a key derived from AUTH_SECRET; ciphertext is versioned so
 * keys can be rotated later without ambiguity.
 */
function key(): Buffer {
  return createHash("sha256").update(`field-encryption:${env().AUTH_SECRET}`).digest();
}

export function encryptSecret(plain: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key(), iv);
  const encrypted = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  return `v1:${iv.toString("base64url")}:${cipher.getAuthTag().toString("base64url")}:${encrypted.toString("base64url")}`;
}

/** Accepts legacy plaintext so an operator can paste a secret and rotate in. */
export function decryptSecret(value: string): string {
  if (!value.startsWith("v1:")) return value;
  const [, ivPart, tagPart, dataPart] = value.split(":");
  if (!ivPart || !tagPart || !dataPart) return "";
  try {
    const decipher = createDecipheriv("aes-256-gcm", key(), Buffer.from(ivPart, "base64url"));
    decipher.setAuthTag(Buffer.from(tagPart, "base64url"));
    return Buffer.concat([decipher.update(Buffer.from(dataPart, "base64url")), decipher.final()]).toString("utf8");
  } catch {
    return "";
  }
}

import { db } from "@/db";
import { auditLog, specials } from "@/db/schema";
import { guardAdmin, noStoreJson } from "@/lib/api-guard";
import { getSpecials } from "@/lib/data";
import { parseJson, specialSchema } from "@/lib/validation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const guard = await guardAdmin(request, "analytics:read");
  if (guard.response) return guard.response;
  try {
    return noStoreJson({ specials: await getSpecials() });
  } catch {
    return noStoreJson({ error: "Specials are unavailable right now." }, 500);
  }
}

export async function POST(request: Request) {
  const guard = await guardAdmin(request, "specials:write");
  if (guard.response) return guard.response;

  const parsed = await parseJson(request, specialSchema);
  if (!parsed.ok) return parsed.response;

  try {
    const [created] = await db.insert(specials).values(parsed.data).returning();
    await db.insert(auditLog).values({
      actorId: guard.session.sub,
      action: "create",
      entity: "special",
      entityId: String(created?.id ?? ""),
    });
    return noStoreJson({ special: created }, 201);
  } catch {
    return noStoreJson({ error: "Could not save this special." }, 500);
  }
}

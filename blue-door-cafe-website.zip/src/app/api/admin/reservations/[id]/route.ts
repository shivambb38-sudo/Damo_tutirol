import { eq } from "drizzle-orm";
import { db } from "@/db";
import { auditLog, reservations } from "@/db/schema";
import { guardAdmin, noStoreJson } from "@/lib/api-guard";
import { parseJson, reservationUpdateSchema } from "@/lib/validation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: Params) {
  const guard = await guardAdmin(request, "reservations:write");
  if (guard.response) return guard.response;

  const { id: rawId } = await params;
  const id = Number(rawId);
  if (!Number.isInteger(id) || id < 1) return noStoreJson({ error: "Invalid reservation." }, 400);

  const parsed = await parseJson(request, reservationUpdateSchema);
  if (!parsed.ok) return parsed.response;

  try {
    const [updated] = await db
      .update(reservations)
      .set({ status: parsed.data.status })
      .where(eq(reservations.id, id))
      .returning();
    if (!updated) return noStoreJson({ error: "Reservation not found." }, 404);

    await db.insert(auditLog).values({
      actorId: guard.session.sub,
      action: "status_change",
      entity: "reservation",
      entityId: String(id),
    });
    return noStoreJson({ reservation: updated });
  } catch {
    return noStoreJson({ error: "Could not update this reservation." }, 500);
  }
}

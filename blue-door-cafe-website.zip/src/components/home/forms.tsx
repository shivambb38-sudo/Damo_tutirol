"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useState, type FormEvent } from "react";
import { Reveal, RippleButton } from "@/components/motion-primitives";
import { CAFE } from "@/lib/format";

const inputClass =
  "w-full rounded-xl border border-line bg-surface px-3.5 py-2.5 text-sm text-ink placeholder:text-muted/60 transition-colors focus:border-brand focus:outline-none";
const labelClass = "mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.16em] text-muted";

const TIME_SLOTS = [
  ["08:00", "8:00 am"],
  ["09:00", "9:00 am"],
  ["10:00", "10:00 am"],
  ["11:00", "11:00 am"],
  ["12:00", "12:00 pm"],
  ["13:00", "1:00 pm"],
  ["14:00", "2:00 pm"],
  ["16:00", "4:00 pm"],
  ["17:00", "5:00 pm"],
  ["18:00", "6:00 pm"],
  ["19:00", "7:00 pm"],
  ["20:00", "8:00 pm"],
  ["21:00", "9:00 pm"],
] as const;

type FieldError = { field: string; message: string };

function isoDate(offsetDays: number): string {
  const date = new Date();
  date.setDate(date.getDate() + offsetDays);
  return date.toISOString().slice(0, 10);
}

function Honeypot() {
  return (
    <div className="absolute -left-[9999px] top-auto h-px w-px overflow-hidden" aria-hidden="true">
      <label htmlFor="website">Website</label>
      <input id="website" name="website" type="text" tabIndex={-1} autoComplete="off" defaultValue="" />
    </div>
  );
}

export function ReservationForm() {
  const reduce = useReducedMotion();
  const [startedAt] = useState(() => Date.now());
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [reference, setReference] = useState("");
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState<FieldError[]>([]);

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);
    setStatus("submitting");
    setErrors([]);

    const payload = {
      name: String(formData.get("name") ?? ""),
      phone: String(formData.get("phone") ?? ""),
      email: String(formData.get("email") ?? ""),
      guests: Number(formData.get("guests") ?? 2),
      date: String(formData.get("date") ?? ""),
      time: String(formData.get("time") ?? "19:00"),
      notes: String(formData.get("notes") ?? ""),
      website: String(formData.get("website") ?? ""),
      formStartedAt: startedAt,
    };

    try {
      const response = await fetch("/api/reservations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await response.json()) as { reference?: string; error?: string; fields?: FieldError[] };
      if (!response.ok) {
        setStatus("error");
        setErrors(data.fields ?? []);
        setMessage(data.error ?? "Please check your details and try again.");
        return;
      }
      setReference(data.reference ?? "");
      setStatus("success");
      form.reset();
    } catch {
      setStatus("error");
      setMessage("Network hiccup. Please call us on 97841 04113.");
    }
  }

  return (
    <div className="relative overflow-hidden rounded-[2rem] border border-line bg-card p-6 shadow-warm sm:p-8">
      <AnimatePresence mode="wait">
        {status === "success" ? (
          <motion.div
            key="success"
            initial={reduce ? { opacity: 0 } : { opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex min-h-[420px] flex-col items-center justify-center text-center"
          >
            <motion.span
              className="flex h-16 w-16 items-center justify-center rounded-full bg-[#1f7a4d]/12 text-2xl text-[#1f7a4d]"
              initial={reduce ? undefined : { scale: 0.6, rotate: -12 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 220, damping: 14 }}
            >
              ✓
            </motion.span>
            <h3 className="mt-5 font-display text-2xl text-ink">Your table is on hold.</h3>
            <p className="mt-2 max-w-sm text-sm text-muted">
              Reference <span className="font-semibold text-ink">{reference}</span>. Our team will call to confirm
              within 30 minutes during opening hours.
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <a
                href={CAFE.phoneHref}
                className="rounded-full bg-brand px-5 py-2.5 text-sm font-semibold text-white"
              >
                Call {CAFE.phoneDisplay}
              </a>
              <button
                type="button"
                onClick={() => setStatus("idle")}
                className="rounded-full border border-line px-5 py-2.5 text-sm font-semibold text-ink"
              >
                Book another
              </button>
            </div>
          </motion.div>
        ) : (
          <motion.form
            key="form"
            onSubmit={onSubmit}
            initial={reduce ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-1 gap-4 sm:grid-cols-2"
            noValidate
          >
            <div className="sm:col-span-2">
              <p className="text-[10px] font-semibold uppercase tracking-[0.28em] text-accent">Reservations</p>
              <h3 className="mt-1 font-display text-2xl text-ink">Reserve your corner of the courtyard</h3>
            </div>
            <Honeypot />

            <div>
              <label className={labelClass} htmlFor="res-name">Full name</label>
              <input id="res-name" name="name" required maxLength={80} autoComplete="name" className={inputClass} placeholder="Ananya Sharma" />
            </div>
            <div>
              <label className={labelClass} htmlFor="res-phone">Mobile</label>
              <input id="res-phone" name="phone" required inputMode="tel" maxLength={16} autoComplete="tel" className={inputClass} placeholder="98765 43210" />
            </div>
            <div>
              <label className={labelClass} htmlFor="res-email">Email (optional)</label>
              <input id="res-email" name="email" type="email" maxLength={120} autoComplete="email" className={inputClass} placeholder="you@example.com" />
            </div>
            <div>
              <label className={labelClass} htmlFor="res-guests">Guests</label>
              <select id="res-guests" name="guests" className={inputClass} defaultValue="2">
                {Array.from({ length: 12 }).map((_, index) => (
                  <option key={index + 1} value={index + 1}>
                    {index + 1} {index === 0 ? "guest" : "guests"}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className={labelClass} htmlFor="res-date">Date</label>
              <input id="res-date" name="date" type="date" required min={isoDate(0)} max={isoDate(90)} defaultValue={isoDate(1)} className={inputClass} />
            </div>
            <div>
              <label className={labelClass} htmlFor="res-time">Time</label>
              <select id="res-time" name="time" className={inputClass} defaultValue="19:00">
                {TIME_SLOTS.map(([value, label]) => (
                  <option key={value} value={value}>{label}</option>
                ))}
              </select>
            </div>
            <div className="sm:col-span-2">
              <label className={labelClass} htmlFor="res-notes">Anything we should know?</label>
              <textarea id="res-notes" name="notes" rows={3} maxLength={300} className={inputClass} placeholder="Anniversary, high chair, courtyard table…" />
            </div>

            {errors.length > 0 ? (
              <ul className="sm:col-span-2 rounded-xl border border-[#b3261e]/30 bg-[#b3261e]/5 px-3 py-2 text-xs text-[#8d1d17] dark:text-[#f0a9a2]">
                {errors.map((error) => (
                  <li key={`${error.field}-${error.message}`}>{error.message}</li>
                ))}
              </ul>
            ) : null}
            {status === "error" && errors.length === 0 ? (
              <p className="sm:col-span-2 rounded-xl border border-[#b3261e]/30 bg-[#b3261e]/5 px-3 py-2 text-xs text-[#8d1d17] dark:text-[#f0a9a2]">
                {message}
              </p>
            ) : null}

            <div className="sm:col-span-2 flex flex-col gap-3 border-t border-line pt-4 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-[11px] leading-relaxed text-muted">
                We confirm every booking by phone. Tables are held for 15 minutes.
              </p>
              <RippleButton type="submit" disabled={status === "submitting"}>
                {status === "submitting" ? "Sending…" : "Request table"}
              </RippleButton>
            </div>
          </motion.form>
        )}
      </AnimatePresence>
    </div>
  );
}

export function ContactForm() {
  const reduce = useReducedMotion();
  const [startedAt] = useState(() => Date.now());
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [errors, setErrors] = useState<FieldError[]>([]);
  const [message, setMessage] = useState("");

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);
    setStatus("submitting");
    setErrors([]);

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: String(formData.get("name") ?? ""),
          email: String(formData.get("email") ?? ""),
          phone: String(formData.get("phone") ?? ""),
          subject: String(formData.get("subject") ?? ""),
          message: String(formData.get("message") ?? ""),
          website: String(formData.get("website") ?? ""),
          formStartedAt: startedAt,
        }),
      });
      const data = (await response.json()) as { error?: string; fields?: FieldError[] };
      if (!response.ok) {
        setStatus("error");
        setErrors(data.fields ?? []);
        setMessage(data.error ?? "Please check your message.");
        return;
      }
      setStatus("success");
      form.reset();
    } catch {
      setStatus("error");
      setMessage("Network hiccup. Please call us on 97841 04113.");
    }
  }

  if (status === "success") {
    return (
      <Reveal className="flex min-h-[320px] flex-col items-start justify-center rounded-[2rem] border border-line bg-card p-8">
        <span className="flex h-12 w-12 items-center justify-center rounded-full bg-[#1f7a4d]/12 text-xl text-[#1f7a4d]">✓</span>
        <h3 className="mt-4 font-display text-2xl text-ink">Message received.</h3>
        <p className="mt-2 max-w-sm text-sm text-muted">
          Thank you for writing in. We reply within one working day — sooner if it is about a table tonight.
        </p>
        <button
          type="button"
          onClick={() => setStatus("idle")}
          className="mt-5 rounded-full border border-line px-5 py-2.5 text-sm font-semibold text-ink"
        >
          Write another
        </button>
      </Reveal>
    );
  }

  return (
    <form onSubmit={onSubmit} className="grid grid-cols-1 gap-4 rounded-[2rem] border border-line bg-card p-6 sm:grid-cols-2 sm:p-8" noValidate>
      <Honeypot />
      <div className="sm:col-span-2">
        <label className={labelClass} htmlFor="contact-name">Name</label>
        <input id="contact-name" name="name" required maxLength={80} autoComplete="name" className={inputClass} placeholder="Your name" />
      </div>
      <div>
        <label className={labelClass} htmlFor="contact-email">Email</label>
        <input id="contact-email" name="email" type="email" required maxLength={120} autoComplete="email" className={inputClass} placeholder="you@example.com" />
      </div>
      <div>
        <label className={labelClass} htmlFor="contact-phone">Mobile (optional)</label>
        <input id="contact-phone" name="phone" inputMode="tel" maxLength={16} autoComplete="tel" className={inputClass} placeholder="98765 43210" />
      </div>
      <div className="sm:col-span-2">
        <label className={labelClass} htmlFor="contact-subject">Subject</label>
        <input id="contact-subject" name="subject" required maxLength={100} className={inputClass} placeholder="Private event, coffee beans, feedback…" />
      </div>
      <div className="sm:col-span-2">
        <label className={labelClass} htmlFor="contact-message">Message</label>
        <textarea id="contact-message" name="message" rows={4} required maxLength={1000} className={inputClass} placeholder="Tell us how we can help." />
      </div>

      {errors.length > 0 ? (
        <ul className="sm:col-span-2 rounded-xl border border-[#b3261e]/30 bg-[#b3261e]/5 px-3 py-2 text-xs text-[#8d1d17] dark:text-[#f0a9a2]">
          {errors.map((error) => (
            <li key={`${error.field}-${error.message}`}>{error.message}</li>
          ))}
        </ul>
      ) : null}
      {status === "error" && errors.length === 0 ? (
        <p className="sm:col-span-2 rounded-xl border border-[#b3261e]/30 bg-[#b3261e]/5 px-3 py-2 text-xs text-[#8d1d17] dark:text-[#f0a9a2]">
          {message}
        </p>
      ) : null}

      <div className="sm:col-span-2 flex flex-col gap-3 border-t border-line pt-4 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-[11px] text-muted">{reduce ? "" : "We never share your details."} Protected by rate limiting & spam checks.</p>
        <RippleButton type="submit" disabled={status === "submitting"}>
          {status === "submitting" ? "Sending…" : "Send message"}
        </RippleButton>
      </div>
    </form>
  );
}

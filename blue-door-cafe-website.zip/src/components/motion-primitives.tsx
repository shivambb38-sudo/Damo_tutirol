"use client";

import { motion, useInView, useReducedMotion, useSpring, useTransform } from "framer-motion";
import Link from "next/link";
import {
  useEffect,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type MouseEvent,
  type ReactNode,
} from "react";
import { formatINR } from "@/lib/format";

/** Scroll-triggered fade/slide/scale wrapper used across every section. */
export function Reveal({
  children,
  delay = 0,
  y = 28,
  scale = 0.98,
  className = "",
  as = "div",
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  scale?: number;
  className?: string;
  as?: "div" | "section" | "li" | "article";
}) {
  const reduce = useReducedMotion();
  const MotionTag = motion[as];

  return (
    <MotionTag
      className={className}
      initial={reduce ? { opacity: 0 } : { opacity: 0, y, scale }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, amount: 0.2, margin: "0px 0px -80px 0px" }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </MotionTag>
  );
}

/** Button/link with a pointer-position ripple and hover lift. */
export function RippleLink({
  href,
  children,
  variant = "solid",
  className = "",
  ...rest
}: {
  href: string;
  children: ReactNode;
  variant?: "solid" | "ghost" | "soft";
  className?: string;
} & Omit<React.ComponentProps<typeof Link>, "href" | "children">) {
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number }[]>([]);

  const styles = {
    solid: "bg-brand text-white hover:bg-brand-soft shadow-warm",
    ghost: "border border-white/35 text-white hover:bg-white/10 backdrop-blur-sm",
    soft: "bg-surface-2 text-ink border border-line hover:border-brand/40",
  }[variant];

  return (
    <Link
      href={href}
      onPointerDown={(event) => {
        const rect = event.currentTarget.getBoundingClientRect();
        const id = Date.now();
        setRipples((current) => [
          ...current,
          { id, x: event.clientX - rect.left, y: event.clientY - rect.top },
        ]);
        window.setTimeout(() => setRipples((current) => current.filter((r) => r.id !== id)), 650);
      }}
      className={`group relative inline-flex items-center justify-center gap-2 overflow-hidden rounded-full px-6 py-3 text-sm font-semibold tracking-wide transition-all duration-300 hover:-translate-y-0.5 active:translate-y-0 ${styles} ${className}`}
      {...rest}
    >
      {ripples.map((ripple) => (
        <motion.span
          key={ripple.id}
          className="pointer-events-none absolute h-10 w-10 rounded-full bg-white/40"
          style={{ left: ripple.x - 20, top: ripple.y - 20 }}
          initial={{ scale: 0, opacity: 0.6 }}
          animate={{ scale: 6, opacity: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        />
      ))}
      <span className="relative z-10 flex items-center gap-2">{children}</span>
    </Link>
  );
}

export function RippleButton({
  children,
  variant = "solid",
  className = "",
  ...props
}: {
  children: ReactNode;
  variant?: "solid" | "soft";
} & ButtonHTMLAttributes<HTMLButtonElement>) {
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number }[]>([]);
  const styles = {
    solid: "bg-brand text-white hover:bg-brand-soft",
    soft: "bg-surface-2 text-ink border border-line hover:border-brand/40",
  }[variant];

  return (
    <button
      onPointerDown={(event: MouseEvent<HTMLButtonElement>) => {
        const rect = event.currentTarget.getBoundingClientRect();
        const id = Date.now();
        setRipples((current) => [...current, { id, x: event.clientX - rect.left, y: event.clientY - rect.top }]);
        window.setTimeout(() => setRipples((current) => current.filter((r) => r.id !== id)), 650);
      }}
      className={`relative inline-flex items-center justify-center gap-2 overflow-hidden rounded-full px-5 py-2.5 text-sm font-semibold transition-all duration-300 hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60 ${styles} ${className}`}
      {...props}
    >
      {ripples.map((ripple) => (
        <motion.span
          key={ripple.id}
          className="pointer-events-none absolute h-10 w-10 rounded-full bg-white/40"
          style={{ left: ripple.x - 20, top: ripple.y - 20 }}
          initial={{ scale: 0, opacity: 0.6 }}
          animate={{ scale: 6, opacity: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        />
      ))}
      <span className="relative z-10 flex items-center gap-2">{children}</span>
    </button>
  );
}

/** Counts up to `value` when scrolled into view — transform/opacity only. */
export function AnimatedPrice({
  value,
  className = "",
  prefix = "",
}: {
  value: number;
  className?: string;
  prefix?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.6 });
  const reduce = useReducedMotion();
  const spring = useSpring(reduce ? value : 0, { stiffness: 60, damping: 18 });
  const display = useTransform(spring, (latest) => formatINR(Math.round(latest)));
  const [text, setText] = useState(() => formatINR(value));

  useEffect(() => {
    if (inView) spring.set(value);
    const unsubscribe = display.on("change", (latest) => setText(latest));
    return () => unsubscribe();
  }, [display, inView, spring, value]);

  return (
    <span ref={ref} className={className}>
      {prefix}
      {text}
    </span>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "center",
  light = false,
}: {
  eyebrow: string;
  title: string;
  description?: string;
  align?: "center" | "left";
  light?: boolean;
}) {
  return (
    <div className={`${align === "center" ? "mx-auto text-center" : "text-left"} max-w-2xl`}>
      <Reveal>
        <p
          className={`flex items-center gap-3 text-[11px] font-semibold uppercase tracking-[0.32em] ${
            align === "center" ? "justify-center" : ""
          } ${light ? "text-[#f3e8d6]/80" : "text-brand"}`}
        >
          <span className={`h-px w-8 ${light ? "bg-[#f3e8d6]/50" : "bg-jaipur"}`} aria-hidden="true" />
          {eyebrow}
        </p>
      </Reveal>
      <Reveal delay={0.08}>
        <h2
          className={`mt-4 font-display text-3xl leading-[1.1] tracking-tight sm:text-4xl lg:text-[2.85rem] ${
            light ? "text-[#fbf6ec]" : "text-ink"
          }`}
        >
          {title}
        </h2>
      </Reveal>
      {description ? (
        <Reveal delay={0.16}>
          <p className={`mt-4 text-[15px] leading-relaxed ${light ? "text-[#f3e8d6]/75" : "text-muted"}`}>
            {description}
          </p>
        </Reveal>
      ) : null}
    </div>
  );
}

import { redirect } from "next/navigation";
import { SpecialsManager } from "@/components/admin/specials-manager";
import { can, getSession } from "@/lib/auth";
import { getSpecials } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function AdminSpecialsPage() {
  const session = await getSession();
  if (!session) redirect("/admin/login");
  if (!can(session.role, "specials:write") && !can(session.role, "analytics:read")) redirect("/admin");

  const specials = await getSpecials();
  return (
    <SpecialsManager
      initial={specials.map((entry) => ({
        id: entry.id,
        title: entry.title,
        description: entry.description,
        priceInr: entry.priceInr,
        badge: entry.badge,
        active: entry.active,
        sortOrder: entry.sortOrder,
      }))}
      canWrite={can(session.role, "specials:write")}
    />
  );
}

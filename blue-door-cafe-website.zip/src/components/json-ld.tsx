import { CAFE } from "@/lib/format";

/**
 * Restaurant + LocalBusiness structured data.
 * Static, developer-authored JSON only — never user input. The serialised
 * string has `<` escaped so it cannot terminate the script element.
 */
export function RestaurantJsonLd() {
  const data = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": ["Restaurant", "LocalBusiness", "CafeOrCoffeeShop"],
        "@id": `${process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"}/#restaurant`,
        name: CAFE.name,
        description:
          "Courtyard cafe in Gangori Bazaar, Jaipur serving single-origin coffee, fresh bakes and Jaipur plates.",
        url: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",
        telephone: "+91-97841-04113",
        priceRange: "₹₹ · ₹150–₹600 per person",
        currenciesAccepted: "INR",
        paymentAccepted: "Cash, UPI, Credit Card",
        servesCuisine: ["Cafe", "Indian", "Rajasthani", "Continental"],
        image:
          "https://images.pexels.com/photos/33454120/pexels-photo-33454120.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200",
        address: {
          "@type": "PostalAddress",
          streetAddress: "Tulsi Marg, Gangori Bazaar",
          addressLocality: "Jaipur",
          addressRegion: "Rajasthan",
          postalCode: "302002",
          addressCountry: "IN",
        },
        geo: { "@type": "GeoCoordinates", latitude: 26.9239, longitude: 75.8267 },
        openingHoursSpecification: [
          {
            "@type": "OpeningHoursSpecification",
            dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday"],
            opens: "08:00",
            closes: "22:30",
          },
          {
            "@type": "OpeningHoursSpecification",
            dayOfWeek: ["Friday", "Saturday", "Sunday"],
            opens: "08:00",
            closes: "23:30",
          },
        ],
        aggregateRating: { "@type": "AggregateRating", ratingValue: "4.9", reviewCount: "1284" },
        acceptsReservations: `${process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"}/#reserve`,
        sameAs: CAFE.socials.map((social) => social.href),
      },
      {
        "@type": "WebSite",
        name: CAFE.name,
        url: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",
      },
    ],
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data).replace(/</g, "\\u003c") }}
    />
  );
}
